//
//  SocialNotificationVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 05/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Quickblox

class SocialNotificationVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblNotificationAvailableOrNot: UILabel!
    
    
    var arrNotificationData = NSArray()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        
//        tblView.estimatedRowHeight = 70.0
//        tblView.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        getProfileImageDocumentDirectory()
        readNotificationMarkWebServiceCall()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrNotificationData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cellID") as! SocialNotificationTblCell
        let dicNotif = arrNotificationData[indexPath.row] as! NSDictionary
        print(dicNotif)
        
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
        
        cell.lblNotificationDescrip.text = "\(dicNotif["Description"] as! String)"
        cell.lblNotificationHead.text = "\(dicNotif["Title"] as! String)"
        cell.imgViewProPic.sd_setImage(with: URL(string : dicNotif["Image"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        if dicNotif["Type"] as! String == "1" || dicNotif["Type"] as! String == "4"
        {
            cell.btnConfirm.isHidden = true
            cell.btnDecline.isHidden = true
            cell.imgViewCross.isHidden = true
            cell.lblDate.isHidden = false
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            let strTempDate = dicNotif["Date"] as! String
            let date = dateFormatter.date(from: strTempDate)
            cell.lblDate.text = self.dateFormatterNotification.string(from: date!)
            
        }
        else if dicNotif["Type"] as! String == "2"
        {
            cell.btnConfirm.setTitle("ACCEPT", for: .normal)
            cell.btnConfirm.isHidden = false
            cell.btnDecline.isHidden = false
            cell.imgViewCross.isHidden = false
            cell.lblDate.isHidden = true
            
            cell.btnConfirm.tag = indexPath.row
            cell.btnDecline.tag = indexPath.row
            cell.btnConfirm.addTarget(self, action: #selector(ActionAcceptYes(sender:)), for: .touchUpInside)
            cell.btnDecline.addTarget(self, action: #selector(ActionDeclineBtn(sender:)), for: .touchUpInside)
            
        }
        else if dicNotif["Type"] as! String == "3"
        {
            cell.btnConfirm.setTitle("VIEW", for: .normal)
            cell.btnConfirm.isHidden = false
            cell.btnDecline.isHidden = false
            cell.imgViewCross.isHidden = false
            cell.lblDate.isHidden = true
            
            cell.btnConfirm.tag = indexPath.row
            cell.btnDecline.tag = indexPath.row
            cell.btnConfirm.addTarget(self, action: #selector(ActionAcceptYes(sender:)), for: .touchUpInside)
            cell.btnDecline.addTarget(self, action: #selector(ActionDeclineBtn(sender:)), for: .touchUpInside)
        }
        
//        [sizingCell setNeedsLayout];
//        [sizingCell layoutIfNeeded];
        
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.setEditing(true, animated: true)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
//        return 70
        
        return UITableViewAutomaticDimension
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        let dicNotif = arrNotificationData[indexPath.row] as! NSDictionary
        DeleteNotificationAPICall(strNotifyID: dicNotif["NotifyID"] as! String)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
//        let dicNotif = arrNotificationData[indexPath.row] as! NSDictionary
//        print(dicNotif)
//
//        if dicNotif["Clickable"] as! String == "2"
//        {
//            if dicNotif["RelationType"] as! String == "1"
//            {
//                calendarDetailAPICall(strRelationID: dicNotif["RelationID"] as! String)
//
//            }
//            else if dicNotif["RelationType"] as! String == "2"
//            {
//                let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
//                eventDetailVC.strEventID = (dicNotif["RelationID"] as? String)!
//                self.navigationController?.pushViewController(eventDetailVC, animated: true)
//            }
//        }
    }
    
    
    // *********** Calendar Detail API Call ********** //
    func calendarDetailAPICall(strRelationID:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Calendar/Fetch"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":strRelationID, "Val_Userid":strUserID, "Action":"SingleCalendar"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicNotifReadMark = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicNotifReadMark?["status"] as? String == "success"
                    {
                        print(dicNotifReadMark)
                        let arrData = dicNotifReadMark!["data"] as! NSArray
                        let dicCalData = arrData[0] as! NSDictionary
                        print(dicCalData)
                        
                        self.getDialogsByCalendar(dicCalData: dicCalData)
                        
                        

                    }
                    else if dicNotifReadMark?["status"] as? String == "error"
                    {
                        
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    func getDialogsByCalendar(dicCalData:NSDictionary) {
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
            
        }, completion: { (response: QBResponse?) -> Void in
            
            guard response != nil && response!.isSuccess else {
                MBProgressHUD.hide(for: self.view, animated: true)
                return
            }
            
            MBProgressHUD.hide(for: self.view, animated: true)
            
            let customCalVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomCalendarVC") as! CustomCalendarVC
            let dicCalendarTemp = dicCalData.mutableCopy()
            customCalVC.dicCalData = dicCalendarTemp as! NSMutableDictionary
            self.navigationController?.pushViewController(customCalVC, animated: true)
            
        })
    }
    
    
    // ********** All Button Actions Methods ********** //
    
    @objc func ActionAcceptYes(sender:UIButton)
    {
        let dicNotif = arrNotificationData[sender.tag] as! NSDictionary
        ActionNotificationWebServiceCall(strNotifyID: dicNotif["NotifyID"] as! String, strAction: "2", dicNotificationDetail: dicNotif)
    }
    
    @objc func ActionDeclineBtn(sender:UIButton)
    {
        let dicNotif = arrNotificationData[sender.tag] as! NSDictionary
        ActionNotificationWebServiceCall(strNotifyID: dicNotif["NotifyID"] as! String, strAction: "3", dicNotificationDetail: dicNotif)
    }
    
    
    // ********** Notification Date Selector ********** //
    fileprivate lazy var dateFormatterNotification: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd"
        return formatter
    }()
    
    
    
    // *********** Delete Notification API Call ********** //
    func DeleteNotificationAPICall(strNotifyID:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Notification/Details"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Notifyid":strNotifyID, "Action":"Delete"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicNotifReadMark = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicNotifReadMark?["status"] as? String == "success"
                    {
                        self.getNotificationListAPICall()
                    }
                    else if dicNotifReadMark?["status"] as? String == "error"
                    {
                        self.getNotificationListAPICall()
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    
    // *********** Notification Action API Service Call ********** //
    func ActionNotificationWebServiceCall(strNotifyID:String, strAction:String, dicNotificationDetail:NSDictionary)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Notification/Details"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Val_Notifyid":strNotifyID, "Val_Action":strAction, "Action":"TakeAction"]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    print(response.debugDescription)
                    let dicNotifAction = response.result.value as? [String: Any]
                    print(dicNotifAction)
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicNotifAction?["status"] as? String == "success"
                    {
//                        self.getNotificationListAPICall()
                        
                        if strAction == "3"
                        {
                            
                        }
                        else
                        {
                            print(dicNotificationDetail)
                            
                            if dicNotificationDetail["RelationType"] as! String == "1"
                            {
                                self.calendarDetailAPICall(strRelationID: dicNotificationDetail["RelationID"] as! String)
                            }
                            else if dicNotificationDetail["RelationType"] as! String == "2"
                            {
//                                let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
//                                eventDetailVC.strEventID = (dicNotificationDetail["RelationID"] as? String)!
//                                self.navigationController?.pushViewController(eventDetailVC, animated: true)
                                
                                self.eventDetailAPICall(strEventID: (dicNotificationDetail["RelationID"] as? String)!)
                            }
                        }
                    }
                    else if dicNotifAction?["status"] as? String == "error"
                    {
                        self.getNotificationListAPICall()
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    // ********** Gel Event Detail Api Call ********** //
    func eventDetailAPICall(strEventID:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as! String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Val_Userid":strUserID, "Action":"SingleEvent"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.debugDescription)
                        let dicEventResponse = response.result.value as? [String: Any]
                        print(dicEventResponse)
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicEventResponse?["status"] as? String == "success"
                        {
                            let arrEventDetailData = dicEventResponse?["data"] as! NSArray
                            let dicEventDetailData = arrEventDetailData[0] as! NSDictionary
                            print(dicEventDetailData)

                            self.getDialogs(strEventJID: dicEventDetailData["EventJID"] as! String, strEventID: strEventID, arrMemberList: dicEventDetailData["EventMembers"] as! NSArray)
                            
                            
                        }
                        else if dicEventResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    func getDialogs(strEventJID:String, strEventID:String, arrMemberList:NSArray) {
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
            
        }, completion: { (response: QBResponse?) -> Void in
            
            guard response != nil && response!.isSuccess else {
                
                return
            }
            
            MBProgressHUD.hide(for: self.view, animated: true)
            
            ServicesManager.instance().chatService.fetchDialog(withID: strEventJID) { (dialog) in
                
                print(dialog)
                
                let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                eventDetailVC.strEventID = strEventID
                eventDetailVC.arrMemberList = arrMemberList
                eventDetailVC.dialog = dialog
                self.navigationController?.pushViewController(eventDetailVC, animated: true)
            }
            
        })
        
    }
    
    
    
    
    
    // *********** Mark As Read Notification Service Call ********** //
    func readNotificationMarkWebServiceCall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            self.lblNotificationAvailableOrNot.text = "No internet connection"
            self.lblNotificationAvailableOrNot.isHidden = false
            
            self.arrNotificationData = NSArray()
            self.tblView.reloadData()
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Notification/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Action":"MarkasRead"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicNotifReadMark = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicNotifReadMark?["status"] as? String == "success"
                        {
                            if let tabItems = self.tabBarController?.tabBar.items as NSArray!
                            {
                                let tabItem = tabItems[4] as! UITabBarItem
                                tabItem.badgeValue = nil
                            }
                            
                            self.getNotificationListAPICall()
                        }
                        else if dicNotifReadMark?["status"] as? String == "error"
                        {
                            self.getNotificationListAPICall()
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    // ********** Fetch Notification List API Call ********** //
    func getNotificationListAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Notification/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Action":"GetAllNotifications"]
//            let parameters = ["Val_Userid":"1", "Action":"GetAllNotifications"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.description)
                        
                        let dicNotifResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicNotifResponse?["status"] as? String == "success"
                        {
                            self.arrNotificationData = dicNotifResponse?["data"] as! NSArray
                            print(self.arrNotificationData)
                            if self.arrNotificationData.count != 0
                            {
                                self.lblNotificationAvailableOrNot.isHidden = true
                            }
                            else
                            {
                                self.lblNotificationAvailableOrNot.isHidden = false
                                self.lblNotificationAvailableOrNot.text = "Notifications are not available"
                            }
                            self.tblView.reloadData()
                            
                        }
                        else if dicNotifResponse?["status"] as? String == "error"
                        {
                            self.arrNotificationData = NSArray()
                            self.tblView.reloadData()
                            self.lblNotificationAvailableOrNot.isHidden = true
                            
                            let alertCntrl = UIAlertController(title: nil, message: (dicNotifResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    // ********** Get Profile Picture Document Directory ********** //
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
    
}







































