//
//  SocialNotificationTblCell.swift
//  heyoo
//
//  Created by Intorque LLP on 28/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialNotificationTblCell: UITableViewCell {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblNotificationHead: UILabel!
    @IBOutlet weak var lblNotificationDescrip: UILabel!
    @IBOutlet weak var btnConfirm: UIButton!
    @IBOutlet weak var btnDecline: UIButton!
    @IBOutlet weak var imgViewCross: UIImageView!
    @IBOutlet weak var lblDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}








