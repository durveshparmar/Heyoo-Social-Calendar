//
//  collectColorCell.swift
//  heyoo
//
//  Created by Intorque LLP on 18/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class collectColorCell: UICollectionViewCell {
    @IBOutlet weak var viewColor: UIView!
    @IBOutlet weak var imgViewTick: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewColor.layer.cornerRadius = viewColor.frame.size.width/2
    }
    
}
