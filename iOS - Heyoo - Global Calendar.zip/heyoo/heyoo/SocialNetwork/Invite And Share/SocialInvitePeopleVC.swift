//
//  SocialInvitePeopleVC.swift
//  heyoo
//
//  Created by Intorque LLP on 25/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Contacts
import ContactsUI
import MessageUI

protocol invitePeopleSelectProtocol {
    func setSelectedInvitedPeople(selectInvite : NSMutableArray)
}

class SocialInvitePeopleVC: UIViewController, UITableViewDelegate, UITableViewDataSource, MFMessageComposeViewControllerDelegate, UITextFieldDelegate {
    var delegate:invitePeopleSelectProtocol?
    private let refreshControl = UIRefreshControl()
    var isTableRefresh : Bool = false
    
    var arrInvitedPeople = NSMutableArray()
    var arrInvitedPeopleTemp = NSMutableArray()
    
    
    @IBOutlet weak var lblNoUserFound: UILabel!
    @IBOutlet weak var imgViewIconSearch: UIImageView!
    @IBOutlet weak var viewNav: UIView!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var viewSearchBack: UIView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var viewTabBack: UIView!
    @IBOutlet weak var btnGlobalSearch: UIButton!
    @IBOutlet weak var btnInviteFriendSearch: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var FetchContacts = [CNContact]()
    var arrFinalContactList = NSArray()
    var arrGlobalSearchList = NSArray()
    var isMemberVC = String()
    var dicCalData = NSMutableDictionary()
    
    
    var searchActive : Bool = false
    var filtered = NSArray()
    var isSearchType : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if isMemberVC == "2"
        {
            viewNav.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
            btnGlobalSearch.setTitleColor(postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String), for: .normal)
            imgViewIconSearch.image = imgViewIconSearch.image?.withRenderingMode(.alwaysTemplate)
            imgViewIconSearch.tintColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        }
        else
        {
            for i in (0..<arrInvitedPeople.count)
            {
                arrInvitedPeopleTemp.add(arrInvitedPeople.object(at: i))
            }
        }
        
        if #available(iOS 10.0, *) {
            tblView.refreshControl = refreshControl
        } else {
            tblView.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(refreshContactData), for: .valueChanged)
        
        viewTabBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewTabBack.layer.shadowOpacity = 0.4
        viewTabBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewTabBack.layer.shadowRadius = 3
        
        isSearchType = false
        
        if UserDefaults.standard.data(forKey: "ContactList") != nil
        {
            let getDataStored = UserDefaults.standard.data(forKey: "ContactList")
            self.arrFinalContactList = NSKeyedUnarchiver.unarchiveObject(with: getDataStored!) as! NSArray
            self.tblView.reloadData()
        }
        else
        {
            isTableRefresh = false
            fetchContactMethod()
        }
        
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionDoneSelection(_ sender: UIBarButtonItem)
    {
        if self.isMemberVC == "2"
        {
            self.addMemberCalendarAPICall()
        }
        else
        {
            delegate?.setSelectedInvitedPeople(selectInvite: arrInvitedPeopleTemp)
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func ActionFinishSearch(_ sender: UIButton)
    {
        txtSearch.text = nil
        filtered = NSArray()
        tblView.reloadData()
    }
    
    @IBAction func ActionGlobalSearch(_ sender: UIButton)
    {
        isSearchType = false
        
        if isMemberVC == "2"
        {
            btnGlobalSearch.setTitleColor(postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String), for: .normal)
        }
        else
        {
            btnGlobalSearch.setTitleColor(UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0), for: .normal)
        }
        btnInviteFriendSearch.setTitleColor(UIColor.darkText, for: .normal)
        
        txtSearch.text = nil
        txtSearch.resignFirstResponder()
        
        tblView.reloadData()
    }
    
    @IBAction func ActionInviteFriendSearch(_ sender: UIButton)
    {
        if UserDefaults.standard.object(forKey: "InvitePopup") as! String == "1"
        {
            UserDefaults.standard.set("2", forKey: "InvitePopup")
            UserDefaults.standard.synchronize()
            let alertContrl = UIAlertController(title: "Reminder:", message: "Members must be registered with heyoo before you can invite them to share events or calendars.", preferredStyle: .alert)
            alertContrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertContrl, animated: true, completion: nil)
        }
        
        
        isSearchType = true
        
        if isMemberVC == "2"
        {
            btnInviteFriendSearch.setTitleColor(postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String), for: .normal)
        }
        else
        {
            btnInviteFriendSearch.setTitleColor(UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0), for: .normal)
        }
        btnGlobalSearch.setTitleColor(UIColor.darkText, for: .normal)
        
        txtSearch.text = nil
        txtSearch.resignFirstResponder()
        self.lblNoUserFound.isHidden = true
        tblView.reloadData()
    }
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        delegate?.setSelectedInvitedPeople(selectInvite: arrInvitedPeople)
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func ActionInviteButton(sender:UIButton)
    {
        if isSearchType == false
        {
            let dicContact = arrGlobalSearchList[sender.tag] as! NSDictionary
            
            if sender.isSelected == true
            {
                for i in (0..<arrInvitedPeopleTemp.count)
                {
                    let dicTemp = arrInvitedPeopleTemp[i] as! NSDictionary
                    
                    if dicTemp["UserID"] as! String == dicContact["UserID"] as! String
                    {
                        arrInvitedPeopleTemp.removeObject(at: i)
                        break
                    }
                }
            }
            else
            {
                arrInvitedPeopleTemp.add(dicContact)
            }
            tblView.reloadData()
        }
        else
        {
            var dicContact = NSDictionary()
            if searchActive
            {
                if filtered.count == 0
                {
                    dicContact = arrFinalContactList[sender.tag] as! NSDictionary
                }
                else
                {
                    dicContact = filtered[sender.tag] as! NSDictionary
                }
            }
            else
            {
                dicContact = arrFinalContactList[sender.tag] as! NSDictionary
            }
            
            if dicContact["Heyoo"] as! String == "1"
            {
                if (MFMessageComposeViewController.canSendText())
                {
                    let controller = MFMessageComposeViewController()
                    controller.body = "Please click on the link to download the Heyoo App. https://itunes.apple.com/us/app/heyoo-global-calendar/id1339563730?ls=1&mt=8"
                    let MobNumVar = dicContact["Mobile"]
                    controller.recipients = [MobNumVar as! String]
                    controller.messageComposeDelegate = self
                    self.present(controller, animated: true, completion: nil)
                }
            }
            else
            {
                if sender.isSelected == true
                {
                    for i in (0..<arrInvitedPeopleTemp.count)
                    {
                        let dicTemp = arrInvitedPeopleTemp[i] as! NSDictionary
                        
                        if dicTemp["UserID"] as! String == dicContact["UserID"] as! String
                        {
                            arrInvitedPeopleTemp.removeObject(at: i)
                            break
                        }
                    }
                }
                else
                {
                    arrInvitedPeopleTemp.add(dicContact)
                }
                tblView.reloadData()
            }
        }
        
    }
    
    // ********** MessageUI Delegate Methods ********** //
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    // ********** UITableView Delegate And DataSource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if isSearchType == false
        {
            return arrGlobalSearchList.count
        }
        else
        {
            if searchActive
            {
                if filtered.count == 0
                {
                    return arrFinalContactList.count
                }
                else
                {
                    return filtered.count
                }
            }
            else
            {
                return arrFinalContactList.count
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if isSearchType == false
        {
            let cell : SocialInviteTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! SocialInviteTblCell
            
            let dicGlobal = arrGlobalSearchList[indexPath.row] as! NSDictionary
            
            cell.lblFullName.text = dicGlobal["FullName"] as? String
            cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
            
            if isMemberVC == "2"
            {
                cell.btnInvite.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
            }
            else
            {
                cell.btnInvite.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            }
            cell.btnInvite.layer.borderColor = UIColor.clear .cgColor
            cell.btnInvite.layer.borderWidth = 1.0
            cell.btnInvite.setTitleColor(UIColor.white, for: .normal)
            cell.imgViewIcon.image = #imageLiteral(resourceName: "iconHeyoo")
            cell.lblUserType.text = "\(dicGlobal["City"] as! String), \(dicGlobal["Country"] as! String)"
            
            let strProPicURL = dicGlobal["ProfileImage"] as! String
            cell.imgViewProPic.sd_setImage(with: URL(string : strProPicURL), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            
            if arrInvitedPeopleTemp.count != 0
            {
                for dicTempCheck in arrInvitedPeopleTemp
                {
                    let dicTemp = dicTempCheck as! NSDictionary
                    let strSelectedU_ID = dicTemp["UserID"] as! String
                    let strNewU_ID = dicGlobal["UserID"] as! String
                    
                    if strSelectedU_ID == strNewU_ID
                    {
                        cell.btnInvite.isSelected = true
                        cell.btnInvite.layer.borderColor = UIColor.clear .cgColor
                        
                        if isMemberVC == "2"
                        {
                            cell.btnInvite.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
                        }
                        else
                        {
                            cell.btnInvite.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
                        }
                        
                        break
                    }
                    else
                    {
                        cell.btnInvite.isSelected = false
                        cell.btnInvite.backgroundColor = UIColor.white
                        cell.btnInvite.layer.borderColor = UIColor.gray .cgColor
                        cell.btnInvite.layer.borderWidth = 1.0
                        cell.btnInvite.setTitleColor(UIColor.black, for: .normal)
                        
                    }
                }
            }
            else
            {
                cell.btnInvite.isSelected = false
                cell.btnInvite.backgroundColor = UIColor.white
                cell.btnInvite.layer.borderColor = UIColor.gray .cgColor
                cell.btnInvite.layer.borderWidth = 1.0
                cell.btnInvite.setTitleColor(UIColor.black, for: .normal)
            }
            
            cell.btnInvite.tag = indexPath.row
            cell.btnInvite.addTarget(self, action: #selector(ActionInviteButton(sender:)), for: UIControlEvents.touchUpInside)
            
            cell .selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        }
        else
        {
            let cell : SocialInviteTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! SocialInviteTblCell
            
            var dicContact = NSDictionary()
            
            
            if searchActive
            {
                if filtered.count == 0
                {
                    dicContact = arrFinalContactList[indexPath.row] as! NSDictionary
                }
                else
                {
                    dicContact = filtered[indexPath.row] as! NSDictionary
                }
            }
            else
            {
                dicContact = arrFinalContactList[indexPath.row] as! NSDictionary
            }
            print(dicContact)
            
            cell.lblFullName.text = (dicContact["FullName"] as! String)
            cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
            
            if dicContact["Heyoo"] as! String == "1"
            {
                cell.btnInvite.backgroundColor = UIColor.white
                cell.btnInvite.layer.borderColor = UIColor.gray .cgColor
                cell.btnInvite.layer.borderWidth = 1.0
                cell.btnInvite.setTitleColor(UIColor.black, for: .normal)
                cell.imgViewIcon.image = #imageLiteral(resourceName: "iconContact")
                cell.lblUserType.text = (dicContact["Mobile"] as! String)
                
                let lblNameInitialize = UILabel()
                lblNameInitialize.frame.size = CGSize(width: 50.0, height: 50.0)
                lblNameInitialize.textColor = UIColor.white
                let txtFieldTempName = UITextField()
                txtFieldTempName.text = dicContact["FullName"] as? String
                lblNameInitialize.text = String(txtFieldTempName.text!.characters.first!)
                lblNameInitialize.textAlignment = NSTextAlignment.center
                lblNameInitialize.backgroundColor = UIColor.gray
                
                UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
                lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
                cell.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
            }
            else
            {
                if isMemberVC == "2"
                {
                    cell.btnInvite.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
                    cell.btnInvite.alpha = 1.0
                }
                else
                {
                    cell.btnInvite.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
                    
                }
                
                cell.btnInvite.layer.borderColor = UIColor.clear .cgColor
                cell.btnInvite.layer.borderWidth = 1.0
                cell.btnInvite.setTitleColor(UIColor.white, for: .normal)
                cell.imgViewIcon.image = #imageLiteral(resourceName: "iconHeyoo")
                cell.lblUserType.text = "Heyoo Member"
                
                let strProPicURL = dicContact["ProfileImage"] as! String
                cell.imgViewProPic.sd_setImage(with: URL(string : strProPicURL), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                
                if arrInvitedPeopleTemp.count != 0
                {
                    for dicTempCheck in arrInvitedPeopleTemp
                    {
                        let dicTemp = dicTempCheck as! NSDictionary
                        let strSelectedU_ID = dicTemp["UserID"] as! String
                        let strNewU_ID = dicContact["UserID"] as! String
                        
                        if strSelectedU_ID == strNewU_ID
                        {
                            cell.btnInvite.isSelected = true
                            
                            
                            if isMemberVC == "2"
                            {
                                cell.btnInvite.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
                                cell.btnInvite.alpha = 0.5
                            }
                            else
                            {
                                cell.btnInvite.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 0.5)
                            }
                            
                            break
                        }
                        else
                        {
                            cell.btnInvite.isSelected = false
                            if isMemberVC == "2"
                            {
                                cell.btnInvite.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
                                cell.btnInvite.alpha = 1.0
                            }
                            else
                            {
                                cell.btnInvite.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
                            }
                        }
                    }
                }
                else
                {
                    cell.btnInvite.isSelected = false
                    
                    if isMemberVC == "2"
                    {
                        cell.btnInvite.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
                        cell.btnInvite.alpha = 1.0
                    }
                    else
                    {
                        cell.btnInvite.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
                    }
                }
                
            }
            
            cell.btnInvite.tag = indexPath.row
            cell.btnInvite.addTarget(self, action: #selector(ActionInviteButton(sender:)), for: UIControlEvents.touchUpInside)
            
            cell .selectionStyle = UITableViewCellSelectionStyle.none
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
//        let cell = tblView.cellForRow(at: indexPath) as! SocialInviteTblCell
//
//        if cell.btnInvite.backgroundColor == UIColor.black
//        {
//            cell.btnInvite.backgroundColor = UIColor.orange
//        }
//        else
//        {
//            cell.btnInvite.backgroundColor = UIColor.black
//        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if isSearchType == false
        {
            return 0
        }
        else
        {
            return 30
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let cellHeader : SocialInviteTblCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! SocialInviteTblCell
        
        return cellHeader
    }
    
    // ********** UITextField Delegate Methods ********** //
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        searchActive = true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        searchActive = true
    }
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        if isSearchType == false
        {
            GlobalUserAutoCompleteSearchAPICall()
        }
        else
        {
            filtered = arrFinalContactList.filter({ (text) -> Bool in
                let dicContact = text as! NSDictionary
                let tmp: NSString = dicContact["FullName"] as! NSString
                let search = textField.text!
                let rang = tmp.range(of: search, options: .caseInsensitive)
                return rang.location != NSNotFound
            }) as! [NSDictionary] as NSArray
            
            if filtered.count == 0
            {
                searchActive = false
            }
            else
            {
                searchActive = true
            }
            tblView.reloadData()
        }
    }
    
    
    // ********** Contact Fetch Methods ********** //
    
    func fetchContactMethod()
    {
        FetchContacts = [CNContact]()
        
        let store = CNContactStore()
        store.requestAccess(for: .contacts, completionHandler: {
            granted, error in
            
            guard granted else {
                let alert = UIAlertController(title: "Can't access contact", message: "Please go to Settings -> heyoo to enable contact permission", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
                return
            }
            
            let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactPhoneNumbersKey] as [Any]
            let request = CNContactFetchRequest(keysToFetch: keysToFetch as! [CNKeyDescriptor])
            
            do {
                try store.enumerateContacts(with: request) {
                    (contact, cursor) -> Void in
                    self.FetchContacts.append(contact)
                }
            } catch let error {
                print("Fetch contact error: \(error)")
            }
            
            DispatchQueue.main.async {
                self.tblView.reloadData()
                
                self.ContactMatchListAPICall()
            }
        })
    }
    
    func ContactMatchListAPICall()
    {
        let arrContactListServer = NSMutableArray()
        
        for contact in self.FetchContacts
        {
            if contact.phoneNumbers.count != 0
            {
                let fullName = CNContactFormatter.string(from: contact, style: .fullName) ?? "No Name"
                let MobNumVar = (contact.phoneNumbers[0].value).value(forKey: "stringValue") as! String
                
                let dicContactTemp = NSMutableDictionary()
                dicContactTemp.setValue(fullName, forKey: "FullName")
                dicContactTemp.setValue(MobNumVar, forKey: "Mobile")
                
                arrContactListServer.add(dicContactTemp)
            }
        }
        
        if isTableRefresh == false
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
        }
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Contacts"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let jsonDataForContact: Data? = try? JSONSerialization.data(withJSONObject: arrContactListServer, options: [])
        let jsonStringForContact = String(data: jsonDataForContact ?? Data(), encoding: .utf8)
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Contacts":jsonStringForContact, "Val_IsDST":strDST, "Action":"Check"]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    print(dicLoginResponse)
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    self.refreshControl.endRefreshing()
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let arrContactList = dicLoginResponse?["data"] as! NSArray
                        let dataStore = NSKeyedArchiver.archivedData(withRootObject: arrContactList)
                        
                        UserDefaults.standard.set(dataStore, forKey: "ContactList")
                        UserDefaults.standard.synchronize()
                        
                        let getDataStored = UserDefaults.standard.data(forKey: "ContactList")
                        self.arrFinalContactList = NSKeyedUnarchiver.unarchiveObject(with: getDataStored!) as! NSArray
                        print(self.arrFinalContactList)
                        
//                        self.arrFinalContactList = dicLoginResponse?["data"] as! NSArray
                        
                        self.tblView.reloadData()
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                self.refreshControl.endRefreshing()
                
                print(encodingError)
            }
        }
    }
    
    
    // ********** Global AutoComplete API Call *********** //
    
    func GlobalUserAutoCompleteSearchAPICall()
    {
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Search"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
//        let strSearchText = txtSearch.text
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_User":"\(txtSearch.text ?? "")", "Val_IsDST":strDST, "Val_Start":"0", "Action":"GetAllUsers", "Val_Userid":strUserID]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicGlobalSearchResponse = response.result.value as? [String: Any]
                    
                    if dicGlobalSearchResponse?["status"] as? String == "success"
                    {
                        
                        if self.isMemberVC == "2"
                        {
                            let arrGlobalTemp = dicGlobalSearchResponse?["data"] as! NSArray
                            let arrUserIDAdded = NSMutableArray()
                            
                            for i in (0..<self.arrInvitedPeople.count)
                            {
                                let dicGlob = self.arrInvitedPeople[i] as! NSDictionary
                                arrUserIDAdded.add(dicGlob["UserID"] as! String)
                            }
                            
                            let arrFinalGlobal = NSMutableArray()
                            
                            for j in (0..<arrGlobalTemp.count)
                            {
                                let dicGlobTemp = arrGlobalTemp[j] as! NSDictionary
                                let strGlobUserID = dicGlobTemp["UserID"] as! String
                                
                                if arrUserIDAdded.contains(strGlobUserID)
                                {
                                    
                                }
                                else
                                {
                                    arrFinalGlobal.add(arrGlobalTemp[j] as! NSDictionary)
                                }
                            }
                            
                            self.arrGlobalSearchList = arrFinalGlobal as NSArray
                            
                        }
                        else
                        {
                            self.arrGlobalSearchList = dicGlobalSearchResponse?["data"] as! NSArray
                            print(self.arrGlobalSearchList)
                        }
                        self.lblNoUserFound.isHidden = true
                        self.tblView.reloadData()
                        
                    }
                    else if dicGlobalSearchResponse?["status"] as? String == "error"
                    {
                        self.lblNoUserFound.isHidden = false
                        self.lblNoUserFound.text = dicGlobalSearchResponse?["message"] as? String
                        self.arrGlobalSearchList = NSArray()
                        self.tblView.reloadData()
                        
//                        let alertCntrl = UIAlertController(title: nil, message: (dicGlobalSearchResponse?["message"] as? String), preferredStyle: .alert)
//                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                    else
                    {
                        self.lblNoUserFound.isHidden = false
                        self.lblNoUserFound.text = "No members found."
                        self.arrGlobalSearchList = NSArray()
                        self.tblView.reloadData()
                    }
                })
                
            case .failure(let encodingError):
                
                print(encodingError)
            }
        }
    }
    
    
    // ********** Add Member Calendar API Call ********** //
    
    func addMemberCalendarAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Members"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let arrAllPeopleUserID = NSMutableArray()
            for dicTempCheck in arrInvitedPeopleTemp
            {
                let dicTemp = dicTempCheck as! NSDictionary
                let strSelectedU_ID = dicTemp["UserID"] as! String
                
                arrAllPeopleUserID.add(strSelectedU_ID)
            }
            
            let jsonDataForInvitePeople: Data? = try? JSONSerialization.data(withJSONObject: arrAllPeopleUserID, options: [])
            let jsonStringForInvitePeople = String(data: jsonDataForInvitePeople ?? Data(), encoding: .utf8)
            
            let calID = dicCalData["CalendarID"] as! String
            
            let strMasterUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Userid":jsonStringForInvitePeople, "Val_IsDST":strDST,"Val_Calendarid":calID, "Val_Masterid":strMasterUserID, "Action":"Add"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.description)
                        
                        let dicAddMemberCalResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicAddMemberCalResponse?["status"] as? String == "success"
                        {
                            self.navigationController?.popViewController(animated: true)
                            
                        }
                        else if dicAddMemberCalResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicAddMemberCalResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
            
    }
    
    
    // ********** Tableview Pull To Refresh Method ********** //
    
    @objc func refreshContactData()
    {
        isTableRefresh = true
        fetchContactMethod()
    }
    
    func postCalendarColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    
}







































