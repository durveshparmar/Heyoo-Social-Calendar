//
//  SocialInviteTblCell.swift
//  heyoo
//
//  Created by Intorque LLP on 25/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialInviteTblCell: UITableViewCell {
    @IBOutlet weak var lblFullName: UITextField!
    @IBOutlet weak var btnInvite: UIButton!
    @IBOutlet weak var imgViewIcon: UIImageView!
    @IBOutlet weak var lblUserType: UITextField!
    @IBOutlet weak var imgViewProPic: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
