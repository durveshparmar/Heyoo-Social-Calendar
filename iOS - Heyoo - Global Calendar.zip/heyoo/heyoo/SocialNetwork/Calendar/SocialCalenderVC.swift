//
//  SocialCalenderVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 05/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire

class SocialCalenderVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var btnCreateCal: UIButton!
    @IBOutlet weak var lblInterNetPreview: UILabel!
    
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var tblCalList: UITableView!
    
    var arrCalendarData = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        getProfileImageDocumentDirectory()
        getAllCalendarAPICall()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    // ********** UITableview Delegate And Datasource Methods ********* //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrCalendarData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SocialCalTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! SocialCalTblCell
        
        let dicCalendar = arrCalendarData[indexPath.row] as! NSDictionary
        print(dicCalendar)
        cell.lblCalendarName.text = dicCalendar.value(forKey: "Name") as? String
        cell.lblShare.text = dicCalendar.value(forKey: "MemberCount") as? String
        cell.viewCalColor.backgroundColor = postCalendarColorInTableCell(strColor: dicCalendar.value(forKey: "Color") as! String)
        
        cell.imgViewShare.image = cell.imgViewShare.image!.withRenderingMode(.alwaysTemplate)
        cell.imgViewShare.tintColor = postCalendarColorInTableCell(strColor: dicCalendar.value(forKey: "Color") as! String)
        
        let arrMemberList = dicCalendar["Members"] as! NSArray
        let arrInviteImages = NSMutableArray()
        
        for i in (0..<arrMemberList.count)
        {
            let dicMember = arrMemberList[i] as! NSDictionary
            print(dicMember)
            let strImgURL = dicMember["ProfileImage"] as! String
            
            arrInviteImages.add(strImgURL)
        }
        print(arrInviteImages)
        
        
        cell.imgView2.layer.cornerRadius = cell.imgView2.frame.size.width/2
        cell.imgView3.layer.cornerRadius = cell.imgView3.frame.size.width/2
        cell.imgView4.layer.cornerRadius = cell.imgView4.frame.size.width/2
        
        if arrInviteImages.count == 0
        {
            cell.imgView4.image = nil
            cell.imgView3.image = nil
            cell.imgView2.image = nil
            cell.imgView4.backgroundColor = UIColor.clear
            cell.viewInviteUsers.isHidden = true
        }
        else if arrInviteImages.count == 1
        {
            cell.imgView4.sd_setImage(with: URL(string : arrInviteImages[0] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            cell.imgView3.image = nil
            cell.imgView2.image = nil
            cell.viewInviteUsers.isHidden = false
        }
        else if arrInviteImages.count == 2
        {
            cell.imgView4.sd_setImage(with: URL(string : arrInviteImages[0] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            cell.imgView3.sd_setImage(with: URL(string : arrInviteImages[1] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            cell.imgView2.image = nil
            cell.viewInviteUsers.isHidden = false
        }
        else
        {
            if arrInviteImages.count > 3
            {
                cell.imgView4.image = #imageLiteral(resourceName: "iconGrayDots")
                cell.imgView3.sd_setImage(with: URL(string : arrInviteImages[0] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                cell.imgView2.sd_setImage(with: URL(string : arrInviteImages[1] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                cell.viewInviteUsers.isHidden = false
            }
            else
            {
                if arrInviteImages.count != 0
                {
                    cell.imgView4.sd_setImage(with: URL(string : arrInviteImages[0] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    cell.imgView3.sd_setImage(with: URL(string : arrInviteImages[1] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    cell.imgView2.sd_setImage(with: URL(string : arrInviteImages[2] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    cell.viewInviteUsers.isHidden = false
                }
            }
        }
        
        
        
        cell.setEditing(true, animated: true)
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let customCalVC = self.storyboard?.instantiateViewController(withIdentifier: "CustomCalendarVC") as! CustomCalendarVC
        let dicCalendar = arrCalendarData[indexPath.row] as! NSDictionary
        print(dicCalendar)
        let dicCalendarTemp = dicCalendar.mutableCopy()
        customCalVC.dicCalData = dicCalendarTemp as! NSMutableDictionary
        self.navigationController?.pushViewController(customCalVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        let dicCalendar = arrCalendarData[indexPath.row] as! NSDictionary
        print(dicCalendar)
        
        let strIsShared = dicCalendar["Shared"] as! String
        if strIsShared == "1"
        {
            deleteCalendarAPICall(indexPath: indexPath)
        }
        else
        {
//            let strIsAdmin = dicCalendar["Admin"] as! String
//            if strIsAdmin == "1"
//            {
                let alertCntrl = UIAlertController(title: "Warning", message: "Sorry but this calendar may only be deleted by the creator.", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alertCntrl, animated: true, completion: nil)
//            }
//            else
//            {
//                deleteCalendarAPICall(indexPath: indexPath)
//            }
        }
    }
    
    // ********** All Button Actions ********** //
    
    @IBAction func ActionCreateCalendar(_ sender: UIButton)
    {
        let createCalVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialCreateCalendar") as! SocialCreateCalendar
        self.navigationController?.pushViewController(createCalVC, animated: true)
    }
    
    // ********** Get Profile Picture Document Directory ********** //
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
    
    // ********** Gel All Calendar Api Call ********** //
    
    func getAllCalendarAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
//                self.getAllCalendarAPICall()
            }))
            self.present(networkAlert, animated: true, completion: nil)
            
            lblInterNetPreview.isHidden = false
        }
        else
        {
            lblInterNetPreview.isHidden = true
            
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            print(strUserID)
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Action":"GetAllCalendars"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicGetAllCalendar = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicGetAllCalendar?["status"] as? String == "success"
                        {
                            self.arrCalendarData = dicGetAllCalendar?["data"] as! NSArray
                            self.tblCalList.reloadData()
                        }
                        else if dicGetAllCalendar?["status"] as? String == "error"
                        {
                            self.arrCalendarData = NSArray()
                            self.tblCalList.reloadData()
                            
                            let alertCntrl = UIAlertController(title: nil, message: (dicGetAllCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** Delete Calendar Api Call ********** //
    
    func deleteCalendarAPICall(indexPath: IndexPath)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
                
                self.deleteCalendarAPICall(indexPath: indexPath)
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let dicCalendar = arrCalendarData[indexPath.row] as! NSDictionary
            let strCalID = dicCalendar.value(forKey: "CalendarID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":strCalID, "Action":"Delete"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDeleteCalendar = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDeleteCalendar?["status"] as? String == "success"
                        {
                            self.getAllCalendarAPICall()
                            
                        }
                        else if dicDeleteCalendar?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDeleteCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
        
    }
    
    func postCalendarColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
}















