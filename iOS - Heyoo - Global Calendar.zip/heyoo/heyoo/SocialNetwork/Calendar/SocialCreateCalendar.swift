//
//  SocialCreateCalendar.swift
//  heyoo
//
//  Created by Intorque LLP on 18/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire

class SocialCreateCalendar: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource, invitePeopleSelectProtocol {
    @IBOutlet weak var btnPublish: UIButton!
    @IBOutlet weak var tblShareCal: UITableView!
    @IBOutlet weak var viewNavBackground: UIView!
    @IBOutlet weak var viewShareCalList: UIView!
    @IBOutlet weak var viewCalNameBack: UIView!
    @IBOutlet weak var collectColor: UICollectionView!
    @IBOutlet weak var txtCalendarName: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var arrColor = NSArray()
    var strSelectColor = String()
    var strSelectTick = String()
    var arrSharePeople = NSMutableArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewCalNameBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalNameBack.layer.shadowOpacity = 0.4
        viewCalNameBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalNameBack.layer.shadowRadius = 3
        
        viewShareCalList.layer.shadowColor = UIColor.lightGray.cgColor
        viewShareCalList.layer.shadowOpacity = 0.4
        viewShareCalList.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewShareCalList.layer.shadowRadius = 3
        
        btnPublish.layer.shadowColor = UIColor.lightGray.cgColor
        btnPublish.layer.shadowOpacity = 0.4
        btnPublish.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPublish.layer.shadowRadius = 5.0
        
        arrColor = [customColor.color1, customColor.color2, customColor.color3, customColor.color4, customColor.color5, customColor.color6, customColor.color7]
        
        txtCalendarName.becomeFirstResponder()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionSharePeople(_ sender: UIButton)
    {
        let inviteVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialInvitePeopleVC") as! SocialInvitePeopleVC
        inviteVC.arrInvitedPeople = arrSharePeople
        inviteVC.delegate = self
        self.navigationController?.pushViewController(inviteVC, animated: true)
    }
    
    @IBAction func ActionPublishCal(_ sender: UIButton)
    {
        PublishCalendarAPICall()
    }
    
    // ********** Invite People Selection Protocol Methods ********** //
    
    func setSelectedInvitedPeople(selectInvite: NSMutableArray)
    {
        arrSharePeople = NSMutableArray()
        for i in (0..<selectInvite.count)
        {
            arrSharePeople.add(selectInvite[i])
        }
        
        
//        arrSharePeople = selectInvite
        tblShareCal.reloadData()
    }
    
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrSharePeople.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : UITableViewCell = (tableView.dequeueReusableCell(withIdentifier: "cell"))!
        
        let dicPeople = arrSharePeople[indexPath.row] as! NSDictionary
        cell.textLabel?.text = (dicPeople["FullName"] as! String)
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.setEditing(true, animated: true)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        arrSharePeople.removeObject(at: indexPath.row)
        tblShareCal.reloadData()
    }
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrColor.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellColor : collectColorCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! collectColorCell
        
        cellColor.viewColor.backgroundColor = arrColor[indexPath.item] as? UIColor
        
        if strSelectTick == "\(indexPath.item)"
        {
            cellColor.imgViewTick.isHidden = false
        }
        else
        {
            cellColor.imgViewTick.isHidden = true
        }
        
        return cellColor
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectColor.frame.size.height, height: collectColor.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        viewNavBackground.backgroundColor = arrColor[indexPath.item] as? UIColor
        strSelectColor = "\(indexPath.item+1)"
        strSelectTick = "\(indexPath.row)"
        collectColor.reloadData()
    }
    
    // ********** Publish Calendar API Call ********** //
    
    func PublishCalendarAPICall()
    {
        if txtCalendarName.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Enter Calendar Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if strSelectColor.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Choose Calendar Color.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            if !Reachability.isConnectedToNetwork()
            {
                let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
                networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
                    
                    self.PublishCalendarAPICall()
                }))
                self.present(networkAlert, animated: true, completion: nil)
            }
            else
            {
                MBProgressHUD.showAdded(to: self.view, animated: true)
                
                let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
                let strMainURL: String = "Calendar/Details"
                let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
                
                
                let arrAllPeopleUserID = NSMutableArray()
                for dicTempCheck in arrSharePeople
                {
                    let dicTemp = dicTempCheck as! NSDictionary
                    let strSelectedU_ID = dicTemp["UserID"] as! String
                    
                    arrAllPeopleUserID.add(strSelectedU_ID)
                }
                
                let jsonDataForInvitePeople: Data? = try? JSONSerialization.data(withJSONObject: arrAllPeopleUserID, options: [])
                let jsonStringForInvitePeople = String(data: jsonDataForInvitePeople ?? Data(), encoding: .utf8)
                
                
                let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
                
                var strShared = String()
                if arrAllPeopleUserID.count == 0
                {
                    strShared = "1"
                }
                else
                {
                    strShared = "2"
                }
                
                let strTimezone = "\(TimeZone.current.secondsFromGMT())"
                let strDST = UserDefaults.standard.value(forKey: "DST") as! String
                
                let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_SharedUsers":jsonStringForInvitePeople,"Val_Color":strSelectColor, "Val_Userid":strUserID, "Val_Name":txtCalendarName.text! as String, "Val_Shared":strShared, "Action":"Add"]
                
                Alamofire.upload(multipartFormData: { (multipartFormData) in
                    
                    for (key,value) in parameters {
                        multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                    }
                    
                }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                    
                    switch encodingResult {
                        
                    case .success(let upload, _, _):
                        upload.responseJSON(completionHandler: { (response) in
                            print(response.description)
                            
                            let dicCreatCalResponse = response.result.value as? [String: Any]
                            
                            MBProgressHUD.hide(for: self.view, animated: true)
                            
                            if dicCreatCalResponse?["status"] as? String == "success"
                            {
                                self.navigationController?.popViewController(animated: true)
                                
                            }
                            else if dicCreatCalResponse?["status"] as? String == "error"
                            {
                                let alertCntrl = UIAlertController(title: nil, message: (dicCreatCalResponse?["message"] as? String), preferredStyle: .alert)
                                alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                self.present(alertCntrl, animated: true, completion: nil)
                            }
                        })
                        
                    case .failure(let encodingError):
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        print(encodingError)
                    }
                }
            }
        }
    }
    
}






























