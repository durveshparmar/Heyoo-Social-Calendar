//
//  CustomCalendarVC.swift
//  heyoo
//
//  Created by Intorque LLP on 13/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Quickblox

class CustomCalendarVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate, FSCalendarDataSource, FSCalendarDelegate, FSCalendarDelegateAppearance, calendarDraftEventCreateProtocol {
    @IBOutlet weak var viewNav: UIView!
    @IBOutlet weak var lblCalenderHeader: UILabel!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var viewCalenderBackCover: UIView!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var viewMore: UIView!
    @IBOutlet weak var imgViewCheckMonthView: UIImageView!
    @IBOutlet weak var imgViewCheckWeekView: UIImageView!
    @IBOutlet weak var btnMembers: UIButton!
    @IBOutlet weak var lblCalName: UILabel!
    @IBOutlet weak var viewCalNave: UIView!
    @IBOutlet weak var btnUnpubEvent: UIButton!
    @IBOutlet weak var btnEditCalendar: UIButton!
    @IBOutlet weak var btnCreateEvent: UIButton!
    @IBOutlet weak var lblUnpublishBadge: UILabel!
    
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
//    var strScopeCheck = String()
    var strSelectedDate = String()
    var strIsNotificationScreen = String()
    
    
    
    
    var dicCalData = NSMutableDictionary()
    var dicEventList = NSMutableDictionary()
    var arrEventListDateKey = NSMutableArray()
    
    
    var viewPopup = UIView()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        print(dicCalData)
        
        if dicCalData["UserProfileImage"] != nil
        {
            imgViewProPic.sd_setImage(with: URL(string : dicCalData["UserProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        }
        
        
        lblUnpublishBadge.layer.cornerRadius = lblUnpublishBadge.frame.size.height / 2
        lblUnpublishBadge.isHidden = true
       
        viewCalenderBackCover.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalenderBackCover.layer.shadowOpacity = 0.4
        viewCalenderBackCover.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalenderBackCover.layer.shadowRadius = 3
        
        viewMore.layer.shadowColor = UIColor.lightGray.cgColor
        viewMore.layer.shadowOpacity = 0.4
        viewMore.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewMore.layer.shadowRadius = 3
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        
        let currentDate = Date()
        lblCalenderHeader.text = self.dateFormatter.string(from: currentDate)
        
        let calendarGesture = UIPanGestureRecognizer(target: calendar, action: #selector(calendar.handleScopeGesture(_:)));
        calendar.addGestureRecognizer(calendarGesture)
        let calendarBackCoverGesture = UIPanGestureRecognizer(target: calendar, action: #selector(calendar.handleScopeGesture(_:)));
        viewCalenderBackCover.addGestureRecognizer(calendarBackCoverGesture)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        print(dicCalData)
        strSelectedDate = ""
        
        let strIsShared = dicCalData["Shared"] as! String
        if strIsShared == "1"
        {
            btnUnpubEvent.isHidden = false
            btnEditCalendar.isEnabled = true
            btnMembers.isEnabled = true
            btnCreateEvent.isHidden = false
            
            let unpubBadge = dicCalData["UnpublishedCount"] as! String
            if unpubBadge == "0"
            {
                self.lblUnpublishBadge.isHidden = true
            }
            else
            {
                self.lblUnpublishBadge.isHidden = false
                self.lblUnpublishBadge.text = "\(unpubBadge)"
            }
        }
        else
        {
            let strIsAdmin = dicCalData["Admin"] as! String
            if strIsAdmin == "1"
            {
                btnUnpubEvent.isHidden = true
                btnEditCalendar.isEnabled = true
                btnMembers.isEnabled = true
                btnCreateEvent.isHidden = true
            }
            else
            {
                btnUnpubEvent.isHidden = false
                btnEditCalendar.isEnabled = true
                btnMembers.isEnabled = true
                btnCreateEvent.isHidden = false
                
                let unpubBadge = dicCalData["UnpublishedCount"] as! String
                if unpubBadge == "0"
                {
                    self.lblUnpublishBadge.isHidden = true
                }
                else
                {
                    self.lblUnpublishBadge.isHidden = false
                    self.lblUnpublishBadge.text = "\(unpubBadge)"
                }
            }
        }
        
        
        
        if self.calendar.scope == .month
        {
            imgViewCheckMonthView.isHidden = false
            imgViewCheckWeekView.isHidden = true
            
//            strScopeCheck = "month"
        }
        else
        {
            imgViewCheckMonthView.isHidden = true
            imgViewCheckWeekView.isHidden = false
            
//            strScopeCheck = "week"
        }
        
        
        viewCalNave.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        lblCalName.text = dicCalData["Name"] as? String
        
        imgViewCheckMonthView.image = imgViewCheckMonthView.image!.withRenderingMode(.alwaysTemplate)
        imgViewCheckMonthView.tintColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        
        imgViewCheckWeekView.image = imgViewCheckWeekView.image!.withRenderingMode(.alwaysTemplate)
        imgViewCheckWeekView.tintColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        
        btnMembers.setTitle("Members (\(dicCalData["MemberCount"] ?? "0"))", for: .normal)
        
        calendar.appearance.eventDefaultColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        calendar.appearance.eventSelectionColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        calendar.reloadData()
        
//        getProfileImageDocumentDirectory()
        
        
        let calTemp = Calendar.current
        let year = calTemp.component(.year, from: calendar.currentPage)
        let month = calTemp.component(.month, from: calendar.currentPage)
        print(year)
        print(month)
        getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
    }
    
    // ********** Calendar Update Delegate Methods **********
    func setUpdatedCalendarData(dicCalendar: NSMutableDictionary)
    {
        dicCalData = dicCalendar
        
        let strIsShared = dicCalData["Shared"] as! String
        if strIsShared == "1"
        {
            btnUnpubEvent.isHidden = false
            btnEditCalendar.isEnabled = true
            btnMembers.isEnabled = true
            btnCreateEvent.isHidden = false
            
            let unpubBadge = dicCalData["UnpublishedCount"] as! String
            if unpubBadge == "0"
            {
                self.lblUnpublishBadge.isHidden = true
            }
            else
            {
                self.lblUnpublishBadge.isHidden = false
                self.lblUnpublishBadge.text = "\(unpubBadge)"
            }
        }
        else
        {
            let strIsAdmin = dicCalData["Admin"] as! String
            if strIsAdmin == "1"
            {
                btnUnpubEvent.isHidden = true
                btnEditCalendar.isEnabled = true
                btnMembers.isEnabled = true
                btnCreateEvent.isHidden = true
            }
            else
            {
                btnUnpubEvent.isHidden = false
                btnEditCalendar.isEnabled = true
                btnMembers.isEnabled = true
                btnCreateEvent.isHidden = false
                
                let unpubBadge = dicCalData["UnpublishedCount"] as! String
                if unpubBadge == "0"
                {
                    self.lblUnpublishBadge.isHidden = true
                }
                else
                {
                    self.lblUnpublishBadge.isHidden = false
                    self.lblUnpublishBadge.text = "\(unpubBadge)"
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    
    // ********** All Button Action ********** //
    
    @IBAction func ActionUnpublishEvent(_ sender: UIButton)
    {
        let unpubDraftVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialUnpublishDraftVC") as! SocialUnpublishDraftVC
        unpubDraftVC.strCheckVC = "1"
        unpubDraftVC.dicCustCalData = dicCalData
        self.navigationController?.pushViewController(unpubDraftVC, animated: true)
    }
    
    @IBAction func ActionCreateEvent(_ sender: UIButton)
    {
        let newEvent = self.storyboard?.instantiateViewController(withIdentifier: "SocialNewEvent") as! SocialNewEvent
        newEvent.isCustCal = "2"
        newEvent.dicCustCalData = dicCalData
        newEvent.delegate = self
        self.navigationController?.pushViewController(newEvent, animated: true)
    }
    
    @IBAction func ActionCalNext(_ sender: UIButton)
    {
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = 1
        }
        else
        {
            dateComponents.weekOfMonth = 1
        }
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    @IBAction func ActionCalPrev(_ sender: UIButton)
    {
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = -1
        }
        else
        {
            dateComponents.weekOfMonth = -1
        }
        
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    @IBAction func ActionMoreButton(_ sender: UIButton)
    {
        viewMore.isHidden = false
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.0)
        viewPopup.addSubview(viewMore)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
    }
    
    @IBAction func ActionMonthView(_ sender: UIButton)
    {
        self.calendar.setScope(.month, animated: true)
        
        imgViewCheckMonthView.isHidden = false
        imgViewCheckWeekView.isHidden = true
        
        viewPopup.isHidden = true
        viewMore.isHidden = true
    }
    
    @IBAction func ActionListView(_ sender: UIButton)
    {
        self.calendar.setScope(.week, animated: true)
        
        imgViewCheckMonthView.isHidden = true
        imgViewCheckWeekView.isHidden = false
        
        viewPopup.isHidden = true
        viewMore.isHidden = true
    }
    
    @IBAction func ActionEditCalendar(_ sender: UIButton)
    {
        let strIsShared = dicCalData["Shared"] as! String
        if strIsShared == "1"
        {
            viewPopup.isHidden = true
            viewMore.isHidden = true
            
            let editCalVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEditCalendarVC") as! SocialEditCalendarVC
            editCalVC.dicCalData = dicCalData
            self.navigationController?.pushViewController(editCalVC, animated: true)
        }
        else
        {
            let strIsAdmin = dicCalData["Admin"] as! String
            if strIsAdmin == "1"
            {
                let alertCntrl = UIAlertController(title: "Warning", message: "Only an Administrator can edit this calendar.", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alertCntrl, animated: true, completion: nil)
            }
            else
            {
                viewPopup.isHidden = true
                viewMore.isHidden = true
                
                let editCalVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEditCalendarVC") as! SocialEditCalendarVC
                editCalVC.dicCalData = dicCalData
                self.navigationController?.pushViewController(editCalVC, animated: true)
            }
        }
        
    }
    
    @IBAction func ActionMembers(_ sender: UIButton)
    {
        viewPopup.isHidden = true
        viewMore.isHidden = true
        
        let memberVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialCalendarMemberVC") as! SocialCalendarMemberVC
        memberVC.dicCalData = dicCalData
        self.navigationController?.pushViewController(memberVC, animated: true)
        
    }
    
    
    
    // ********** UITableViewDelegate And Datasource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if strSelectedDate != ""
        {
            return 1
        }
        else
        {
            return dicEventList.count
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            return arrEventSelectedDate.count
            
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[section]] as! NSArray
            return arrEventSectionWise.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : socialHomeTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! socialHomeTblCell
        
//        let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
//        let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        
        

        cell.lblEventName.text = dicPerticularEvent["EventTitle"] as? String
        var countImgAndVideo = dicPerticularEvent["EventVideos"] as! Int64
        cell.lblVideoCount.text = String(countImgAndVideo)
        countImgAndVideo = dicPerticularEvent["EventImages"] as! Int64
        cell.lblMessageCount.text = String(countImgAndVideo)
        cell.viewColor.backgroundColor = postCalendarColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)

        cell.imgImage.image = cell.imgImage.image!.withRenderingMode(.alwaysTemplate)
        cell.imgImage.tintColor = postCalendarColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)

        cell.imgVideo.image = cell.imgVideo.image!.withRenderingMode(.alwaysTemplate)
        cell.imgVideo.tintColor = postCalendarColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)

        let inFormatter = DateFormatter()
        inFormatter.dateFormat = "HH:mm:ss"
        let outFormatter = DateFormatter()
        outFormatter.dateFormat = "hh:mma"

        let inTime = dicPerticularEvent["EventStartTime"] as! String
        let date = inFormatter.date(from: inTime)!
        let outTime = outFormatter.string(from: date)
        cell.lblTime.text = outTime

        
        let arrInviteImages = dicPerticularEvent["EventMembers"] as! NSArray
        
        cell.imgView2.layer.cornerRadius = cell.imgView2.frame.size.width/2
        cell.imgView3.layer.cornerRadius = cell.imgView3.frame.size.width/2
        cell.imgView4.layer.cornerRadius = cell.imgView4.frame.size.width/2
        
        if arrInviteImages.count == 0
        {
            cell.imgView4.image = nil
            cell.imgView3.image = nil
            cell.imgView2.image = nil
            cell.imgView4.backgroundColor = UIColor.clear
            cell.viewInviteUsers.isHidden = true
        }
        else if arrInviteImages.count == 1
        {
            let dicImg0 = arrInviteImages[0] as! NSDictionary
            cell.imgView4.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            
            cell.imgView3.image = nil
            cell.imgView2.image = nil
            cell.viewInviteUsers.isHidden = false
        }
        else if arrInviteImages.count == 2
        {
            let dicImg0 = arrInviteImages[0] as! NSDictionary
            cell.imgView4.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            
            let dicImg1 = arrInviteImages[1] as! NSDictionary
            cell.imgView3.sd_setImage(with: URL(string : dicImg1["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            
            cell.imgView2.image = nil
            cell.viewInviteUsers.isHidden = false
        }
        else
        {
            if arrInviteImages.count > 3
            {
                cell.imgView4.image = #imageLiteral(resourceName: "iconGrayDots")
                
                let dicImg0 = arrInviteImages[0] as! NSDictionary
                cell.imgView3.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                
                let dicImg1 = arrInviteImages[1] as! NSDictionary
                cell.imgView2.sd_setImage(with: URL(string : dicImg1["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                cell.viewInviteUsers.isHidden = false
            }
            else
            {
                if arrInviteImages.count != 0
                {
                    let dicImg0 = arrInviteImages[0] as! NSDictionary
                    cell.imgView4.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    
                    let dicImg1 = arrInviteImages[1] as! NSDictionary
                    cell.imgView3.sd_setImage(with: URL(string : dicImg1["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    
                    let dicImg2 = arrInviteImages[2] as! NSDictionary
                    cell.imgView2.sd_setImage(with: URL(string : dicImg2["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    cell.viewInviteUsers.isHidden = false
                }
            }
        }
        
        cell.setEditing(true, animated: true)
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 25
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView : socialHomeHeaderViewCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! socialHomeHeaderViewCell
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        var strTempDate = String()
        if strSelectedDate != ""
        {
            strTempDate = strSelectedDate
        }
        else
        {
            strTempDate = arrEventListDateKey[section] as! String
        }
        
        
        let date = dateFormatter.date(from: strTempDate)
        headerView.lblDateTitle.text = self.dateFormatterHeader.string(from: date!)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        let viewFooter = UIView()
        viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
        viewFooter.backgroundColor = UIColor .white
        
        return viewFooter
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        var strEventDate = String()
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
            strEventDate = strSelectedDate
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            strEventDate = arrEventListDateKey[indexPath.section] as! String
        }
        
        print(dicPerticularEvent)
        ServicesManager.instance().chatService.fetchDialog(withID: (dicPerticularEvent["EventJID"] as? String)!) { (dialog) in
            
            print(dialog)
            
            if dialog != nil
            {
                let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
                eventDetailVC.dicEventDetPass = dicPerticularEvent
                eventDetailVC.arrMemberList = dicPerticularEvent["EventMembers"] as! NSArray
                eventDetailVC.dialog = dialog
                eventDetailVC.strGroupDate = strEventDate
                self.navigationController?.pushViewController(eventDetailVC, animated: true)
            }
            else
            {
                self.getDialogs(dicPerticularEvent: dicPerticularEvent)
            }
        }
    }
    
    func getDialogs(dicPerticularEvent:NSDictionary) {
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
            
        }, completion: { (response: QBResponse?) -> Void in
            
            guard response != nil && response!.isSuccess else {
                
                return
            }
            
            MBProgressHUD.hide(for: self.view, animated: true)
            
            ServicesManager.instance().chatService.fetchDialog(withID: (dicPerticularEvent["EventJID"] as? String)!) { (dialogFetch) in
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                
                let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
                eventDetailVC.dicEventDetPass = dicPerticularEvent
                eventDetailVC.arrMemberList = dicPerticularEvent["EventMembers"] as! NSArray
                eventDetailVC.dialog = dialogFetch
                self.navigationController?.pushViewController(eventDetailVC, animated: true)
            }
        })
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        deleteEventAPICall(indexPath: indexPath)
    }
    
    
    // ********** FSCalendar Deleagete Methods ********** //
    
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM yyyy"
        return formatter
    }()
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatterHeader: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar)
    {
        lblCalenderHeader.text = self.dateFormatter.string(from: calendar.currentPage)
        strSelectedDate = ""
        
        let calTemp = Calendar.current
        let year = calTemp.component(.year, from: calendar.currentPage)
        let month = calTemp.component(.month, from: calendar.currentPage)
        print(year)
        print(month)
        
        if self.calendar.scope == .month
        {
            getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
        }
        else
        {
            let custCal = Calendar.current
            let weekOfYear = custCal.component(.weekOfYear, from: calendar.currentPage)
            print(weekOfYear)
            
            let strWeekOfYear = "\(weekOfYear)"
            if strWeekOfYear.count == 1
            {
                getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
            }
            else
            {
                let strWeekOfYear = "\(weekOfYear)"
                if strWeekOfYear.count == 1
                {
                    getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
                }
                else
                {
                    getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
                }
            }
        }
    }
    
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool)
    {
        self.calendarHeightConstraint.constant = bounds.height
        self.view.layoutIfNeeded()
        
        if bounds.height < 100 || bounds.height > 222
        {
            strSelectedDate = ""
            
            let calTemp = Calendar.current
            let year = calTemp.component(.year, from: calendar.currentPage)
            let month = calTemp.component(.month, from: calendar.currentPage)
            print(year)
            print(month)
            
            if self.calendar.scope == .month
            {
                imgViewCheckMonthView.isHidden = false
                imgViewCheckWeekView.isHidden = true
                
                getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
            }
            else
            {
                imgViewCheckMonthView.isHidden = true
                imgViewCheckWeekView.isHidden = false
                
                let custCal = Calendar.current
                let weekOfYear = custCal.component(.weekOfYear, from: calendar.currentPage)
                print(weekOfYear)
                
                let strWeekOfYear = "\(weekOfYear)"
                if strWeekOfYear.count == 1
                {
                    getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
                }
                else
                {
                    getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(year)", strCalID: dicCalData["CalendarID"] as! String)
                }
            }
        }
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition)
    {
        print(date)
        let custCal = Calendar.current
        let weekOfYear = custCal.component(.weekOfYear, from: date)
        print(weekOfYear)
        
        let dateString = self.dateFormatter2.string(from: date as Date)
        if arrEventListDateKey.contains(dateString)
        {
            strSelectedDate = "\(dateString)"
            tblView.reloadData()
        }
        else
        {
            let alertCntrl = UIAlertController(title: "Reminder:", message: "No events scheduled on this day.", preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in
                
                self.strSelectedDate = ""
                self.tblView.reloadData()
            }))
            self.present(alertCntrl, animated: true, completion: nil)
        }
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillSelectionColorFor date: Date) -> UIColor?
    {
        return postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String).withAlphaComponent(0.3)
    }
    
    func calendar(_ calendar: FSCalendar!, appearance: FSCalendarAppearance!, titleDefaultColorFor date: Date!) -> UIColor!
    {
        let dateString = self.dateFormatter2.string(from: date as Date)
        
        if arrEventListDateKey.contains(dateString)
        {
            return postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        }
        
        return nil
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int
    {
        let dateString = self.dateFormatter2.string(from: date)
        if arrEventListDateKey.contains(dateString) {
            return 1
        }
        return 0
    }
    
    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == viewPopup
            {
                viewPopup.isHidden = true
                viewMore.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    // ********** Get Profile Picture Document Directory ********** //
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
    
    func postCalendarColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    // MARK:
    // MARK: All WebServices Call
    
    // ********** Get Month wise Events ********** //
    
    func getMonthWiseEventList(strMonth:String, strYear:String, strCalID:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/DateWiseList"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Val_Status":"2", "Val_Type":"2", "Val_Calendarid":strCalID, "Val_Year":strYear, "Val_Month":strMonth, "Action":"GetMonthWise"]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    print(response)
                    
                    let dicMonthEventResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicMonthEventResponse?["status"] as? String == "success"
                    {
                        let dicData = dicMonthEventResponse?["data"] as! NSDictionary
                        print(dicData)
                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicData.mutableCopy() as! NSMutableDictionary

                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []

                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"

                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }

                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)

                        }
                        
                        if self.arrEventListDateKey.count == 0
                        {
//                            self.lblEventAvailOrNot.isHidden = false
                        }
                        else
                        {
//                            self.lblEventAvailOrNot.isHidden = true
                        }
                        
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                    }
                    else if dicMonthEventResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
//
//                        self.lblEventAvailOrNot.isHidden = false
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
//                        self.lblEventAvailOrNot.isHidden = false
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    
    // ********** Get Week wise Events ********** //
    
    func getWeekWiseEventList(strWeek:String, strYear:String, strCalID:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/DateWiseList"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Val_Status":"2", "Val_Type":"2", "Val_Calendarid":strCalID, "Val_Year":strYear, "Val_Week":strWeek, "Action":"GetWeekWise"]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    print(response)
                    
                    let dicWeekEventResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicWeekEventResponse?["status"] as? String == "success"
                    {
                        let dicData = dicWeekEventResponse?["data"] as! NSDictionary
                        print(dicData)
                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicData.mutableCopy() as! NSMutableDictionary
                        
                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }
                        
                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)
                            
                        }
                        
                        if self.arrEventListDateKey.count == 0
                        {
                            //                            self.lblEventAvailOrNot.isHidden = false
                        }
                        else
                        {
                            //                            self.lblEventAvailOrNot.isHidden = true
                        }
                        
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                    }
                    else if dicWeekEventResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        //
//                                                self.lblEventAvailOrNot.isHidden = false
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        //                        self.lblEventAvailOrNot.isHidden = false
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    // ********** Delete Event Api Call ********** //
    
    func deleteEventAPICall(indexPath: IndexPath)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
                
                self.deleteEventAPICall(indexPath: indexPath)
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            var dicPerticularEvent = NSDictionary()
            if strSelectedDate != ""
            {
                let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
                dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
            }
            else
            {
                let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
                dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            }
            let strEventID = dicPerticularEvent.value(forKey: "EventID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Action":"Delete", "Val_Userid":strUserID]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDeleteCalendar = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDeleteCalendar?["status"] as? String == "success"
                        {
                            let calTemp = Calendar.current
                            let year = calTemp.component(.year, from: self.calendar.currentPage)
                            let month = calTemp.component(.month, from: self.calendar.currentPage)
                            print(year)
                            print(month)
                            
                            if self.calendar.scope == .month
                            {
//                                self.getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
                                self.getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)", strCalID: self.dicCalData["CalendarID"] as! String)
                            }
                            else
                            {
                                let custCal = Calendar.current
                                let weekOfYear = custCal.component(.weekOfYear, from: self.calendar.currentPage)
                                print(weekOfYear)
                                
                                let strWeekOfYear = "\(weekOfYear)"
                                if strWeekOfYear.count == 1
                                {
//                                    self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)")
                                    self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)", strCalID: self.dicCalData["CalendarID"] as! String)
                                }
                                else
                                {
                                    let strWeekOfYear = "\(weekOfYear)"
                                    if strWeekOfYear.count == 1
                                    {
//                                        self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)")
                                        self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)", strCalID: self.dicCalData["CalendarID"] as! String)
                                    }
                                    else
                                    {
//                                        self.getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(year)")
                                        self.getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(year)", strCalID: self.dicCalData["CalendarID"] as! String)
                                    }
                                }
                            }
                            
                        }
                        else if dicDeleteCalendar?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDeleteCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    

}



























