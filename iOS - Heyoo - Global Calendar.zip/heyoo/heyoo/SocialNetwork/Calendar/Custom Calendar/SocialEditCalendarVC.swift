//
//  SocialEditCalendarVC.swift
//  heyoo
//
//  Created by Intorque LLP on 23/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire

class SocialEditCalendarVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITextFieldDelegate {
    
    @IBOutlet weak var lblCalendarName: UILabel!
    @IBOutlet weak var viewNav: UIView!
    @IBOutlet weak var viewCalNameBack: UIView!
    @IBOutlet weak var txtCalName: UITextField!
    @IBOutlet weak var btnUpdate: UIButton!
    @IBOutlet weak var collectColor: UICollectionView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var strSelectColor = String()
    var strSelectTick = String()
    var arrColor = NSArray()
    
    var dicCalData = NSMutableDictionary()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        print(dicCalData)
        
        viewCalNameBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalNameBack.layer.shadowOpacity = 0.4
        viewCalNameBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalNameBack.layer.shadowRadius = 3
        lblCalendarName.text = dicCalData["Name"] as? String
        strSelectColor = "\(dicCalData["Color"] as! String)"
        txtCalName.text = "\(dicCalData["OriginalName"] as! String)"
        let strSelColorTemp = dicCalData["Color"] as! String
        let selColor:Int = Int(strSelColorTemp)!
        strSelectTick = "\(selColor-1)"
        
        viewNav.backgroundColor = postCalendarColorInTableCell(strColor: strSelectColor)
        
        arrColor = [customColor.color1, customColor.color2, customColor.color3, customColor.color4, customColor.color5, customColor.color6, customColor.color7]
        
        txtCalName.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrColor.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellColor : collectColorCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! collectColorCell
        
        cellColor.viewColor.backgroundColor = arrColor[indexPath.item] as? UIColor
        
        if strSelectTick == "\(indexPath.item)"
        {
            cellColor.imgViewTick.isHidden = false
        }
        else
        {
            cellColor.imgViewTick.isHidden = true
        }
        
        return cellColor
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectColor.frame.size.height, height: collectColor.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        viewNav.backgroundColor = arrColor[indexPath.item] as? UIColor
        strSelectColor = "\(indexPath.item+1)"
        strSelectTick = "\(indexPath.row)"
        collectColor.reloadData()
    }
    
    // ********** UITextField Delegate Methods ********** //
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        lblCalendarName.text = textField.text
    }
    
    
    // ********** All Button Action ********** //

    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionUpdateCalendar(_ sender: UIButton)
    {
        UpdateCalendarAPICall()
    }
    
    
    // ********** Update Calendar API Call ********** //
    
    func UpdateCalendarAPICall()
    {
        if txtCalName.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Enter Calendar Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            if !Reachability.isConnectedToNetwork()
            {
                let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
                networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
                    
                    self.UpdateCalendarAPICall()
                }))
                self.present(networkAlert, animated: true, completion: nil)
            }
            else
            {
                MBProgressHUD.showAdded(to: self.view, animated: true)
                
                let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
                let strMainURL: String = "Calendar/Details"
                let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
                
                let calID = dicCalData["CalendarID"] as! String
                let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
                let strTimezone = "\(TimeZone.current.secondsFromGMT())"
                let strDST = UserDefaults.standard.value(forKey: "DST") as! String
                
                let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":calID, "Val_Color":strSelectColor, "Val_Name":txtCalName.text! as String, "Val_Userid":strUserID, "Action":"Update"]
                
                Alamofire.upload(multipartFormData: { (multipartFormData) in
                    
                    for (key,value) in parameters {
                        multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                    }
                    
                }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                    
                    switch encodingResult {
                        
                    case .success(let upload, _, _):
                        upload.responseJSON(completionHandler: { (response) in
                            print(response.description)
                            
                            let dicUpdateCalResponse = response.result.value as? [String: Any]
                            
                            MBProgressHUD.hide(for: self.view, animated: true)
                            
                            if dicUpdateCalResponse?["status"] as? String == "success"
                            {
                                let arrCalendar = dicUpdateCalResponse!["data"] as! NSArray
                                let dicCalendar = arrCalendar[0] as! NSDictionary
//                                let dicCalendarTemp = dicCalendar.mutableCopy()
//                                customCalVC.dicCalData = dicCalendarTemp as! NSMutableDictionary
//                                self.dicCalData = dicCalendarTemp as! NSMutableDictionary
                                
                                print(self.dicCalData)
                                
                                self.dicCalData["Color"] = self.strSelectColor
                                self.dicCalData["Name"] = self.txtCalName.text
                                self.dicCalData["OriginalName"] = dicCalendar["OriginalName"] as! String
                                print(self.dicCalData)
                                
                                self.navigationController?.popViewController(animated: true)
                                
                            }
                            else if dicUpdateCalResponse?["status"] as? String == "error"
                            {
                                let alertCntrl = UIAlertController(title: nil, message: (dicUpdateCalResponse?["message"] as? String), preferredStyle: .alert)
                                alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                self.present(alertCntrl, animated: true, completion: nil)
                            }
                        })
                        
                    case .failure(let encodingError):
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        print(encodingError)
                    }
                }
            }
        }
    }
    
    
    func postCalendarColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
}




































