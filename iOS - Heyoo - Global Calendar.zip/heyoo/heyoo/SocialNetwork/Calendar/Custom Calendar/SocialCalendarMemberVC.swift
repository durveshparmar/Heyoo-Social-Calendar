//
//  SocialCalendarMemberVC.swift
//  heyoo
//
//  Created by Intorque LLP on 21/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Quickblox
import QMChatViewController
import QMServices


class SocialCalendarMemberVC: UIViewController, UITableViewDelegate, UITableViewDataSource, QMChatServiceDelegate, QMChatConnectionDelegate {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var lblCalName: UILabel!
    @IBOutlet weak var viewCalNave: UIView!
    @IBOutlet weak var imgViewIconUser: UIImageView!
    @IBOutlet weak var lblSharedCalendarCount: UILabel!
    @IBOutlet weak var btnAddMember: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var dicCalData = NSMutableDictionary()
    var arrMemberListData = NSArray()
    var strCreaterUserID = String()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        viewCalNave.backgroundColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        lblCalName.text = dicCalData["Name"] as? String
        imgViewIconUser.image = imgViewIconUser.image?.withRenderingMode(.alwaysTemplate)
        imgViewIconUser.tintColor = postCalendarColorInTableCell(strColor: dicCalData.value(forKey: "Color") as! String)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        let strIsShared = dicCalData["Shared"] as! String
        if strIsShared == "1"
        {
            
        }
        else
        {
            if dicCalData["Admin"] as! String == "1"
            {
                btnAddMember.isHidden = true
            }
        }
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        self.getCalendarMemberListAPICall()
        print(dicCalData)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        
    }
    
    
    // ********** All Button Action ********** //
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionAddMember(_ sender: UIButton)
    {
        let inviteVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialInvitePeopleVC") as! SocialInvitePeopleVC
        let arrInvitePeople = arrMemberListData.mutableCopy()
        inviteVC.arrInvitedPeople = arrInvitePeople as! NSMutableArray
        inviteVC.isMemberVC = "2"
        inviteVC.dicCalData = dicCalData
        self.navigationController?.pushViewController(inviteVC, animated: true)
    }
    
    
    // ********** UITableViewDelegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrMemberListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SocialCalMemberCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! SocialCalMemberCell
        let dicMemberData = arrMemberListData[indexPath.row] as! NSDictionary
        
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
        
        cell.lblName.text = dicMemberData["FullName"] as? String
        cell.imgViewProPic.sd_setImage(with: URL(string : dicMemberData["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        
        
        cell.setEditing(true, animated: true)
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let dicMemberData = arrMemberListData[indexPath.row] as! NSDictionary
        print(dicMemberData)
        
        if dicMemberData["UserID"] as! String == UserDefaults.standard.value(forKey: "socialUserID") as! String
        {
            
        }
        else
        {
            print(dicCalData)
            
            
            let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
            actionSheet.addAction(UIAlertAction(title: "Send A Message", style: .default, handler: { (messageAction:UIAlertAction) in
                
                self.sendAMessageMethod(memberDetail: dicMemberData)
                
            }))
            actionSheet.addAction(UIAlertAction(title: "View Profile", style: .default, handler: { (viewProAction:UIAlertAction) in
                
                let viewProfileVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialViewMemberProfileVC") as! SocialViewMemberProfileVC
                viewProfileVC.dicUserData = dicMemberData
                self.navigationController?.pushViewController(viewProfileVC, animated: true)
                
            }))
            
            let strIsShared = dicCalData["Shared"] as! String
            if strIsShared == "1"
            {
                if dicMemberData["Admin"] as! String == "1"
                {
                    actionSheet.addAction(UIAlertAction(title: "Make Admin", style: .default, handler: { (makeAdminAction:UIAlertAction) in
                        self.makeAdminMemberAPICall(strUserID: dicMemberData["UserID"] as! String)
                    }))
                }
                else
                {
                    actionSheet.addAction(UIAlertAction(title: "Remove Admin", style: .default, handler: { (removeAdminAction:UIAlertAction) in
                        self.removeAdminMemberAPICall(strUserID: dicMemberData["UserID"] as! String)
                    }))
                }
            }
            else
            {
                let strIsAdmin = dicCalData["Admin"] as! String
                if strIsAdmin == "2"
                {
                    if dicMemberData["Admin"] as! String == "1"
                    {
                        actionSheet.addAction(UIAlertAction(title: "Make Admin", style: .default, handler: { (makeAdminAction:UIAlertAction) in
                            self.makeAdminMemberAPICall(strUserID: dicMemberData["UserID"] as! String)
                        }))
                    }
                    else if strCreaterUserID == UserDefaults.standard.value(forKey: "socialUserID") as! String
                    {
                        actionSheet.addAction(UIAlertAction(title: "Remove Admin", style: .default, handler: { (removeAdminAction:UIAlertAction) in
                            self.removeAdminMemberAPICall(strUserID: dicMemberData["UserID"] as! String)
                        }))
                    }
                }
            }
            
            actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            self.present(actionSheet, animated: true, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        let dicMemberData = arrMemberListData[indexPath.row] as! NSDictionary
        print(dicMemberData)
        
        
        let strIsShared = dicCalData["Shared"] as! String
        if strIsShared == "1"
        {
            if dicMemberData["UserID"] as! String == UserDefaults.standard.value(forKey: "socialUserID") as! String
            {
                
            }
            else
            {
                let strUserID = dicMemberData["UserID"] as! String
                deleteCalendarMemberAPICall(strUserID: strUserID)
            }
        }
        else
        {
            let strIsAdmin = dicCalData["Admin"] as! String
            if strIsAdmin == "1"
            {
                let alertCntrl = UIAlertController(title: "Warning", message: "Sorry but this member may only be deleted by the creator.", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alertCntrl, animated: true, completion: nil)
            }
            else
            {
                if strCreaterUserID == dicMemberData["UserID"] as! String
                {
                    let alertCntrl = UIAlertController(title: "Warning", message: "Sorry but you can not delete the creator.", preferredStyle: .alert)
                    alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                    self.present(alertCntrl, animated: true, completion: nil)
                }
                else
                {
                    let strUserID = dicMemberData["UserID"] as! String
                    deleteCalendarMemberAPICall(strUserID: strUserID)
                }
            }
        }
    }
    
    func sendAMessageMethod(memberDetail:NSDictionary)
    {
        print(memberDetail)
        
        var userSelected: [QBUUser] = []
        QBRequest.user(withLogin: "\(memberDetail["Mobile"] as! String)", successBlock: { (response, user) in
            userSelected.append(user)
            
            let completion = {[weak self] (response: QBResponse?, createdDialog: QBChatDialog?) -> Void in
                
                if createdDialog != nil {
                    
                    self?.openNewDialog(dialog: createdDialog)
                }
                
                guard let unwrappedResponse = response else {
                    print("Error empty response")
                    return
                }
                
                if let error = unwrappedResponse.error {
                    print(error.error as Any)
//                    SVProgressHUD.showError(withStatus: error.error?.localizedDescription)
                }
                else {
                    
                }
            }
            
            self.createChat(name: nil, users: userSelected, completion: completion)
            
            
        }) { (response) in
            
        }
    }
    
    func createChat(name: String?, users:[QBUUser], completion: ((_ response: QBResponse?, _ createdDialog: QBChatDialog?) -> Void)?)
    {
        ServicesManager.instance().chatService.createPrivateChatDialog(withOpponent: users.first!, completion: { (response, chatDialog) in
            
            completion?(response, chatDialog)
        })
    }
    
    
    func openNewDialog(dialog: QBChatDialog!)
    {
        let navigationArray = self.navigationController?.viewControllers
        let newStack = [] as NSMutableArray
        for vc in navigationArray!
        {
            newStack.add(vc)
            if vc is SocialMessageVC
            {
                let chatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
                chatVC.dialog = dialog
                newStack.add(chatVC)
                self.navigationController?.setViewControllers(newStack.copy() as! [UIViewController], animated: true)
                return
            }
        }
        
        let chatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
        chatVC.dialog = dialog
        self.navigationController?.pushViewController(chatVC, animated: true)
    }
    
    
    
    // ********** Calender Member Remove Admin API Call ********** //
    
    func removeAdminMemberAPICall(strUserID:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Members"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let calID = dicCalData["CalendarID"] as! String
            let strMasterUserID = UserDefaults.standard.value(forKey: "socialUserID") as! String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":calID, "Val_Userid":strUserID, "Val_Masterid":strMasterUserID, "Val_Admin":"1", "Action":"MakeAdmin"]
            
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.description)
                        
                        let dicCalMemberResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicCalMemberResponse?["status"] as? String == "success"
                        {
                            self.getCalendarMemberListAPICall()
                            
                        }
                        else if dicCalMemberResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicCalMemberResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** Calender Member Make Admin API Call ********** //
    
    func makeAdminMemberAPICall(strUserID:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Members"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let calID = dicCalData["CalendarID"] as! String
            let strMasterUserID = UserDefaults.standard.value(forKey: "socialUserID") as! String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":calID, "Val_Userid":strUserID, "Val_Masterid":strMasterUserID, "Val_Admin":"2", "Action":"MakeAdmin"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.description)
                        
                        let dicCalMemberResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicCalMemberResponse?["status"] as? String == "success"
                        {
                            self.getCalendarMemberListAPICall()
                            
                        }
                        else if dicCalMemberResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicCalMemberResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    // ********** Calender Member Delete API Call ********** //
    
    func deleteCalendarMemberAPICall(strUserID:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Members"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let calID = dicCalData["CalendarID"] as! String
            let strMasterUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":calID, "Val_Userid":strUserID, "Val_Masterid":strMasterUserID, "Action":"Delete"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.description)
                        
                        let dicCalMemberResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicCalMemberResponse?["status"] as? String == "success"
                        {
                            self.getCalendarMemberListAPICall()
                            
                        }
                        else if dicCalMemberResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicCalMemberResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    // ********** Calender Member List API Call ********** //
    
    func getCalendarMemberListAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
//                self.getCalendarMemberListAPICall()
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let calID = dicCalData["CalendarID"] as! String
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":calID, "Val_Userid":strUserID, "Action":"GetMembers"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.description)
                        
                        let dicCalMemberResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicCalMemberResponse?["status"] as? String == "success"
                        {
                            let arrCalData = dicCalMemberResponse?["data"] as! NSArray
                            let dicCalData = arrCalData[0] as! NSDictionary
                            self.arrMemberListData = dicCalData["Members"] as! NSArray
                            print(self.arrMemberListData)
                            
                            self.strCreaterUserID = dicCalData["UserID"] as! String
                            
                            self.lblSharedCalendarCount.text = "Shared Calendar (\(self.arrMemberListData.count-1))"
                            self.dicCalData["SharedCount"] = "\(self.arrMemberListData.count)"
                            self.tblView.reloadData()
                            
                        }
                        else if dicCalMemberResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicCalMemberResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    func postCalendarColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }

}
































