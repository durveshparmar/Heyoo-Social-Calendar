//
//  SocialCalMemberCell.swift
//  heyoo
//
//  Created by Intorque LLP on 21/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialCalMemberCell: UITableViewCell {
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewBack.layer.shadowColor = UIColor.gray.cgColor
        viewBack.layer.shadowOffset = CGSize.zero
        viewBack.layer.shadowOpacity = 0.5 //0.4
        viewBack.layer.shadowRadius = 5 //3
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}









