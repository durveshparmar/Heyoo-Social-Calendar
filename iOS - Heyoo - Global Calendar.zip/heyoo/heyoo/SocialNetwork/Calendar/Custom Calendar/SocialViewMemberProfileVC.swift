//
//  SocialViewMemberProfileVC.swift
//  heyoo
//
//  Created by Intorque LLP on 28/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire

class SocialViewMemberProfileVC: UIViewController {
    @IBOutlet weak var viewProfileDetail: UIView!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtCountry: UITextField!
    @IBOutlet weak var txtState: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var dicUserData = NSDictionary()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        viewProfileDetail.layer.shadowColor = UIColor.lightGray.cgColor
        viewProfileDetail.layer.shadowOpacity = 0.4
        viewProfileDetail.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewProfileDetail.layer.shadowRadius = 3
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        imgViewProPic.layer.borderWidth = 3.0
        imgViewProPic.layer.borderColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0) .cgColor
        
        getUserProfileWebServiceCall()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action Methods ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    // *********** Get User Profile Service Call ********** //
    func getUserProfileWebServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Fetch"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = dicUserData["UserID"] as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Action":"SingleUser"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicMyProfile = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicMyProfile?["status"] as? String == "success"
                    {
                        let arrData = dicMyProfile?["data"] as! NSArray
                        let dicData = arrData[0] as! NSDictionary
                        
                        print(dicData)
                        
                        self.txtFirstName.text = dicData["FirstName"] as? String
                        self.txtLastName.text = dicData["LastName"] as? String
                        self.txtCountry.text = dicData["Country"] as? String
                        self.txtState.text = dicData["State"] as? String
                        self.txtCity.text = dicData["City"] as? String
                        
                        if dicData["ProfileImage"] as? String != nil
                        {
                            MBProgressHUD.showAdded(to: self.view, animated: true)
                            
                            let strImgURL = dicData["ProfileImage"] as? String
                            let imgURL = NSURL(string: strImgURL!)
                            
                            self.getDataFromUrl(url: imgURL! as URL) { data, response, error in
                                guard let data = data, error == nil else { return }
                                DispatchQueue.main.async() {
                                    
                                    self.imgViewProPic.image = UIImage(data: data)
                                    
                                    MBProgressHUD.hide(for: self.view, animated: true)
                                }
                            }
                        }
                        else
                        {
                            let lblNameInitialize = UILabel()
                            lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
                            lblNameInitialize.textColor = UIColor.white
                            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
                            lblNameInitialize.textAlignment = NSTextAlignment.center
                            lblNameInitialize.backgroundColor = UIColor.black
                            
                            UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
                            lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
                            self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
                            UIGraphicsEndImageContext()
                        }
                    }
                    else if dicMyProfile?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicMyProfile?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    // ********** Image URL Convert To Data ********** //
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    
}




































