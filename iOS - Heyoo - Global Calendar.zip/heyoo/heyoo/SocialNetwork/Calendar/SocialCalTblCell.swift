//
//  SocialCalTblCell.swift
//  heyoo
//
//  Created by Intorque LLP on 18/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialCalTblCell: UITableViewCell {
    @IBOutlet weak var viewMainBack: UIView!
    @IBOutlet weak var lblCalendarName: UILabel!
    @IBOutlet weak var viewCalColor: UIView!
    @IBOutlet weak var imgViewShare: UIImageView!
    @IBOutlet weak var lblShare: UILabel!
    @IBOutlet weak var imgView2: UIImageView!
    @IBOutlet weak var imgView3: UIImageView!
    @IBOutlet weak var imgView4: UIImageView!
    @IBOutlet weak var viewInviteUsers: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewMainBack.layer.shadowColor = UIColor.gray.cgColor
        viewMainBack.layer.shadowOffset = CGSize.zero
        viewMainBack.layer.shadowOpacity = 0.5
        viewMainBack.layer.shadowRadius = 5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
