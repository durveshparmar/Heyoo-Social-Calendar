//
//  SocialSettingsVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 05/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import QMServices
import Quickblox
 
import GoogleSignIn
import GoogleAPIClientForREST

class SocialSettingsVC: UIViewController, GIDSignInDelegate, GIDSignInUIDelegate, QMChatConnectionDelegate, QMChatServiceDelegate, QMAuthServiceDelegate {
    @IBOutlet weak var switchPrivateAccount: UISwitch!
    @IBOutlet weak var switchGoogleAcc: UISwitch!
    @IBOutlet weak var imgViewProPic: UIImageView!
    
    
    private var observer: NSObjectProtocol?
    
    
    // If modifying these scopes, delete your previously saved credentials by
    // resetting the iOS simulator or uninstall the app.
    private let scopes = [kGTLRAuthScopeCalendarReadonly]
    
    private let service = GTLRCalendarService()
    let signInButton = GIDSignInButton()
    let output = UITextView()
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        
        // Configure Google Sign-in.
//        GIDSignIn.sharedInstance().delegate = self
//        GIDSignIn.sharedInstance().uiDelegate = self
//        GIDSignIn.sharedInstance().scopes = scopes
//        GIDSignIn.sharedInstance().signInSilently()
        
        // Add the sign-in button.
//        view.addSubview(signInButton)
        
        // Add a UITextView to display output.
        output.frame = view.bounds
        output.isEditable = false
        output.contentInset = UIEdgeInsets(top: 20, left: 0, bottom: 20, right: 0)
        output.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        output.isHidden = true
        view.addSubview(output)
    }
    
//    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
//              withError error: Error!) {
//        if let error = error {
//            showAlert(title: "Authentication Error", message: error.localizedDescription)
//            self.service.authorizer = nil
//        } else {
//            self.signInButton.isHidden = true
//            self.output.isHidden = false
//            self.service.authorizer = user.authentication.fetcherAuthorizer()
//            fetchEvents()
//        }
//    }
    
    // Construct a query and get a list of upcoming events from the user calendar
    func fetchEvents() {
        let query = GTLRCalendarQuery_EventsList.query(withCalendarId: "primary")
        query.maxResults = 100000
        query.timeMin = GTLRDateTime(date: Date())
        query.singleEvents = true
        query.orderBy = kGTLRCalendarOrderByStartTime
        service.executeQuery(query, delegate: self, didFinish: #selector(displayResultWithTicket(ticket:finishedWithObject:error:)))
    }

    // Display the start dates and event summaries in the UITextView
    @objc func displayResultWithTicket(ticket: GTLRServiceTicket, finishedWithObject response : GTLRCalendar_Events, error : NSError?)
    {
        if let error = error {
            showAlert(title: "Error", message: error.localizedDescription)
            return
        }

        var outputText = ""
        if let events = response.items, !events.isEmpty {
            for event in events {
                let start = event.start!.dateTime ?? event.start!.date!
                let startString = DateFormatter.localizedString(from: start.date, dateStyle: .short, timeStyle: .short)
                outputText += "\(startString) - \(event.summary!)\n"
            }
            print(events)
        } else {
            outputText = "No upcoming events found."
        }
        output.text = outputText
    }
    
    
//    // Helper for showing an alert
    func showAlert(title : String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    
    
    
    //MARK:Google SignIn Delegate
//    func sign(inWillDispatch signIn: GIDSignIn!, error: Error!)
//    {
//        print(error.localizedDescription)
//    }
    
    // Present a view that prompts the user to sign in with Google
    
    func sign(_ signIn: GIDSignIn!, present viewController: UIViewController!)
    {
        self.present(viewController, animated: true, completion: nil)
    }
    
    // Dismiss the "Sign in with Google" view
    
    func sign(_ signIn: GIDSignIn!, dismiss viewController: UIViewController!)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    //completed sign In
    
    public func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!)
    {
        if (error == nil)
        {
            // Perform any operations on signed in user here.
            self.service.authorizer = user.authentication.fetcherAuthorizer()
            let userId = user.userID                  // For client-side use only!
            let idToken = user.authentication.idToken // Safe to send to the server
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            
            UserDefaults.standard.set("\(user.userID)", forKey: "googleUserID")
            UserDefaults.standard.synchronize()
            
            print(user.authentication)
            print(user.authentication.fetcherAuthorizer())
            print(user.authentication.accessToken)
            print(user.authentication.refreshToken)
            print(user.authentication.accessTokenExpirationDate)
            print(user.serverAuthCode)
            
            print(userId)
            print(idToken)
            print(fullName)
            print(givenName)
            print(familyName)
            print(email)
            print(user)
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            
            let strAccessTokenExpiryDate = formatter.string(from: user.authentication.accessTokenExpirationDate)
            print(strAccessTokenExpiryDate)
            
            
//            strGoogleToken = "\(user.authentication.fetcherAuthorizer())"
            
//            self.googleCalendarWebServiceCall(strGoogle: "2", strGoogleToken: "{\"access_token\"=\"\(user.authentication.accessToken!)\", \"refresh_token\"=\"\(user.authentication.refreshToken!)\", \"expirationDate\"=\"\(strAccessTokenExpiryDate)\"}")
            
            self.googleCalendarWebServiceCall(strGoogle: "2", strGoogleToken: "\(user.serverAuthCode)")
            
//            fetchEvents()
        }
        else
        {
            switchGoogleAcc.setOn(false, animated: true)
            print("\(error)")
            showAlert(title: "Alert", message: "\(error.localizedDescription)")
        }
    }
    
    // ********** Google Calendar Webservice Call ********** //
    
    func googleCalendarWebServiceCall(strGoogle : String, strGoogleToken:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Val_Google":strGoogle, "Val_GoogleToken":strGoogleToken, "Val_GoogleType":"1", "Action":"UpdateGoogle"]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicMyProfile = response.result.value as? [String: Any]
                    print(dicMyProfile)
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicMyProfile?["status"] as? String == "success"
                    {
                        print(dicMyProfile)
                    }
                    else if dicMyProfile?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicMyProfile?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        if UserDefaults.standard.value(forKey: "isAccountPrivacy") as? String == "1"
        {
            switchPrivateAccount.setOn(false, animated: false)
        }
        else if UserDefaults.standard.value(forKey: "isAccountPrivacy") as? String == "2"
        {
            switchPrivateAccount.setOn(true, animated: false)
        }
        else
        {
            switchPrivateAccount.setOn(false, animated: false)
        }
        
        let strCheckGoogleSwitch = UserDefaults.standard.value(forKey: "googleUserID") as? String
        print(strCheckGoogleSwitch)
        if strCheckGoogleSwitch == "" || strCheckGoogleSwitch == nil
        {
            switchGoogleAcc.setOn(false, animated: true)
        }
        else
        {
            switchGoogleAcc.setOn(true, animated: true)
            GIDSignIn.sharedInstance().signInSilently()
        }
        
        getProfileImageDocumentDirectory()
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    
    @IBAction func ActionPrivacyPolicy(_ sender: UIButton)
    {
        //        UIApplication.shared.open(URL(string: "https://www.iubenda.com/privacy-policy/35888035")!, options: [:], completionHandler: nil)
        
        UIApplication.shared.openURL(URL(string: "https://www.iubenda.com/privacy-policy/35888035")!)
    }
    
    @IBAction func ActionEditProfile(_ sender: UIButton)
    {
        let editProVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEditProfile") as! SocialEditProfile
        self.navigationController?.pushViewController(editProVC, animated: true)
        
    }
    
    @IBAction func ActionSwitchPrivateAccount(_ sender: UISwitch)
    {
        if sender.isOn == true
        {
            privacyAccountWebServiceCall(strPrivacy: "2")
        }
        else
        {
            let alert = UIAlertController(title: nil, message: "Turning the Privacy Setting OFF means your account is public, and anyone in the heyoo database can find you.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "CANCEL", style: .default, handler: { (cancelBtn:UIAlertAction) in
                
                self.switchPrivateAccount.setOn(true, animated: true)
                
            }))
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (okBtn:UIAlertAction) in
                
                self.privacyAccountWebServiceCall(strPrivacy: "1")
                
            }))
            
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func ActionSwitchGoogleCal(_ sender: UISwitch)
    {
        if sender.isOn == true
        {
            print("Switch is on")
            
            GIDSignIn.sharedInstance().delegate=self
            GIDSignIn.sharedInstance().uiDelegate=self
            GIDSignIn.sharedInstance().scopes = scopes
            GIDSignIn.sharedInstance().signIn()
        }
        else
        {
            print("Switch is off")
            
            GIDSignIn.sharedInstance().signOut()
            UserDefaults.standard.set("", forKey: "googleUserID")
            UserDefaults.standard.synchronize()
            
            self.googleCalendarWebServiceCall(strGoogle: "1", strGoogleToken: "")
        }
    }
    
    @IBAction func ActionLogout(_ sender: UIButton)
    {
        self.LogOutWebServiceCall()
        
//        SVProgressHUD.show(withStatus: " LOGOUTING", maskType: SVProgressHUDMaskType.clear)
//
//        ServicesManager.instance().logoutUserWithCompletion { [weak self] (boolValue) -> () in
//
//            guard let strongSelf = self else { return }
//            if boolValue {
//                NotificationCenter.default.removeObserver(strongSelf)
//
//                if strongSelf.observer != nil {
//                    NotificationCenter.default.removeObserver(strongSelf.observer!)
//                    strongSelf.observer = nil
//                }
//
//                ServicesManager.instance().chatService.removeDelegate(strongSelf)
//                ServicesManager.instance().authService.remove(strongSelf)
//
//                ServicesManager.instance().lastActivityDate = nil;
//
//                GIDSignIn.sharedInstance().signOut()
//                UserDefaults.standard.set(nil, forKey: "socialUserID")
//                UserDefaults.standard.set("", forKey: "googleUserID")
//                UserDefaults.standard.synchronize()
//
//                let selectVC = strongSelf.storyboard?.instantiateViewController(withIdentifier: "LoginSelectionVC") as! LoginSelectionVC
//                strongSelf.navigationController?.pushViewController(selectVC, animated: false)
//
//                SVProgressHUD.showSuccess(withStatus: " COMPLETED")
//            }
//        }
    }
    
    
    // ********** Call Login WibService Method ********** //
    
    func LogOutWebServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)

        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/SignOut"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Userid":strUserID, "Val_IsDST":strDST, "Action":"UserSignOut"]

        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    print(dicLoginResponse)
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
//                        SVProgressHUD.show(withStatus: "", maskType: SVProgressHUDMaskType.clear)
                        MBProgressHUD.showAdded(to: self.view, animated: true)
                        
                        let deviceIdentifier: String = UIDevice.current.identifierForVendor!.uuidString
                        QBRequest.unregisterSubscription(forUniqueDeviceIdentifier: deviceIdentifier, successBlock: { (response) in
                            
                            ServicesManager.instance().logoutUserWithCompletion { [weak self] (boolValue) -> () in
                                
                                guard let strongSelf = self else { return }
                                if boolValue {
                                    NotificationCenter.default.removeObserver(strongSelf)
                                    
                                    if strongSelf.observer != nil {
                                        NotificationCenter.default.removeObserver(strongSelf.observer!)
                                        strongSelf.observer = nil
                                    }
                                    
                                    ServicesManager.instance().chatService.removeDelegate(strongSelf)
                                    ServicesManager.instance().authService.remove(strongSelf)
                                    
                                    ServicesManager.instance().lastActivityDate = nil
                                    
                                    GIDSignIn.sharedInstance().signOut()
                                    UserDefaults.standard.set(nil, forKey: "socialUserID")
                                    UserDefaults.standard.set("", forKey: "googleUserID")
                                    UserDefaults.standard.synchronize()
                                    
//                                    let selectVC = strongSelf.storyboard?.instantiateViewController(withIdentifier: "LoginSelectionVC") as! LoginSelectionVC
//                                    strongSelf.navigationController?.pushViewController(selectVC, animated: true)
                                    
                                    let LoginVC = strongSelf.storyboard?.instantiateViewController(withIdentifier: "SocialLoginVC") as! SocialLoginVC
                                    strongSelf.navigationController?.pushViewController(LoginVC, animated: true)
                                    
//                                    SVProgressHUD.showSuccess(withStatus: "")
                                    
                                }
                            }
                            
                        }) { (error) in
                            print(error)
                        }
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    // ********** Privacy Webservice Call ********** //
    
    func privacyAccountWebServiceCall(strPrivacy : String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Userid":strUserID, "Val_IsDST":strDST, "Val_Privacy":strPrivacy, "Action":"UpdatePrivacy"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicMyProfile = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicMyProfile?["status"] as? String == "success"
                    {
                        UserDefaults.standard.set(strPrivacy, forKey: "isAccountPrivacy")
                        UserDefaults.standard.synchronize()
                    }
                    else if dicMyProfile?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicMyProfile?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    
    
    // ********** Get Profile Picture Document Directory ********** //
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
}






























