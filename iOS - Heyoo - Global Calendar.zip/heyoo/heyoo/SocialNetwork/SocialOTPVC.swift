//
//  SocialOTPVC.swift
//  heyoo
//
//  Created by Intorque LLP on 07/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Quickblox
import QMServices

class SocialOTPVC: UIViewController, VPMOTPViewDelegate, UITextFieldDelegate {
    var strSelectCountryCode = NSString()
    var strEmailAddress = NSString()
    var strPhoneNumber = NSString()
    var strScreenCheck = NSString()
    var strOTP = String()
    var strUserID = String()
    
    @IBOutlet weak var first: UITextField!
    @IBOutlet weak var second: UITextField!
    @IBOutlet weak var third: UITextField!
    @IBOutlet weak var fourth: UITextField!
    
    
    
    
    
    
    @IBOutlet weak var otpView: VPMOTPView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        print(strOTP)
        
        otpView.otpFieldsCount = 4
        otpView.otpFieldDefaultBorderColor = UIColor.black
        otpView.otpFieldEnteredBorderColor = UIColor.black
        otpView.otpFieldBorderWidth = 1
        otpView.delegate = self
        otpView.otpFieldFont = UIFont(name: "ProximaNova-Bold", size: 17)!
        otpView.backgroundColor = UIColor.white
        
        // Create the UI
        otpView.initalizeUI()
        
        first.delegate = self
        second.delegate = self
        third.delegate = self
        fourth.delegate = self
        
        first.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        second.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        third.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        fourth.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
    }
    
    @objc func textFieldDidChange(textField: UITextField){
        
        //        let text = Int(textField.text?.characters.count)
        let text = textField.text
        let textCount:Int = (text?.characters.count)!
        
        
        if textCount >= 1 {
            switch textField{
            case first:
                second.becomeFirstResponder()
            case second:
                third.becomeFirstResponder()
            case third:
                fourth.becomeFirstResponder()
            case fourth:
                fourth.resignFirstResponder()
            default:
                break
            }
        }else{
            
            switch textField{
            case first:
                first.becomeFirstResponder()
            case second:
                first.becomeFirstResponder()
            case third:
                second.becomeFirstResponder()
            case fourth:
                third.becomeFirstResponder()
            default:
                break
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == first {
            
            first.text = ""
            second.text = ""
            third.text = ""
            fourth.text = ""
        }
        else{
            
            textField.text = ""
        }
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if first.text != "" && second.text != "" && third.text != "" && fourth.text != "" {
            
            let otpString = "\(first.text!)\(second.text!)\(third.text!)\(fourth.text!)"
            print("OTPString: \(otpString)")
            
            if otpString == strOTP
            {
                if strScreenCheck == "logScreen"
                {
                    let logUser = QBUUser()
                    logUser.login = "\(strPhoneNumber)"
                    logUser.password = "\(strEmailAddress)\(strPhoneNumber)"
                    
                    MBProgressHUD.showAdded(to: self.view, animated: true)
                    QMServicesManager.instance().logIn(with: logUser) { (success, errorMessage) in
                        
                        guard success else {
                            
                            return
                        }
                        
                        
                        let deviceIdentifier: String = UIDevice.current.identifierForVendor!.uuidString
                        
                        let subscription: QBMSubscription! = QBMSubscription()
                        subscription.notificationChannel = QBMNotificationChannel.APNS
                        subscription.deviceUDID = deviceIdentifier
                        subscription.deviceToken = UserDefaults.standard.value(forKey: "deviceTokenData") as? Data
                        
                        QBRequest.createSubscription(subscription, successBlock: { (response: QBResponse!, objects: [QBMSubscription]?) -> Void in
                            
                            MBProgressHUD.hide(for: self.view, animated: true)
                            
                            UserDefaults.standard.set(self.strUserID, forKey: "socialUserID")
                            UserDefaults.standard.synchronize()
                            
                            let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                            self.navigationController?.pushViewController(tabVC, animated: true)
                            
                        }) { (response: QBResponse!) -> Void in
                            
                            MBProgressHUD.hide(for: self.view, animated: true)
                            
                            UserDefaults.standard.set(self.strUserID, forKey: "socialUserID")
                            UserDefaults.standard.synchronize()
                            
                            let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                            self.navigationController?.pushViewController(tabVC, animated: true)
                        }
                    }
                }
                else if strScreenCheck == "regScreen"
                {
                    let proVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialMyProfile") as! SocialMyProfile
                    proVC.strSelectCountryCode = strSelectCountryCode
                    proVC.strEmailAddress = strEmailAddress
                    proVC.strPhoneNumber = strPhoneNumber
                    self.navigationController?.pushViewController(proVC, animated: true)
                }
            }
            else
            {
                let alertCntrl = UIAlertController(title: "Warning", message: "Your PIN is invalid", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    self.first.becomeFirstResponder()
                }))
                self.present(alertCntrl, animated: true, completion: nil)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        first.becomeFirstResponder()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // *********** OTP View Delegate Methods *********** //
    func hasEnteredAllOTP(hasEntered: Bool)
    {
        print("Has entered all OTP? \(hasEntered)")
    }
    	
    func enteredOTP(otpString: String)
    {
        print("OTPString: \(otpString)")
        
        if otpString == strOTP
        {
            if strScreenCheck == "logScreen"
            {
                let logUser = QBUUser()
                logUser.login = "\(strPhoneNumber)"
                logUser.password = "\(strEmailAddress)\(strPhoneNumber)"
                
//                SVProgressHUD.show(withStatus: "Logging", maskType: SVProgressHUDMaskType.clear)
                MBProgressHUD.showAdded(to: self.view, animated: true)
                QMServicesManager.instance().logIn(with: logUser) { (success, errorMessage) in
                    
                    guard success else {
//                        SVProgressHUD.showError(withStatus: errorMessage)
                        return
                    }
                    
                    
                    let deviceIdentifier: String = UIDevice.current.identifierForVendor!.uuidString
                    
                    let subscription: QBMSubscription! = QBMSubscription()
                    subscription.notificationChannel = QBMNotificationChannel.APNS
                    subscription.deviceUDID = deviceIdentifier
                    subscription.deviceToken = UserDefaults.standard.value(forKey: "deviceTokenData") as? Data
                    
                    QBRequest.createSubscription(subscription, successBlock: { (response: QBResponse!, objects: [QBMSubscription]?) -> Void in
                        
//                        SVProgressHUD.showSuccess(withStatus: "Logged In")
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        UserDefaults.standard.set(self.strUserID, forKey: "socialUserID")
                        UserDefaults.standard.synchronize()
                        
                        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                        self.navigationController?.pushViewController(tabVC, animated: true)
                        
                    }) { (response: QBResponse!) -> Void in
                        
//                        SVProgressHUD.showSuccess(withStatus: "Logged In")
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        UserDefaults.standard.set(self.strUserID, forKey: "socialUserID")
                        UserDefaults.standard.synchronize()
                        
                        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                        self.navigationController?.pushViewController(tabVC, animated: true)
                    }
                }
            }
            else if strScreenCheck == "regScreen"
            {
                let proVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialMyProfile") as! SocialMyProfile
                proVC.strSelectCountryCode = strSelectCountryCode
                proVC.strEmailAddress = strEmailAddress
                proVC.strPhoneNumber = strPhoneNumber
                self.navigationController?.pushViewController(proVC, animated: true)
            }
        }
        else
        {
            let alertCntrl = UIAlertController(title: "Warning", message: "Your OTP is invalid", preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Okay", style: .default, handler: nil))
            self.present(alertCntrl, animated: true, completion: nil)
            
        }
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionResendOPT(_ sender: UIButton)
    {
        first.becomeFirstResponder()
        self.resendOTPServiceCall()
    }
    
    // ********** Call Resend OTP WibService Method ********** //
    func resendOTPServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/ResendOTP"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strMobileNumber = strPhoneNumber as String
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Countrycode":strSelectCountryCode as String, "Val_IsDST":strDST, "Val_Mobile":strMobileNumber, "Action":"Send"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append((value ).data(using: .utf8)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicResendOTPResponse = response.result.value as? [String: Any]
                    print(dicResendOTPResponse)
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicResendOTPResponse?["status"] as? String == "success"
                    {
                        let dicData = dicResendOTPResponse?["data"] as! NSDictionary
                        print(dicData)
                        
                        self.strOTP = dicData["OTP"] as! String
                        
                    }
                    else if dicResendOTPResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicResendOTPResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }

    
    
    
}



























