//
//  SocialMyProfile.swift
//  heyoo
//
//  Created by I N T O R Q U E on 04/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Quickblox
import QMServices

class SocialMyProfile: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate {
    var strSelectCountryCode = NSString()
    var strEmailAddress = NSString()
    var strPhoneNumber = NSString()
    
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet var btnNext: UIButton!
    @IBOutlet var viewProfileDetail: UIView!
    @IBOutlet var txtFirstName: UITextField!
    @IBOutlet var txtLastName: UITextField!
    @IBOutlet weak var txtCountry: UITextField!
    @IBOutlet weak var txtState: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var dataPrpPic = NSData()
    var imageProPic = UIImage()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewProfileDetail.layer.shadowColor = UIColor.lightGray.cgColor
        viewProfileDetail.layer.shadowOpacity = 0.4
        viewProfileDetail.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewProfileDetail.layer.shadowRadius = 3
        
//        btnNext.layer.shadowColor = UIColor.lightGray.cgColor
//        btnNext.layer.shadowOpacity = 1.0
//        btnNext.layer.shadowOffset = CGSize(width: 0.0, height: 0.5)
//        btnNext.layer.shadowRadius = 5.0
//        btnNext.layer.masksToBounds = false
        
        btnNext.layer.shadowColor = UIColor.lightGray.cgColor
        btnNext.layer.shadowOpacity = 0.4
        btnNext.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnNext.layer.shadowRadius = 5.0
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        imgViewProPic.layer.borderWidth = 3.0
        imgViewProPic.layer.borderColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0) .cgColor
        
        profileNameImaageGenerater()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionNext(_ sender: UIButton)
    {
        registerWebServiceCall()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == imgViewProPic
            {
                OpenImagePickerForProfilePicture()
            }
            else
            {
                return
            }
        }
    }
    
    func OpenImagePickerForProfilePicture()
    {
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (alert: UIAlertAction) in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                let imag = UIImagePickerController()
                imag.delegate = self
                imag.sourceType = UIImagePickerControllerSourceType.camera
                imag.allowsEditing = true
                self.present(imag, animated: true, completion: nil)
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Gallery", style: .default, handler: { (alert: UIAlertAction) in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary)
            {
                let imag = UIImagePickerController()
                imag.delegate = self
                imag.sourceType = UIImagePickerControllerSourceType.photoLibrary
                imag.allowsEditing = true
                self.present(imag, animated: true, completion: nil)
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Remove Photo", style: .default, handler: { (alert: UIAlertAction) in
            self.dataPrpPic = NSData()
            self.profileNameImaageGenerater()
        }))
        
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (alert: UIAlertAction) in
            
            print("cancel")
        }))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    // ********** UIImagePickerControllerDelegate Methods ********** //
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        imgViewProPic.image = info["UIImagePickerControllerEditedImage"] as? UIImage
        
        dataPrpPic = UIImageJPEGRepresentation(imgViewProPic.image!, 0.5)! as NSData
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    func registerWebServiceCall()
    {
        if txtFirstName.text?.count == 0 || txtLastName.text?.count == 0 || txtCountry.text?.count == 0 || txtState.text?.count == 0 || txtCity.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "All Field are require", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Authentication/SignUp"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            dataPrpPic = UIImageJPEGRepresentation(imgViewProPic.image!, 0.5)! as NSData
            let strBase64proPic = dataPrpPic.base64EncodedString(options: .lineLength64Characters)
            
            let tokenString = UserDefaults.standard.value(forKey: "deviceToken") as! String
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Action":"UserSignUp", "Val_IsDST":strDST, "Val_iOSToken":tokenString, "Val_Firstname":txtFirstName.text! as String, "Val_Lastname":txtLastName.text! as String, "Val_Countrycode":strSelectCountryCode as String, "Val_Mobile":strPhoneNumber as String, "Val_Email":strEmailAddress as String, "Val_Country":txtCountry.text! as String, "Val_State":txtState.text! as String, "Val_City":txtCity.text! as String, "Val_ProfileImage":strBase64proPic as String]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    if value.count == 0
                    {
                        
                    }
                    else
                    {
                        multipartFormData.append((value ).data(using: .utf8)!, withName: key)
                    }
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicRegResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicRegResponse?["status"] as? String == "success"
                        {
                            let dicData = dicRegResponse?["data"] as! NSDictionary
                            print(dicData)
                            
                            let strUserID = dicData["UserID"] as! String
                            UserDefaults.standard.set(strUserID, forKey: "socialUserID")
                            UserDefaults.standard.set("1", forKey: "InvitePopup")
                            UserDefaults.standard.synchronize()
                            
                            if dicData["ProfileImage"] as? String != nil
                            {
                                MBProgressHUD.showAdded(to: self.view, animated: true)
                                
                                let strImgURL = dicData["ProfileImage"] as? String
                                let imgURL = NSURL(string: strImgURL!)
                                
                                self.getDataFromUrl(url: imgURL! as URL) { data, response, error in
                                    guard let data = data, error == nil else { return }
                                    DispatchQueue.main.async() {
                                        
                                        self.imageProPic = UIImage(data: data)!
                                        self.saveProfileImageDocumentDirectory()
                                        
                                        
//                                        SVProgressHUD.show(withStatus: "Register", maskType: SVProgressHUDMaskType.clear)
                                        
                                        let logUser = QBUUser()
                                        logUser.login = "\(self.strPhoneNumber)"
                                        logUser.password = "\(self.strEmailAddress.lowercased)\(self.strPhoneNumber)"
                                        
//                                        SVProgressHUD.show(withStatus: "Register", maskType: SVProgressHUDMaskType.clear)
                                        QMServicesManager.instance().logIn(with: logUser) { (success, errorMessage) in
                                            
                                            guard success else {
//                                                SVProgressHUD.showError(withStatus: errorMessage)
                                                return
                                            }
                                            
                                            let deviceIdentifier: String = UIDevice.current.identifierForVendor!.uuidString
                                            
                                            let subscription: QBMSubscription! = QBMSubscription()
                                            subscription.notificationChannel = QBMNotificationChannel.APNS
                                            subscription.deviceUDID = deviceIdentifier
                                            subscription.deviceToken = UserDefaults.standard.value(forKey: "deviceTokenData") as? Data
                                            
                                            QBRequest.createSubscription(subscription, successBlock: { (response: QBResponse!, objects: [QBMSubscription]?) -> Void in
                                                
//                                                SVProgressHUD.showSuccess(withStatus: "Registered")
                                                
                                                MBProgressHUD.hide(for: self.view, animated: true)
                                                
                                                let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                                                self.navigationController?.pushViewController(tabVC, animated: true)
                                                
                                            }) { (response: QBResponse!) -> Void in
                                                
//                                                SVProgressHUD.showSuccess(withStatus: "Registered")
                                                
                                                MBProgressHUD.hide(for: self.view, animated: true)
                                                
                                                let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                                                self.navigationController?.pushViewController(tabVC, animated: true)
                                            }
                                            
                                        }
                                        
                                    }
                                }
                            }
                            else
                            {
//                                let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
//                                self.navigationController?.pushViewController(tabVC, animated: true)
                                
//                                SVProgressHUD.show(withStatus: "Register", maskType: SVProgressHUDMaskType.clear)
                                
                                let logUser = QBUUser()
                                logUser.login = "\(self.strPhoneNumber)"
                                logUser.password = "\(self.strEmailAddress)\(self.strPhoneNumber)"
                                
//                                SVProgressHUD.show(withStatus: "Register", maskType: SVProgressHUDMaskType.clear)
                                QMServicesManager.instance().logIn(with: logUser) { (success, errorMessage) in
                                    
                                    guard success else {
//                                        SVProgressHUD.showError(withStatus: errorMessage)
                                        return
                                    }
                                    
                                    let deviceIdentifier: String = UIDevice.current.identifierForVendor!.uuidString
                                    
                                    let subscription: QBMSubscription! = QBMSubscription()
                                    subscription.notificationChannel = QBMNotificationChannel.APNS
                                    subscription.deviceUDID = deviceIdentifier
                                    subscription.deviceToken = UserDefaults.standard.value(forKey: "deviceTokenData") as? Data
                                    
                                    QBRequest.createSubscription(subscription, successBlock: { (response: QBResponse!, objects: [QBMSubscription]?) -> Void in
                                        
//                                        SVProgressHUD.showSuccess(withStatus: "Registered")
                                        
                                        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                                        self.navigationController?.pushViewController(tabVC, animated: true)
                                        
                                    }) { (response: QBResponse!) -> Void in
                                        
//                                        SVProgressHUD.showSuccess(withStatus: "Registered")
                                        
                                        let tabVC = self.storyboard?.instantiateViewController(withIdentifier: "TabBarSocial") as! TabBarSocial
                                        self.navigationController?.pushViewController(tabVC, animated: true)
                                    }
                                    
                                }
                            }
                        }
                        else if dicRegResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicRegResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** Image URL Convert To Data ********** //
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    // ********** TextField Delegate Methods ********** //
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        if textField == txtFirstName || textField == txtLastName
        {
            if dataPrpPic.length == 0
            {
                let lblNameInitialize = UILabel()
                lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
                lblNameInitialize.textColor = UIColor.white
                
                if txtFirstName.text?.count != 0 && txtLastName.text?.count == 0
                {
                    lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!)
                }
                else if txtLastName.text?.count != 0 && txtFirstName.text?.count == 0
                {
                    lblNameInitialize.text = String(self.txtLastName.text!.characters.first!)
                }
                else if txtFirstName.text?.count != 0 && txtLastName.text?.count != 0
                {
                    lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
                }
                else
                {
                    lblNameInitialize.text = String("heyoo")
                }
                
                lblNameInitialize.textAlignment = NSTextAlignment.center
                lblNameInitialize.backgroundColor = UIColor.gray
                
                
                UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
                lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
                self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
            }
        }
    }
    
    func profileNameImaageGenerater()
    {
        let lblNameInitialize = UILabel()
        lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
        lblNameInitialize.textColor = UIColor.white
        
        if txtFirstName.text?.count != 0 && txtLastName.text?.count == 0
        {
            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!)
        }
        else if txtLastName.text?.count != 0 && txtFirstName.text?.count == 0
        {
            lblNameInitialize.text = String(self.txtLastName.text!.characters.first!)
        }
        else if txtFirstName.text?.count != 0 && txtLastName.text?.count != 0
        {
            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
        }
        else
        {
            lblNameInitialize.text = String("heyoo")
        }
        lblNameInitialize.textAlignment = NSTextAlignment.center
        lblNameInitialize.backgroundColor = UIColor.gray
        
        
        UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
        lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
        self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    // ********** Save Profile Picture Document Directory ********** //
    
    func saveProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        do {
            try UIImageJPEGRepresentation(imageProPic, 1.0)!.write(to: fileURL)
        } catch {
            print(error)
        }
    }
}






























