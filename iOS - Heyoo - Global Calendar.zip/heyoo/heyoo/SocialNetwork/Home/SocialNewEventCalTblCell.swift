//
//  SocialNewEventCalTblCell.swift
//  heyoo
//
//  Created by Intorque LLP on 27/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialNewEventCalTblCell: UITableViewCell {
    @IBOutlet weak var imgViewCalColor: UIImageView!
    @IBOutlet weak var lblCalendarName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
//        imgViewCalColor.layer.cornerRadius = imgViewCalColor.frame.size.width/2
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
