//
//  SocialSelectReminderVC.swift
//  heyoo
//
//  Created by Intorque LLP on 01/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

protocol reminderSelectionProtocol {
    func setSelectedReminder(selectReminder : String)
    func setSelectedReminderIndex(selectedIndex : String)
}

class SocialSelectReminderVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var delegate:reminderSelectionProtocol?
    
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var arrReminderSec1 = NSMutableArray()
    var arrReminderSec2 = NSMutableArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        arrReminderSec1.add("None")
        arrReminderSec2 = ["None", "At time of event", "5 minutes before", "10 minutes before", "30 minutes before", "1 hour before", "2 hours before", "1 day before", "2 days before", "1 week before"]
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    // ********** UITableviewDeleagete And Datasource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 10
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
//        if section == 0
//        {
//            return arrReminderSec1.count
//        }
//        else
//        {
            return arrReminderSec2.count
//        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        
//        if indexPath.section == 0
//        {
//            cell.textLabel?.text = (arrReminderSec1[indexPath.row] as! String)
//        }
//        else
//        {
            cell.textLabel?.text = (arrReminderSec2[indexPath.row] as! String)
//        }
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
//        if indexPath.section == 0
//        {
//            delegate?.setSelectedReminder(selectReminder: arrReminderSec1[indexPath.row] as! String)
//            delegate?.setSelectedReminderIndex(selectedIndex: "\(indexPath.row+1)")
//        }
//        else
//        {
            delegate?.setSelectedReminder(selectReminder: arrReminderSec2[indexPath.row] as! String)
            delegate?.setSelectedReminderIndex(selectedIndex: "\(indexPath.row+1)")
//        }
        
        self.navigationController?.popViewController(animated: true)
    }
    
}





























