//
//  collectNewEventMediaCell.swift
//  heyoo
//
//  Created by Intorque LLP on 18/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class collectNewEventMediaCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var imgViewPlayIcon: UIImageView!
    
}
