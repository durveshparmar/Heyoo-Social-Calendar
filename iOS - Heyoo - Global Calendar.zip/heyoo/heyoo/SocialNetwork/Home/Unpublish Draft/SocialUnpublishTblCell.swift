//
//  SocialUnpublishTblCell.swift
//  heyoo
//
//  Created by Intorque LLP on 02/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialUnpublishTblCell: UITableViewCell {
    @IBOutlet var viewMainBack: UIView!
    @IBOutlet var viewColor: UIView!
    @IBOutlet var lblTime: UILabel!
    @IBOutlet weak var imgView1: UIImageView!
    @IBOutlet weak var imgView2: UIImageView!
    @IBOutlet weak var imgView3: UIImageView!
    @IBOutlet weak var imgView4: UIImageView!
    @IBOutlet weak var lblSharedCount: UILabel!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var lblVideoCount: UILabel!
    @IBOutlet weak var lblMessageCount: UILabel!
    @IBOutlet weak var imgImage: UIImageView!
    @IBOutlet weak var imgVideo: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewMainBack.layer.shadowColor = UIColor.gray.cgColor
        viewMainBack.layer.shadowOffset = CGSize.zero
        viewMainBack.layer.shadowOpacity = 0.5 //0.4
        viewMainBack.layer.shadowRadius = 5 //3
        
        imgView4.layer.cornerRadius = imgView4.frame.size.width/2
        imgView3.layer.cornerRadius = imgView4.frame.size.width/2
        imgView2.layer.cornerRadius = imgView4.frame.size.width/2
        imgView1.layer.cornerRadius = imgView4.frame.size.width/2
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        
    }

}
