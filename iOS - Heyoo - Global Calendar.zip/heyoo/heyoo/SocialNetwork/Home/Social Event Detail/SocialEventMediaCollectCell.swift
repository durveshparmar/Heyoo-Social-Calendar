//
//  SocialEventMediaCollectCell.swift
//  heyoo
//
//  Created by Intorque LLP on 29/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialEventMediaCollectCell: UICollectionViewCell {
    @IBOutlet weak var imgViewImage: UIImageView!
    @IBOutlet weak var imgMediaPlayIcon: UIImageView!
    
}
