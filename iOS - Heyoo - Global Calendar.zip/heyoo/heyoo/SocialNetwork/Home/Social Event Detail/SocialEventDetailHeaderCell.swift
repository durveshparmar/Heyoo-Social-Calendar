//
//  SocialEventDetailHeaderCell.swift
//  heyoo
//
//  Created by Intorque LLP on 14/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialEventDetailHeaderCell: UITableViewCell {
    @IBOutlet weak var lblHeaderName: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
