//
//  SocialEditEventVC.swift
//  heyoo
//
//  Created by Gaurav Patel on 09/12/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire

class SocialEditEventVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, repeatSelectionProtocol, reminderSelectionProtocol, invitePeopleSelectProtocol {
    @IBOutlet weak var btnLoadCalendar: UIButton!
    @IBOutlet weak var imgViewIconStartClock: UIImageView!
    @IBOutlet weak var imgViewIconEndClock: UIImageView!
    @IBOutlet weak var viewDatePickerBack: UIView!
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var viewDateAndTime: UIView!
    @IBOutlet weak var viewMedia: UIView!
    @IBOutlet weak var viewLocation: UIView!
    @IBOutlet weak var viewInvite: UIView!
    @IBOutlet weak var viewNav: UIView!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var lblCalendarName: UITextField!
    @IBOutlet weak var viewCalendarColor: UIView!
    @IBOutlet weak var txtEventName: UITextField!
    @IBOutlet weak var collectEventColor: UICollectionView!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var lblStartTime: UILabel!
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var lblEndTime: UILabel!
    @IBOutlet weak var lblRepeat: UILabel!
    @IBOutlet weak var imgViewAllDayCheck: UIImageView!
    @IBOutlet weak var tblViewInviteList: UITableView!
    @IBOutlet weak var tblViewCalendar: UITableView!
    @IBOutlet weak var imgViewAllDay: UIImageView!
    @IBOutlet weak var datePickerSelectDate: UIDatePicker!
    
    @IBOutlet weak var txtEventLocation: UITextField!
    @IBOutlet weak var txtEventNotes: UITextField!
    @IBOutlet weak var txtEventReminder: UITextField!
    @IBOutlet weak var btnPublish: UIButton!
    @IBOutlet weak var btnSaveAsDraft: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var viewPopup = UIView()
    var strSelectColor = String()
    var strSelectTick = String()
    var arrColor = NSArray()
    var today = Date()
    var startDate = Date()
    var endDate = Date()
    var isStartDate = Bool()
    var strRepeat = String()
    var strRemiderIndex = String()
    var arrInvitePeople = NSMutableArray()
    var strAllDay = String()
    var dicSelectedCalendar = NSMutableDictionary()
    var arrCalendarData = NSArray()
    
    var dicEventDetailPass = NSDictionary()
    var strIsPublishOrNot = String()
    var strCalendarMemberFetchPopup = String()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        AllBackViewMethods()
        
        if strIsPublishOrNot == "Publish"
        {
            btnPublish.setTitle("Update", for: .normal)
            btnSaveAsDraft.isHidden = true
        }
        else
        {
            btnPublish.setTitle("Publish", for: .normal)
            btnSaveAsDraft.isHidden = false
        }
        
        arrColor = [customColor.color1, customColor.color2, customColor.color3, customColor.color4, customColor.color5, customColor.color6, customColor.color7]
        
        viewCalendarColor.layer.cornerRadius = viewCalendarColor.frame.size.height / 2
        btnLoadCalendar.isEnabled = false
        self.allDataSetInUI()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionDatePickerDone(_ sender: UIButton)
    {
        viewDatePickerBack.isHidden = true
    }
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionViewMedia(_ sender: UIButton)
    {
        let mediaVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEditEventMediaListVC") as! SocialEditEventMediaListVC
        mediaVC.strEventID = dicEventDetailPass["EventID"] as! String
        mediaVC.strUserIDOwner = dicEventDetailPass["UserID"] as! String
        mediaVC.dicEventDetailPass = dicEventDetailPass
        self.navigationController?.pushViewController(mediaVC, animated: true)
    }
    
    @IBAction func ActionRepeat(_ sender: UIButton)
    {
        let repeatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialSelectRepeatVC") as! SocialSelectRepeatVC
        repeatVC.strRepeatIndex = strRepeat
        repeatVC.delegate = self
        self.navigationController?.pushViewController(repeatVC, animated: true)
    }
    
    @IBAction func ActionReminder(_ sender: UIButton)
    {
        let reminderVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialSelectReminderVC") as! SocialSelectReminderVC
        reminderVC.delegate = self
        self.navigationController?.pushViewController(reminderVC, animated: true)
    }
    
    @IBAction func ActionInvitePeople(_ sender: UIButton)
    {
        let inviteVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialInvitePeopleVC") as! SocialInvitePeopleVC
        inviteVC.arrInvitedPeople = arrInvitePeople
        inviteVC.delegate = self
        self.navigationController?.pushViewController(inviteVC, animated: true)
    }
    
    @IBAction func ActionAllDay(_ sender: UIButton)
    {
        if strAllDay == "1"
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxOrange")
            strAllDay = "2"
            
            datePickerSelectDate.datePickerMode = .date
            imgViewIconStartClock.isHidden = true
            imgViewIconEndClock.isHidden = true
            lblStartTime.isHidden = true
            lblEndTime.isHidden = true
        }
        else
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxBlack")
            strAllDay = "1"
            
            datePickerSelectDate.datePickerMode = .dateAndTime
            imgViewIconStartClock.isHidden = false
            imgViewIconEndClock.isHidden = false
            lblStartTime.isHidden = false
            lblEndTime.isHidden = false
        }
    }
    
    @IBAction func ActionLoadCalendar(_ sender: UIButton)
    {
        if arrCalendarData.count == 0
        {
            getAllCalendarAPICall()
        }
        else
        {
            showCalendarSelectionPopup()
        }
    }
    
    @IBAction func ActionPublish(_ sender: UIButton)
    {
        updatePublishAndDraftEventAPICall(strEventType: "Publish")
    }
    
    @IBAction func ActionSaveAsDraft(_ sender: UIButton)
    {
        updatePublishAndDraftEventAPICall(strEventType: "Draft")
    }
    
    @IBAction func ActionStartDateSelect(_ sender: UIButton)
    {
        isStartDate = true
        
        viewDatePickerBack.isHidden = false
        datePickerSelectDate.minimumDate = today
        
        if startDate > today
        {
            datePickerSelectDate.date = startDate
        }
        else
        {
            datePickerSelectDate.date = today
        }
    }
    
    @IBAction func ActionEndDateSelect(_ sender: UIButton)
    {
        isStartDate = false
        viewDatePickerBack.isHidden = false
        
        datePickerSelectDate.datePickerMode = UIDatePickerMode.dateAndTime
        if startDate > endDate
        {
//            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
            datePickerSelectDate.minimumDate = startDate
            datePickerSelectDate.date = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
        }
        else
        {
//            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
            datePickerSelectDate.minimumDate = startDate
            datePickerSelectDate.date = endDate
        }
    }
    
    // ********** UIDatePickerView Methods ********** //
    @IBAction func startDatePickerHandle(_ sender: UIDatePicker)
    {
        if isStartDate == true
        {
            lblStartDate.text = self.dateFormatter.string(from: sender.date)
            lblStartTime.text = self.timeFormatter.string(from: sender.date)
            
            startDate = sender.date
            
            let startTimeInterval = Int(startDate.timeIntervalSinceReferenceDate)
            let endTimeInterval = Int(endDate.timeIntervalSinceReferenceDate)
            
            if startTimeInterval > endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else if startTimeInterval == endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
        }
        else
        {
            endDate = sender.date
            lblEndDate.text = self.dateFormatter.string(from: endDate)
            lblEndTime.text = self.timeFormatter.string(from: endDate)
        }
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    fileprivate lazy var timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        return formatter
    }()
    
    
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrColor.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellColor : collectColorCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! collectColorCell
        
        cellColor.viewColor.backgroundColor = arrColor[indexPath.item] as? UIColor
        
        if strSelectTick == "\(indexPath.item)"
        {
            cellColor.imgViewTick.isHidden = false
        }
        else
        {
            cellColor.imgViewTick.isHidden = true
        }
        
        return cellColor
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectEventColor.frame.size.height, height: collectEventColor.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        viewNav.backgroundColor = arrColor[indexPath.item] as? UIColor
        strSelectColor = "\(indexPath.item+1)"
        strSelectTick = "\(indexPath.row)"
        collectEventColor.reloadData()
    }
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if tableView == tblViewCalendar
        {
            return 1
        }
        else
        {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView == tblViewCalendar
        {
            return arrCalendarData.count
        }
        else
        {
            return arrInvitePeople.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if tableView == tblViewCalendar
        {
            let cellCal : SocialNewEventCalTblCell = tableView.dequeueReusableCell(withIdentifier: "cellCalID") as! SocialNewEventCalTblCell
            
            let dicCalendar = arrCalendarData[indexPath.row] as! NSDictionary
            
            cellCal.lblCalendarName.text = dicCalendar.value(forKey: "FullName") as? String
            cellCal.imgViewCalColor.backgroundColor = postEventColorInTableCell(strColor: dicCalendar.value(forKey: "Color") as! String)
            cellCal.imgViewCalColor.layer.cornerRadius = cellCal.imgViewCalColor.frame.size.width/2
            
            cellCal .selectionStyle = UITableViewCellSelectionStyle.none
            return cellCal
        }
        else
        {
            let cell : UITableViewCell = (tableView.dequeueReusableCell(withIdentifier: "cell"))!
            
            let dicPeople = arrInvitePeople[indexPath.row] as! NSDictionary
            
            if let strName = dicPeople["FullName"]
            {
                cell.textLabel?.text = strName as? String
            }
            else
            {
                cell.textLabel?.text = (dicPeople["FullName"] as! String)
            }
            
            
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if tableView == tblViewCalendar
        {
            let dicTempCalendar = arrCalendarData[indexPath.row] as! NSDictionary
            
            dicSelectedCalendar = NSMutableDictionary()
            dicSelectedCalendar = dicTempCalendar.mutableCopy() as! NSMutableDictionary
            
            lblCalendarName.text = dicSelectedCalendar.value(forKey: "FullName") as? String
            viewCalendarColor.backgroundColor = postEventColorInTableCell(strColor: dicSelectedCalendar.value(forKey: "Color") as! String)
            
            self.tblViewCalendar.isHidden = true
            self.viewPopup.isHidden = true
            
            if strCalendarMemberFetchPopup == ""
            {
                strCalendarMemberFetchPopup = "1"
                let alertCntrl = UIAlertController(title: "Alert", message: "Caledar Members won't be fetch, you need to add manually.", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alertCntrl, animated: true, completion: nil)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if tableView == tblViewInviteList
        {
            arrInvitePeople.removeObject(at: indexPath.row)
            tblViewInviteList.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if tableView == tblViewCalendar
        {
            return 1
        }
        else
        {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        if tableView == tblViewCalendar
        {
            return 1
        }
        else
        {
            return 0
        }
    }
    
    
    // ********** All Data Set In UI ********** //
    func allDataSetInUI()
    {
        // -------------- Title And Color Set -------------------
        viewNav.backgroundColor = postEventColorInTableCell(strColor: dicEventDetailPass["Color"] as! String)
        lblEventName.text = dicEventDetailPass["Title"] as? String
        lblCalendarName.text = dicEventDetailPass["CalendarName"] as? String
        viewCalendarColor.backgroundColor = postEventColorInTableCell(strColor: dicEventDetailPass["CalendarColor"] as! String)
        txtEventName.text = dicEventDetailPass["Title"] as? String
        
        strSelectColor = "\(dicEventDetailPass["Color"] as! String)"
        let strSelColorTemp = dicEventDetailPass["Color"] as! String
        let selColor:Int = Int(strSelColorTemp)!
        strSelectTick = "\(selColor-1)"
        collectEventColor.reloadData()
        
        
        // --------------- Location View Set -------------------
        txtEventLocation.text = dicEventDetailPass["Location"] as? String
        txtEventNotes.text = dicEventDetailPass["Notes"] as? String
        
        let arrReminderList = ["None", "At time of event", "5 minutes before", "10 minutes before", "30 minutes before", "1 hour before", "2 hours before", "1 day before", "2 days before", "1 week before"] as NSArray
        
        strRemiderIndex = dicEventDetailPass["Reminder"] as! String
        if dicEventDetailPass["Reminder"] as! String == "0"
        {
            txtEventReminder.text = "None"
        }
        else
        {
            let strReminIndex = dicEventDetailPass["Reminder"] as! String
            let indexReminder = Int(strReminIndex)
            
            txtEventReminder.text = arrReminderList[indexReminder! - 1] as? String
        }
        
        
        // -------------- Invite View Set ----------------- //
        let arrGoingInvitee = dicEventDetailPass["GoingInvitees"] as! NSArray
        let arrHaveNotReplieInvitee = dicEventDetailPass["HaveNotRepliedInvitees"] as! NSArray
        let arrMaybeInvitee = dicEventDetailPass["MaybeInvitees"] as! NSArray
        let arrNoInvitee = dicEventDetailPass["NoInvitees"] as! NSArray
        
        
//        let dicPeople = arrCalMember[i] as! NSDictionary
//        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
//        if strUserID != dicPeople["UserID"] as? String
//        {
//            arrInvitePeople.add(dicPeople)
//        }
        
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        arrInvitePeople = NSMutableArray()
        for i in (0..<arrGoingInvitee.count)
        {
            let dicTempInvitee = arrGoingInvitee[i] as! NSDictionary
            if strUserID != dicTempInvitee["UserID"] as? String
            {
                arrInvitePeople.add(dicTempInvitee)
            }
        }
        
        for i in (0..<arrHaveNotReplieInvitee.count)
        {
            let dicTempInvitee = arrHaveNotReplieInvitee[i] as! NSDictionary
            if strUserID != dicTempInvitee["UserID"] as? String
            {
                arrInvitePeople.add(dicTempInvitee)
            }
        }

        for i in (0..<arrMaybeInvitee.count)
        {
            let dicTempInvitee = arrMaybeInvitee[i] as! NSDictionary
            if strUserID != dicTempInvitee["UserID"] as? String
            {
                arrInvitePeople.add(dicTempInvitee)
            }
        }

        for i in (0..<arrNoInvitee.count)
        {
            let dicTempInvitee = arrNoInvitee[i] as! NSDictionary
            if strUserID != dicTempInvitee["UserID"] as? String
            {
                arrInvitePeople.add(dicTempInvitee)
            }
        }
        print(arrInvitePeople)
        
        
        // --------------- Date Selection View Set --------------
        strAllDay = dicEventDetailPass["AllDay"] as! String
        if strAllDay == "2"
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxOrange")
            
            datePickerSelectDate.datePickerMode = .date
            imgViewIconStartClock.isHidden = true
            imgViewIconEndClock.isHidden = true
            lblStartTime.isHidden = true
            lblEndTime.isHidden = true
        }
        else
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxBlack")
            
            datePickerSelectDate.datePickerMode = .dateAndTime
            imgViewIconStartClock.isHidden = false
            imgViewIconEndClock.isHidden = false
            lblStartTime.isHidden = false
            lblEndTime.isHidden = false
        }
        
        
        
        let inFormatter = DateFormatter()
        inFormatter.dateFormat = "HH:mm:ss"
        let outFormatter = DateFormatter()
        outFormatter.dateFormat = "hh:mm a"
        
        let inStartTime = dicEventDetailPass["StartTime"] as! String
        let dateTimeStart = inFormatter.date(from: inStartTime)!
        let inEndTime = dicEventDetailPass["EndTime"] as! String
        let dateTimeEnd = inFormatter.date(from: inEndTime)!
        lblStartTime.text = outFormatter.string(from: dateTimeStart)
        lblEndTime.text = outFormatter.string(from: dateTimeEnd)
        
        let inDateFormatter = DateFormatter()
        inDateFormatter.dateFormat = "yyyy-MM-dd"
        let outDateFormatter = DateFormatter()
        outDateFormatter.dateFormat = "EEE, MMM dd, yyyy" //"MMM dd, yyyy"
        
        let inStartDate = dicEventDetailPass["StartDate"] as! String
        let dateDateStart = inDateFormatter.date(from: inStartDate)!
        let inEndDate = dicEventDetailPass["EndDate"] as! String
        let dateDateEnd = inDateFormatter.date(from: inEndDate)!
        lblStartDate.text = outDateFormatter.string(from: dateDateStart)
        lblEndDate.text = outDateFormatter.string(from: dateDateEnd)
        
        print(dicEventDetailPass)
        
//        let dateFormatStartEndDate = DateFormatter()
//        inDateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
//
//        let strStartDateFull = "\(dicEventDetailPass["StartDate"] as! String) \(dicEventDetailPass["StartTime"] as! String)"
////        startDate = dateFormatStartEndDate.date(from: strStartDateFull)!
//        print(strStartDateFull)
//        let tempStartDate = dateFormatStartEndDate.date(from: strStartDateFull)!
//        print(tempStartDate)
//
//
//        let strEndDateFull = "\(dicEventDetailPass["EndDate"] as! String) \(dicEventDetailPass["EndTime"] as! String)"
//        endDate = dateFormatStartEndDate.date(from: strEndDateFull)!
//        print(strEndDateFull)
//        print(endDate)
        
        
        let arrStartDate = inStartDate.components(separatedBy: "-")
        let arrStartTime = inStartTime.components(separatedBy: ":")
        
        var startDateComponent = DateComponents()
        startDateComponent.year = Int(arrStartDate[0])
        startDateComponent.month = Int(arrStartDate[1])
        startDateComponent.day = Int(arrStartDate[2])
        startDateComponent.hour = Int(arrStartTime[0])
        startDateComponent.minute = Int(arrStartTime[1])
        startDateComponent.second = Int(arrStartTime[2])
        
        startDate = Calendar(identifier: .gregorian).date(from: startDateComponent)!
        print(startDate)
        
        let arrEndDate = inEndDate.components(separatedBy: "-")
        let arrEndTime = inEndTime.components(separatedBy: ":")
        
        var endDateComponent = DateComponents()
        endDateComponent.year = Int(arrEndDate[0])
        endDateComponent.month = Int(arrEndDate[1])
        endDateComponent.day = Int(arrEndDate[2])
        endDateComponent.hour = Int(arrEndTime[0])
        endDateComponent.minute = Int(arrEndTime[1])
        endDateComponent.second = Int(arrEndTime[2])
        
        endDate = Calendar(identifier: .gregorian).date(from: endDateComponent)!
        
        dicSelectedCalendar = NSMutableDictionary()
        dicSelectedCalendar.setValue(dicEventDetailPass["CalendarColor"] as! String, forKey: "Color")
        dicSelectedCalendar.setValue(dicEventDetailPass["CalendarID"] as! String, forKey: "CalendarID")
        dicSelectedCalendar.setValue(dicEventDetailPass["CalendarName"] as! String, forKey: "FullName")
        
        
        let arrRepeat = ["Never", "Every Day", "Every Week", "Every 2 Weeks", "Every Month", "Every Year"] as NSArray
        let strRepeatIndex = dicEventDetailPass["Repeat"] as! String
        strRepeat = dicEventDetailPass["Repeat"] as! String
        let indexRepeat = Int(strRepeatIndex)
        lblRepeat.text = arrRepeat[indexRepeat! - 1] as? String
        
    }
    
    
    // ********** Repeat Selection Protocol Methods ********** //
    func setSelectedRepeatIndex(selectedIndex: String)
    {
        strRepeat = selectedIndex
    }
    
    func setSelectedRepeat(selectRepeat: String)
    {
        lblRepeat.text = selectRepeat
    }
    
    // ********** Reminder Selection Protocol Methods ********** //
    
    func setSelectedReminder(selectReminder: String)
    {
        txtEventReminder.text = selectReminder
    }
    
    func setSelectedReminderIndex(selectedIndex: String)
    {
        print(selectedIndex)
        strRemiderIndex = selectedIndex
    }
    
    
    // ********** Invite People Selection Protocol Methods ********** //
    func setSelectedInvitedPeople(selectInvite: NSMutableArray)
    {
        arrInvitePeople = NSMutableArray()
        arrInvitePeople = selectInvite
        print(arrInvitePeople)
        tblViewInviteList.reloadData()
    }
    
    // ********** All Backview Shadow Method ********** //
    func AllBackViewMethods()
    {
        viewTitle.layer.shadowColor = UIColor.lightGray.cgColor
        viewTitle.layer.shadowOpacity = 0.4
        viewTitle.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewTitle.layer.shadowRadius = 3
        
        viewDateAndTime.layer.shadowColor = UIColor.lightGray.cgColor
        viewDateAndTime.layer.shadowOpacity = 0.4
        viewDateAndTime.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewDateAndTime.layer.shadowRadius = 3
        
        viewMedia.layer.shadowColor = UIColor.lightGray.cgColor
        viewMedia.layer.shadowOpacity = 0.4
        viewMedia.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewMedia.layer.shadowRadius = 3
        
        viewLocation.layer.shadowColor = UIColor.lightGray.cgColor
        viewLocation.layer.shadowOpacity = 0.4
        viewLocation.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLocation.layer.shadowRadius = 3
        
        viewInvite.layer.shadowColor = UIColor.lightGray.cgColor
        viewInvite.layer.shadowOpacity = 0.4
        viewInvite.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewInvite.layer.shadowRadius = 3
        
        btnPublish.layer.shadowColor = UIColor.lightGray.cgColor
        btnPublish.layer.shadowOpacity = 0.4
        btnPublish.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPublish.layer.shadowRadius = 5.0
        
        btnSaveAsDraft.layer.shadowColor = UIColor.lightGray.cgColor
        btnSaveAsDraft.layer.shadowOpacity = 0.4
        btnSaveAsDraft.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnSaveAsDraft.layer.shadowRadius = 5.0
    }
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == viewPopup
            {
                viewPopup.isHidden = true
                tblViewCalendar.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    func showCalendarSelectionPopup()
    {
        self.tblViewCalendar.isHidden = false
        
        self.viewPopup.frame = self.view.bounds
        self.viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        self.viewPopup.addSubview(self.tblViewCalendar)
        self.view.addSubview(self.viewPopup)
        
        self.viewPopup.isHidden = false
        
        self.tblViewCalendar.frame.size.height = 1
        
        if self.tblViewCalendar.contentSize.height > self.view.frame.size.height - self.tblViewCalendar.frame.origin.y - 30
        {
            UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseOut, animations: {
                self.tblViewCalendar.frame.size.height = self.view.frame.size.height - self.tblViewCalendar.frame.origin.y - 30
            }, completion: nil)
        }
        else
        {
            UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseOut, animations: {
                self.tblViewCalendar.frame.size.height = self.tblViewCalendar.contentSize.height
            }, completion: nil)
            
        }
    }
    
    
    // ********** Gel All Calendar Api Call ********** //
    func getAllCalendarAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Userid":strUserID, "Val_Type":"2", "Action":"GetAllCalendars"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicGetAllCalendar = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicGetAllCalendar?["status"] as? String == "success"
                        {
                            self.arrCalendarData = dicGetAllCalendar?["data"] as! NSArray
                            self.tblViewCalendar.reloadData()
                            
                            self.showCalendarSelectionPopup()
                            
                        }
                        else if dicGetAllCalendar?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicGetAllCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    // ********** Update Publish And Draft Event WebService Call ********** //
    func updatePublishAndDraftEventAPICall(strEventType: String)
    {
        print(dicSelectedCalendar)
        print(strSelectColor)
        print(txtEventName.text as Any)
        print("Start Date = \(String(describing: lblStartDate.text))")
        print("Start Time = \(String(describing: lblStartTime.text))")
        print("End Date = \(String(describing: lblEndDate.text))")
        print("End Time = \(String(describing: lblEndTime.text))")
        print("Location = \(String(describing: txtEventLocation.text))")
        print("Notes = \(String(describing: txtEventNotes.text))")
        
        
        let strCalCheck = dicSelectedCalendar.value(forKey: "CalendarID") as? String
        if strCalCheck?.count == 0 || strCalCheck == nil
        {
            let alertControl = UIAlertController(title: nil, message: "Please Select Calendar", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if txtEventName.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Enter Event Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if strSelectColor.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Choose Event Color.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = dicEventDetailPass["UserID"] as? String
            let strCalID = dicSelectedCalendar.value(forKey: "CalendarID") as? String
            let strEventID = dicEventDetailPass["EventID"] as? String
            

            let strStartDateServer = self.dateServerFormatter.string(from: startDate)
            let strStartTimeServer = self.timeServerFormatter.string(from: startDate)

            let strEndDateServer = self.dateServerFormatter.string(from: endDate)
            let strEndTimeServer = self.timeServerFormatter.string(from: endDate)
            
            let arrAllPeopleUserID = NSMutableArray()
            for dicTempCheck in arrInvitePeople
            {
                let dicTemp = dicTempCheck as! NSDictionary
                let strSelectedU_ID = dicTemp["UserID"] as! String

                arrAllPeopleUserID.add(strSelectedU_ID)
            }
            
            let jsonDataForInvitePeople: Data? = try? JSONSerialization.data(withJSONObject: arrAllPeopleUserID, options: [])
            let jsonStringForInvitePeople = String(data: jsonDataForInvitePeople ?? Data(), encoding: .utf8)
            
            var strEventStatus = String()
            if strEventType == "Publish"
            {
                strEventStatus = "2"
            }
            else
            {
                strEventStatus = "1"
            }
            
            var strAction = String()
            if strIsPublishOrNot == "Publish"
            {
                strAction = "Update"
            }
            else
            {
                strAction = "Publish"
            }
            
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":strAction, "Val_Eventid":strEventID, "Val_Calendarid":strCalID, "Val_Userid":strUserID, "Val_Title":txtEventName.text! as String, "Val_Color":strSelectColor, "Val_Startdate":strStartDateServer, "Val_Starttime":strStartTimeServer, "Val_EndDate":strEndDateServer, "Val_Endtime":strEndTimeServer, "Val_Allday":strAllDay, "Val_Repeat":strRepeat, "Val_Location":txtEventLocation.text! as String, "Val_Notes":txtEventNotes.text! as String, "Val_Reminder":strRemiderIndex, "Val_InvitedUsers": jsonStringForInvitePeople, "Val_Status":strEventStatus]
            print(parameters)
            
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in

                for (key,value) in parameters {
                    
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }

            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in

                switch encodingResult {

                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in

                        print(response.description)

                        let dicUpdateResponse = response.result.value as? [String: Any]

                        MBProgressHUD.hide(for: self.view, animated: true)

                        if dicUpdateResponse?["status"] as? String == "success"
                        {
//                            if strEventType == "Publish"
//                            {
//                                let alertControl = UIAlertController(title: "Event Published", message: "Members Invited to the event will be notified.", preferredStyle: .alert)
//                                alertControl.addAction(UIAlertAction(title: "Got it!", style: .default, handler: { (gotIt:UIAlertAction) in
//
//                                    self.navigationController?.popViewController(animated: true)
//                                }))
//                                self.present(alertControl, animated: true, completion: nil)
//
//                            }
//                            else
//                            {
//                                self.navigationController?.popViewController(animated: true)
//                            }
                            
                            self.navigationController?.popViewController(animated: true)
                        }
                        else if dicUpdateResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):

                    MBProgressHUD.hide(for: self.view, animated: true)

                    print(encodingError)
                }
            }
        }
    }
    
    // ********** ServerSide Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "YYYY-MM-dd"
        return formatter
    }()
    
    fileprivate lazy var timeServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()

}


























