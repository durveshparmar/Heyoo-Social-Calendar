//
//  SocialEventDetailVC.swift
//  heyoo
//
//  Created by Intorque LLP on 13/11/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
import Alamofire
import Quickblox
import QMChatViewController
import QMServices


class SocialEventDetailVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate, UITextViewDelegate, QMPlaceHolderTextViewPasteDelegate, QMInputToolbarDelegate, QMChatServiceDelegate, QMChatAttachmentServiceDelegate, QMChatConnectionDelegate, QMChatCellDelegate, QMDeferredQueueManagerDelegate, QMChatDataSourceDelegate, QMChatCollectionViewDelegateFlowLayout, QMChatCollectionViewDataSource {
    
//    QMChatCollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource
//    QMChatCollectionViewDataSource, QMChatCollectionViewDelegateFlowLayout, QMChatDataSourceDelegate
    
    @IBOutlet weak var inputToolbar: QMInputToolbar!
    @IBOutlet weak var collectionView: QMChatCollectionView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var strEventID = String()
    var dicEventDetPass = NSDictionary()
    var arrMemberList = NSArray()
    var totalUserCount = Int()
    var strGroupDate = String()
    
    
    
    
    // ********* Chat Using Data ********* //
    var qmChatVC = QMChatViewController()
    var willResignActiveBlock: AnyObject?
    var attachmentCellsMap: NSMapTable<AnyObject, AnyObject>!
    var detailedCells: Set<String> = []
    var typingTimer: Timer?
    let maxCharactersNumber = 0 // 0 - unlimited and other like 10 Limit
    var dialog: QBChatDialog!
//    var senderID = UInt()
//    var senderDisplayName = String()
//    var heightForSectionHeader = CGFloat()
    var chatDataSource = QMChatDataSource()
    var enableTextCheckingTypes = NSTextCheckingTypes()
    var unreadMessages: [QBChatMessage]?
    var selectedIndexPathForMenu = IndexPath()
    var topContentAdditionalInset = CGFloat()
    
    @nonobjc var senderID = UInt()
    @nonobjc var senderDisplayName = String()
    @nonobjc var heightForSectionHeader = CGFloat()
    
    
    
    
    
    
    
    @IBOutlet weak var btnYes: UIButton!
    @IBOutlet weak var btnMaybe: UIButton!
    @IBOutlet weak var btnNo: UIButton!
    @IBOutlet weak var imgViewYes: UIImageView!
    @IBOutlet weak var imgViewMaybe: UIImageView!
    @IBOutlet weak var imgViewNo: UIImageView!
    @IBOutlet weak var mediaImg1: UIImageView!
    @IBOutlet weak var mediaImg2: UIImageView!
    @IBOutlet weak var mediaImg3: UIImageView!
    @IBOutlet weak var mediaImg4: UIImageView!
    @IBOutlet weak var mediaImg5: UIImageView!
    @IBOutlet weak var mediaPlayICon1: UIImageView!
    @IBOutlet weak var mediaPlayICon2: UIImageView!
    @IBOutlet weak var mediaPlayICon3: UIImageView!
    @IBOutlet weak var mediaPlayICon4: UIImageView!
    @IBOutlet weak var mediaPlayICon5: UIImageView!
    @IBOutlet weak var lblMediaCount: UILabel!
    
    @IBOutlet weak var viewNave: UIView!
    @IBOutlet weak var viewTabOverDiscuss: UIView!
    @IBOutlet weak var viewCalName: UIView!
    @IBOutlet weak var viewEventMedia: UIView!
    @IBOutlet weak var viewLocation: UIView!
    @IBOutlet weak var tblViewInvite: UITableView!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var viewCalColor: UIView!
    @IBOutlet weak var lblCalendarName: UILabel!
    @IBOutlet weak var lblStartEndDate: UILabel!
    @IBOutlet weak var lblStartEndTime: UILabel!
    @IBOutlet weak var lblEventLocation: UILabel!
    @IBOutlet weak var lblEventNotes: UILabel!
    @IBOutlet weak var lblEventReminder: UILabel!
    @IBOutlet weak var lblEventRepeat: UILabel!
    @IBOutlet weak var imgViewIconOverview: UIImageView!
    @IBOutlet weak var imgViewIconDiscuss: UIImageView!
    @IBOutlet weak var collectViewMedia: UICollectionView!
    @IBOutlet weak var viewMediaPlaceholder: UIView!
    @IBOutlet weak var viewImagePreview: UIView!
    @IBOutlet weak var imgViewPreviewImage: UIImageView!
    @IBOutlet weak var btnEditEvent: UIButton!
    @IBOutlet weak var scrollViewMain: UIScrollView!
    
    @IBOutlet weak var MainViewWidth: NSLayoutConstraint!
    @IBOutlet weak var tblViewWidth: NSLayoutConstraint!
    @IBOutlet weak var chatMainViewWidth: NSLayoutConstraint!
    
    var dicEventDetailData = NSDictionary()
    var arrEventImages = NSArray()
    var arrEventVideos = NSArray()
    var arrGoingInvite = NSArray()
    var arrMaybeInvite = NSArray()
    var arrNoInvite = NSArray()
    var arrHaveNotRepliedInvite = NSArray()
    var arrMediaTemp = NSMutableArray()
    var strTopTabSelect = String()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.inputToolbar?.contentView?.textView?.placeHolder = "MESSAGE_PLACEHOLDER"
        self.inputToolbar.delegate = self;
        self.inputToolbar.contentView.textView.delegate = self;
        self.inputToolbar.contentView.rightBarButtonItem = self.sendButtonItem()
        self.chatDataSource = QMChatDataSource()
        self.chatDataSource.delegate = self
        
        MainViewWidth.constant = self.view.frame.size.width * 2
        tblViewWidth.constant = self.view.frame.size.width
        chatMainViewWidth.constant = self.view.frame.size.width
        
        imgViewIconOverview.image = imgViewIconOverview.image!.withRenderingMode(.alwaysTemplate)
        imgViewIconOverview.tintColor = UIColor .lightGray
        strTopTabSelect = "1"
        
        print(dicEventDetPass)
        
        self.quickbloxCurrentUserAndLoadMessage()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
//        let swipeGestureInBackVC = UISwipeGestureRecognizer(target: self, action: #selector(swipeToBackPop))
//        swipeGestureInBackVC.direction = .right
//        self.view.addGestureRecognizer(swipeGestureInBackVC)
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        self.allBackViewShadow()
        self.eventDetailAPICall()
        self.updateCollectionViewInsets()
        
//        self.collectionView.transform = CGAffineTransformMake(1, 0, 0, -1, 0, 0);
        self.collectionView.transform = CGAffineTransform(a: 1, b: 0, c: 0, d: -1, tx: 0, ty: 0)
        
        
        // QuickBlox Code ---------------------
        self.queueManager().add(self)
        
        ServicesManager.instance().chatService.connect(completionBlock: nil)
        
        self.willResignActiveBlock = NotificationCenter.default.addObserver(forName: NSNotification.Name.UIApplicationWillResignActive, object: nil, queue: nil) { [weak self] (notification) in
            
            self?.fireSendStopTypingIfNecessary()
        }
        //  ------------------------------------
        
    }
    
    override func viewDidDisappear(_ animated: Bool)
    {
        if let willResignActive = self.willResignActiveBlock {
            NotificationCenter.default.removeObserver(willResignActive)
        }
        
        // Resetting current dialog ID.
//        ServicesManager.instance().currentDialogID = ""
        
        // clearing typing status blocks
        self.dialog.clearTypingStatusBlocks()
        
        self.queueManager().remove(self)
    }
    
//    @objc func swipeToBackPop()
//    {
//        self.navigationController?.popViewController(animated: true)
//    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionYes(_ sender: UIButton)
    {
        imgViewYes.image = UIImage(named: "iconCheckBoxOrange")
        imgViewMaybe.image = UIImage(named: "iconCheckBoxBlack")
        imgViewNo.image = UIImage(named: "iconCheckBoxBlack")
        
        self.yesMaybeNoAPICall(strAction: "4")
    }
    @IBAction func ActionMaybe(_ sender: UIButton)
    {
        imgViewYes.image = UIImage(named: "iconCheckBoxBlack")
        imgViewMaybe.image = UIImage(named: "iconCheckBoxOrange")
        imgViewNo.image = UIImage(named: "iconCheckBoxBlack")
        
        self.yesMaybeNoAPICall(strAction: "3")
    }
    @IBAction func ActionNo(_ sender: UIButton)
    {
        imgViewYes.image = UIImage(named: "iconCheckBoxBlack")
        imgViewMaybe.image = UIImage(named: "iconCheckBoxBlack")
        imgViewNo.image = UIImage(named: "iconCheckBoxOrange")
        
        self.yesMaybeNoAPICall(strAction: "2")
    }
    
    @IBAction func ActionEditEvent(_ sender: UIButton)
    {
        let editEventVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEditEventVC") as! SocialEditEventVC
        editEventVC.dicEventDetailPass = dicEventDetailData
        editEventVC.strIsPublishOrNot = "Publish"
        self.navigationController?.pushViewController(editEventVC, animated: true)
    }
    
    @IBAction func ActionMediaOpen(_ sender: UIButton)
    {
        if arrMediaTemp.count != 0
        {
            let imgPreviewVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventMediaPreviewVC") as! SocialEventMediaPreviewVC
            imgPreviewVC.arrAllMedia = arrMediaTemp
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
            UIView.setAnimationDuration(0.75)
            self.navigationController?.pushViewController(imgPreviewVC, animated: false)
            UIView.setAnimationTransition(UIViewAnimationTransition.flipFromRight, for: (self.navigationController?.view)!, cache: false)
            UIView.commitAnimations()
         
        }
        
    }
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionOverview(_ sender: UIButton)
    {
        strTopTabSelect = "1"
        imgViewIconOverview.image = imgViewIconOverview.image!.withRenderingMode(.alwaysTemplate)
        imgViewIconOverview.tintColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
        
        imgViewIconDiscuss.image = imgViewIconDiscuss.image!.withRenderingMode(.alwaysTemplate)
        imgViewIconDiscuss.tintColor = UIColor .lightGray
        
        scrollViewMain.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        
        if dicEventDetailData["EventEditable"] as! String == "2"
        {
            btnEditEvent.isHidden = false
        }
        else
        {
            btnEditEvent.isHidden = true
        }
    }
    
    @IBAction func ActionDiscuss(_ sender: UIButton)
    {
        if totalUserCount != 1 {
            
            strTopTabSelect = "2"
            imgViewIconDiscuss.image = imgViewIconDiscuss.image!.withRenderingMode(.alwaysTemplate)
            imgViewIconDiscuss.tintColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
            
            imgViewIconOverview.image = imgViewIconOverview.image!.withRenderingMode(.alwaysTemplate)
            imgViewIconOverview.tintColor = UIColor .lightGray
            
            scrollViewMain.setContentOffset(CGPoint(x: self.view.frame.size.width, y: 0), animated: true)
            btnEditEvent.isHidden = true
        }
    }
    
    @IBAction func ActionImagePreviewDone(_ sender: UIButton)
    {
        viewImagePreview.isHidden = true
    }
    
    @IBAction func ActionSaveImageToPhotoAlbum(_ sender: UIButton)
    {
        UIImageWriteToSavedPhotosAlbum(imgViewPreviewImage.image!, nil, nil, nil)
    }
    
    // ********** UIScrollView Delegate Methdos ********** //
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        if scrollView == scrollViewMain
        {
            if totalUserCount != 1 {
             
                if (scrollView.contentOffset.x == 0)
                {
                    strTopTabSelect = "1"
                    imgViewIconOverview.image = imgViewIconOverview.image!.withRenderingMode(.alwaysTemplate)
                    imgViewIconOverview.tintColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
                    
                    imgViewIconDiscuss.image = imgViewIconDiscuss.image!.withRenderingMode(.alwaysTemplate)
                    imgViewIconDiscuss.tintColor = UIColor .lightGray
                    
                    if dicEventDetailData["EventEditable"] as! String == "2"
                    {
                        btnEditEvent.isHidden = false
                    }
                    else
                    {
                        btnEditEvent.isHidden = true
                    }
                }
                if (scrollView.contentOffset.x == self.view.frame.size.width)
                {
                    strTopTabSelect = "2"
                    imgViewIconDiscuss.image = imgViewIconDiscuss.image!.withRenderingMode(.alwaysTemplate)
                    imgViewIconDiscuss.tintColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
                    
                    imgViewIconOverview.image = imgViewIconOverview.image!.withRenderingMode(.alwaysTemplate)
                    imgViewIconOverview.tintColor = UIColor .lightGray
                    btnEditEvent.isHidden = true
                }
            }
            else
            {
                scrollViewMain.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
            }
        }
    }
    
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
//    {
//        if arrEventImages.count > indexPath.item
//        {
//            viewImagePreview.isHidden = false
//            imgViewPreviewImage.sd_setImage(with: URL(string : arrEventImages[indexPath.item] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
//        }
//        else
//        {
//            let strVideo = arrEventVideos[indexPath.item - arrEventImages.count] as! String
//            let videoURL = URL(string: strVideo)
//            let player = AVPlayer(url: videoURL!)
//            let playerViewController = AVPlayerViewController()
//            playerViewController.player = player
//            self.present(playerViewController, animated: true) {
//                playerViewController.player!.play()
//            }
//        }
//    }
    
    private func thumbnailForVideoAtURL(url: NSURL) -> UIImage? {
        
        let asset = AVAsset(url: url as URL)
        let assetImageGenerator = AVAssetImageGenerator(asset: asset)
        
        var time = asset.duration
        time.value = min(time.value, 2)
        
        do {
            let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
            
        } catch {
            print("error")
            return nil
        }
    }
    
    
    // ********** UITableViewDelegate And Datasource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 4
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if section == 0
        {
            return arrGoingInvite.count
        }
        else if section == 1
        {
            return arrMaybeInvite.count
        }
        else if section == 2
        {
            return arrNoInvite.count
        }
        else
        {
            return arrHaveNotRepliedInvite.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SocialEventDetailInviteCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! SocialEventDetailInviteCell
        
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width / 2
        
        if indexPath.section == 0
        {
            let dicGoing = arrGoingInvite[indexPath.row] as! NSDictionary
            cell.lblInviteName.text = dicGoing["FullName"] as? String
            cell.lblLocation.text = dicGoing["Location"] as? String
            cell.imgViewProPic.sd_setImage(with: URL(string : dicGoing["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        }
        else if indexPath.section == 1
        {
            let dicMaybe = arrMaybeInvite[indexPath.row] as! NSDictionary
            cell.lblInviteName.text = dicMaybe["FullName"] as? String
            cell.lblLocation.text = dicMaybe["Location"] as? String
            cell.imgViewProPic.sd_setImage(with: URL(string : dicMaybe["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        }
        else if indexPath.section == 2
        {
            let dicNo = arrNoInvite[indexPath.row] as! NSDictionary
            cell.lblInviteName.text = dicNo["FullName"] as? String
            cell.lblLocation.text = dicNo["Location"] as? String
            cell.imgViewProPic.sd_setImage(with: URL(string : dicNo["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        }
        else
        {
            let dicHaveNot = arrHaveNotRepliedInvite[indexPath.row] as! NSDictionary
            cell.lblInviteName.text = dicHaveNot["FullName"] as? String
            cell.lblLocation.text = dicHaveNot["Location"] as? String
            cell.imgViewProPic.sd_setImage(with: URL(string : dicHaveNot["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 30
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView : SocialEventDetailHeaderCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! SocialEventDetailHeaderCell
        
        if section == 0
        {
            headerView.lblHeaderName.text = "Going (\(arrGoingInvite.count))"
        }
        else if section == 1
        {
            headerView.lblHeaderName.text = "Maybe (\(arrMaybeInvite.count))"
        }
        else if section == 2
        {
            headerView.lblHeaderName.text = "No (\(arrNoInvite.count))"
        }
        else
        {
            headerView.lblHeaderName.text = "Have not replied (\(arrHaveNotRepliedInvite.count))"
        }
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        let viewFooter = UIView()
        viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
        viewFooter.backgroundColor = UIColor .lightGray
        
        return viewFooter
    }
    
    
    
    // ********** All Data Set Methods ********** //
    func allDataSetOnScreen()
    {
        print(dicEventDetailData)
        
        let inFormatter = DateFormatter()
        inFormatter.dateFormat = "HH:mm:ss"
        let outFormatter = DateFormatter()
        outFormatter.dateFormat = "hh:mma"
        
        let inStartTime = dicEventDetailData["StartTime"] as! String
        let dateTimeStart = inFormatter.date(from: inStartTime)!
        let inEndTime = dicEventDetailData["EndTime"] as! String
        let dateTimeEnd = inFormatter.date(from: inEndTime)!
        
        if dicEventDetailData["AllDay"] as! String == "2"
        {
            lblStartEndTime.text = "Today"
        }
        else
        {
            lblStartEndTime.text = "\(outFormatter.string(from: dateTimeStart)) To \(outFormatter.string(from: dateTimeEnd))"
        }
        
        let inDateFormatter = DateFormatter()
        inDateFormatter.dateFormat = "yyyy-MM-dd"
        let outDateFormatter = DateFormatter()
        outDateFormatter.dateFormat = "MMM dd, yyyy"
        
        let inStartDate = dicEventDetailData["StartDate"] as! String
        let dateDateStart = inDateFormatter.date(from: inStartDate)!
        let inEndDate = dicEventDetailData["EndDate"] as! String
        let dateDateEnd = inDateFormatter.date(from: inEndDate)!
        
        print(dicEventDetailData)
        
        if dicEventDetailData["Repeat"] as! String == "0" {
            
            lblStartEndDate.text = "\(outDateFormatter.string(from: dateDateStart)) To \(outDateFormatter.string(from: dateDateEnd))"
        }
        else
        {
            if strGroupDate == "" {
                
                lblStartEndDate.text = "\(outDateFormatter.string(from: dateDateStart)) To \(outDateFormatter.string(from: dateDateEnd))"
            }
            else {
                
                if dicEventDetailData["StartDate"] as! String == strGroupDate {
                    
                    lblStartEndDate.text = "\(outDateFormatter.string(from: dateDateStart)) To \(outDateFormatter.string(from: dateDateEnd))"
                }
                else
                {
                    print(strGroupDate)
                    
                    let dateDateGroup = inDateFormatter.date(from: strGroupDate)!
                    let components = Calendar.current.dateComponents([.day], from: dateDateStart, to: dateDateEnd)
                    let dateDateNewEnd = NSCalendar.current.date(byAdding: .day, value: components.day!, to: dateDateGroup)!
                    
                    lblStartEndDate.text = "\(outDateFormatter.string(from: dateDateGroup)) To \(outDateFormatter.string(from: dateDateNewEnd))"
                }
            }
            
        }
        
        
        
        lblEventName.text = dicEventDetailData["Title"] as? String
        viewNave.backgroundColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
        lblCalendarName.text = dicEventDetailData["CalendarName"] as? String
        lblEventLocation.text = dicEventDetailData["Location"] as? String
        lblEventNotes.text = dicEventDetailData["Notes"] as? String
        
        let arrReminderList = ["None", "At time of event", "5 minutes before", "10 minutes before", "30 minutes before", "1 hour before", "2 hours before", "1 day before", "2 days before", "1 week before"] as NSArray
        
        if dicEventDetailData["Reminder"] as! String == "0"
        {
            lblEventReminder.text = "None"
        }
        else
        {
            let strReminIndex = dicEventDetailData["Reminder"] as! String
            let indexReminder = Int(strReminIndex)
            let finalIndexReminder = indexReminder! - 1 as Int
            
            lblEventReminder.text = arrReminderList[finalIndexReminder] as? String
        }
        
        let arrRepeat = ["Never", "Every Day", "Every Week", "Every 2 Weeks", "Every Month", "Every Year"] as NSArray
        if dicEventDetailData["Repeat"] as! String == "0" {
            
            lblEventRepeat.text = "Never"
        }
        else
        {
            let strRepeatIndex = dicEventDetailData["Repeat"] as! String
            let indexRepeat = Int(strRepeatIndex)
            let finalIndexRepeat = indexRepeat! - 1 as Int
            
            lblEventRepeat.text = arrRepeat[finalIndexRepeat] as? String
        }
        
        
        
        if dicEventDetailData["EventEditable"] as! String == "2"
        {
            btnEditEvent.isHidden = false
        }
        else
        {
            btnEditEvent.isHidden = true
        }
        
        
        let curDate = Date()
        let inFullEndFormatter = DateFormatter()
        inFullEndFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        let strFullEndDate = "\(dicEventDetailData["EndDate"] as! String) \(dicEventDetailData["EndTime"] as! String)"
        let dateEndFull = inFullEndFormatter.date(from: strFullEndDate)!
        
        if curDate > dateEndFull
        {
            btnYes.isEnabled = false
            btnMaybe.isEnabled = false
            btnNo.isEnabled = false
        }
        else
        {
            btnYes.isEnabled = true
            btnMaybe.isEnabled = true
            btnNo.isEnabled = true
        }
        
        
        
        
        if dicEventDetailData["Attendance"] as! String == "2"
        {
            imgViewYes.image = UIImage(named: "iconCheckBoxBlack")
            imgViewMaybe.image = UIImage(named: "iconCheckBoxBlack")
            imgViewNo.image = UIImage(named: "iconCheckBoxOrange")
        }
        else if dicEventDetailData["Attendance"] as! String == "3"
        {
            imgViewYes.image = UIImage(named: "iconCheckBoxBlack")
            imgViewMaybe.image = UIImage(named: "iconCheckBoxOrange")
            imgViewNo.image = UIImage(named: "iconCheckBoxBlack")
        }
        else if dicEventDetailData["Attendance"] as! String == "4"
        {
            imgViewYes.image = UIImage(named: "iconCheckBoxOrange")
            imgViewMaybe.image = UIImage(named: "iconCheckBoxBlack")
            imgViewNo.image = UIImage(named: "iconCheckBoxBlack")
        }
        else
        {
            imgViewYes.image = UIImage(named: "iconCheckBoxBlack")
            imgViewMaybe.image = UIImage(named: "iconCheckBoxBlack")
            imgViewNo.image = UIImage(named: "iconCheckBoxBlack")
        }
        
        
        viewCalColor.layer.cornerRadius = viewCalColor.frame.size.width/2
        viewCalColor.backgroundColor = postEventColorInTableCell(strColor: dicEventDetailData["CalendarColor"] as! String)
        
        if strTopTabSelect == "1"
        {
            imgViewIconOverview.image = imgViewIconOverview.image!.withRenderingMode(.alwaysTemplate)
            imgViewIconOverview.tintColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
            
            imgViewIconDiscuss.image = imgViewIconDiscuss.image!.withRenderingMode(.alwaysTemplate)
            imgViewIconDiscuss.tintColor = UIColor .lightGray
        }
        else
        {
            imgViewIconDiscuss.image = imgViewIconDiscuss.image!.withRenderingMode(.alwaysTemplate)
            imgViewIconDiscuss.tintColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
            
            imgViewIconOverview.image = imgViewIconOverview.image!.withRenderingMode(.alwaysTemplate)
            imgViewIconOverview.tintColor = UIColor .lightGray
        }
        
        arrEventImages = dicEventDetailData["Images"] as! NSArray
        arrEventVideos = dicEventDetailData["Vidoes"] as! NSArray
        arrGoingInvite = dicEventDetailData["GoingInvitees"] as! NSArray
        arrMaybeInvite = dicEventDetailData["MaybeInvitees"] as! NSArray
        arrNoInvite = dicEventDetailData["NoInvitees"] as! NSArray
        arrHaveNotRepliedInvite = dicEventDetailData["HaveNotRepliedInvitees"] as! NSArray
        
        totalUserCount = 0
        totalUserCount = totalUserCount + arrGoingInvite.count
        totalUserCount = totalUserCount + arrMaybeInvite.count
        totalUserCount = totalUserCount + arrNoInvite.count
        totalUserCount = totalUserCount + arrHaveNotRepliedInvite.count
        
        
        arrMediaTemp = NSMutableArray()
        for i in (0..<arrEventImages.count)
        {
            let strImgURLTemp = arrEventImages[i] as! String
            let dicImageTemp = NSMutableDictionary()
            dicImageTemp.setValue(strImgURLTemp, forKey: "url")
            dicImageTemp.setValue("image", forKey: "Type")
            
            arrMediaTemp.add(dicImageTemp)
        }
        
        for i in (0..<arrEventVideos.count)
        {
            let strVideoURLTemp = arrEventVideos[i] as! String
            let dicVideoTemp = NSMutableDictionary()
            dicVideoTemp.setValue(strVideoURLTemp, forKey: "url")
            dicVideoTemp.setValue("video", forKey: "Type")
            
            arrMediaTemp.add(dicVideoTemp)
        }
        print(arrMediaTemp)
        
        lblMediaCount.isHidden = true
        let mediaCount = arrMediaTemp.count
        if mediaCount == 1
        {
            let dicMediaTemp = arrMediaTemp[0] as! NSDictionary
            if dicMediaTemp["Type"] as! String == "image"
            {
                mediaPlayICon1.isHidden = true
                mediaImg1.sd_setImage(with: URL(string : dicMediaTemp["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            }
            else
            {
                let strVideo = dicMediaTemp["url"] as! String
                let videoURL = NSURL(string: strVideo)
                DispatchQueue.global(qos: .background).async {
                    let image = self.thumbnailForVideoAtURL(url: videoURL!)
                    
                    DispatchQueue.main.async {
                        self.mediaImg1.image = image
                    }
                }
                mediaPlayICon1.isHidden = false
            }
            mediaImg2.isHidden = true
            mediaImg3.isHidden = true
            mediaImg4.isHidden = true
            mediaImg5.isHidden = true
            
            mediaPlayICon2.isHidden = true
            mediaPlayICon3.isHidden = true
            mediaPlayICon4.isHidden = true
            mediaPlayICon5.isHidden = true
            
            lblMediaCount.isHidden = true
        }
        else if mediaCount == 2
        {
            let dicMedia1 = arrMediaTemp[0] as! NSDictionary
            if dicMedia1["Type"] as! String == "image"
            {
                mediaPlayICon2.isHidden = true
                mediaImg2.sd_setImage(with: URL(string : dicMedia1["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            }
            else
            {
                let strVideo = dicMedia1["url"] as! String
                let videoURL = NSURL(string: strVideo)
                DispatchQueue.global(qos: .background).async {
                    let image = self.thumbnailForVideoAtURL(url: videoURL!)
                    
                    DispatchQueue.main.async {
                        self.mediaImg2.image = image
                    }
                }
                mediaPlayICon2.isHidden = false
            }
            
            let dicMedia2 = arrMediaTemp[1] as! NSDictionary
            if dicMedia2["Type"] as! String == "image"
            {
                mediaPlayICon3.isHidden = true
                mediaImg3.sd_setImage(with: URL(string : dicMedia2["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            }
            else
            {
                let strVideo = dicMedia2["url"] as! String
                let videoURL = NSURL(string: strVideo)
                DispatchQueue.global(qos: .background).async {
                    let image = self.thumbnailForVideoAtURL(url: videoURL!)
                    
                    DispatchQueue.main.async {
                        self.mediaImg3.image = image
                    }
                }
                mediaPlayICon3.isHidden = false
            }
            mediaImg1.isHidden = true
            mediaImg4.isHidden = true
            mediaImg5.isHidden = true
            
            mediaPlayICon1.isHidden = true
            mediaPlayICon4.isHidden = true
            mediaPlayICon5.isHidden = true
            
            lblMediaCount.isHidden = true
        }
        else
        {
            if mediaCount != 0
            {
                let dicMedia1 = arrMediaTemp[0] as! NSDictionary
                if dicMedia1["Type"] as! String == "image"
                {
                    mediaPlayICon2.isHidden = true
                    mediaImg2.sd_setImage(with: URL(string : dicMedia1["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                }
                else
                {
                    let strVideo = dicMedia1["url"] as! String
                    let videoURL = NSURL(string: strVideo)
                    DispatchQueue.global(qos: .background).async {
                        let image = self.thumbnailForVideoAtURL(url: videoURL!)
                        
                        DispatchQueue.main.async {
                            self.mediaImg2.image = image
                        }
                    }
                    mediaPlayICon2.isHidden = false
                }
                
                let dicMedia2 = arrMediaTemp[1] as! NSDictionary
                if dicMedia2["Type"] as! String == "image"
                {
                    mediaPlayICon4.isHidden = true
                    mediaImg4.sd_setImage(with: URL(string : dicMedia2["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                }
                else
                {
                    
                    let strVideo = dicMedia2["url"] as! String
                    let videoURL = NSURL(string: strVideo)
                    DispatchQueue.global(qos: .background).async {
                        let image = self.thumbnailForVideoAtURL(url: videoURL!)
                        
                        DispatchQueue.main.async {
                            self.mediaImg4.image = image
                        }
                    }
                    mediaPlayICon4.isHidden = false
                }
                
                let dicMedia3 = arrMediaTemp[2] as! NSDictionary
                if dicMedia3["Type"] as! String == "image"
                {
                    mediaPlayICon5.isHidden = true
                    mediaImg5.sd_setImage(with: URL(string : dicMedia3["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                }
                else
                {
                    let strVideo = dicMedia3["url"] as! String
                    let videoURL = NSURL(string: strVideo)
                    DispatchQueue.global(qos: .background).async {
                        let image = self.thumbnailForVideoAtURL(url: videoURL!)
                        
                        DispatchQueue.main.async {
                            self.mediaImg5.image = image
                        }
                    }
                    mediaPlayICon5.isHidden = false
                }
                mediaImg1.isHidden = true
                mediaImg3.isHidden = true
                
                mediaPlayICon1.isHidden = true
                mediaPlayICon3.isHidden = true
            }
            
            if mediaCount > 3
            {
                lblMediaCount.isHidden = false
                lblMediaCount.text = "+\(mediaCount-3)"
                lblMediaCount.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            }
            
        }
        
        
        
//        if arrEventImages.count > indexPath.item
//        {
//            cellMedia.imgViewPlayIcon.isHidden = true
//            cellMedia.imgView.sd_setImage(with: URL(string : arrEventImages[indexPath.item] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
//        }
//        else
//        {
//            let strVideo = arrEventVideos[indexPath.item - arrEventImages.count] as! String
//            let videoURL = NSURL(string: strVideo)
//            cellMedia.imgViewPlayIcon.isHidden = false
//
//            DispatchQueue.global(qos: .background).async {
//                let image = self.thumbnailForVideoAtURL(url: videoURL!)
//
//                DispatchQueue.main.async {
//                    cellMedia.imgView.image = image
//                }
//            }
//
//        }
        
        
        
        
        
//        if arrEventImages.count == 0 && arrEventVideos.count == 0
//        {
//            viewMediaPlaceholder.isHidden = false
//        }
//        else
//        {
//            viewMediaPlaceholder.isHidden = true
//        }
        
//        collectViewMedia.reloadData()
        tblViewInvite.reloadData()
        
    }
    
    // ********** Gel Event Detail Api Call ********** //
    func yesMaybeNoAPICall(strAction:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
                
                self.eventDetailAPICall()
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as! String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Val_Userid":strUserID, "Val_Action":strAction, "Action":"TakeAction"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.debugDescription)
                        let dicEventResponse = response.result.value as? [String: Any]
                        print(dicEventResponse)
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicEventResponse?["status"] as? String == "success"
                        {
                            self.eventDetailAPICall()
                        }
                        else if dicEventResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    // ********** Gel Event Detail Api Call ********** //
    func eventDetailAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
                
                self.eventDetailAPICall()
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as! String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Val_Userid":strUserID, "Action":"SingleEvent"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.debugDescription)
                        let dicEventResponse = response.result.value as? [String: Any]
                        print(dicEventResponse)
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicEventResponse?["status"] as? String == "success"
                        {
                            let arrEventDetailData = dicEventResponse?["data"] as! NSArray
                            self.dicEventDetailData = arrEventDetailData[0] as! NSDictionary
                            print(self.dicEventDetailData)
                            
                            self.arrMemberList = self.dicEventDetailData["EventMembers"] as! NSArray
                            
                            self.allDataSetOnScreen()
                            
                            self.getDialogs()
                            
                        }
                        else if dicEventResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    func getDialogs() {
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
            
        }, completion: { (response: QBResponse?) -> Void in
            
            guard response != nil && response!.isSuccess else {
                
                return
            }
            
            MBProgressHUD.hide(for: self.view, animated: true)
            
            ServicesManager.instance().chatService.fetchDialog(withID: (self.dialog.id)!) { (dialogFetch) in
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                self.dialog = dialogFetch
            }
            
        })
        
    }
    
    
    
    // ********** All Back View Shadow Method ********* //
    
    func allBackViewShadow()
    {
        viewTabOverDiscuss.layer.shadowColor = UIColor.lightGray.cgColor
        viewTabOverDiscuss.layer.shadowOpacity = 0.4
        viewTabOverDiscuss.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewTabOverDiscuss.layer.shadowRadius = 3
        
        viewCalName.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalName.layer.shadowOpacity = 0.4
        viewCalName.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalName.layer.shadowRadius = 3
        
        viewEventMedia.layer.shadowColor = UIColor.lightGray.cgColor
        viewEventMedia.layer.shadowOpacity = 0.4
        viewEventMedia.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewEventMedia.layer.shadowRadius = 3
        
        viewLocation.layer.shadowColor = UIColor.lightGray.cgColor
        viewLocation.layer.shadowOpacity = 0.4
        viewLocation.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLocation.layer.shadowRadius = 3
        
        tblViewInvite.layer.shadowColor = UIColor.lightGray.cgColor
        tblViewInvite.layer.shadowOpacity = 0.4
        tblViewInvite.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        tblViewInvite.layer.shadowRadius = 3
    }
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    
    // ***************************************************************************************************************** //
    // *********************************************** Chatting Methods ************************************************ //
    // ***************************************************************************************************************** //
    
    func quickbloxCurrentUserAndLoadMessage()
    {
        if let currentUser:QBUUser = ServicesManager.instance().currentUser {
            self.registerCells()
            self.senderID = currentUser.id
            self.senderDisplayName = currentUser.login!
            print(currentUser.id)
            print(currentUser.login)
            
            ServicesManager.instance().chatService.addDelegate(self)
            ServicesManager.instance().chatService.chatAttachmentService.addDelegate(self)
            
            self.heightForSectionHeader = 40.0
            
            self.collectionView?.backgroundColor = UIColor.white
            self.inputToolbar?.contentView?.backgroundColor = UIColor.white
            self.inputToolbar?.contentView?.textView?.placeHolder = "Type a message here"
            
            self.attachmentCellsMap = NSMapTable(keyOptions: NSPointerFunctions.Options.strongMemory, valueOptions: NSPointerFunctions.Options.weakMemory)
            
            // Retrieving messages
            if (self.storedMessages()?.count ?? 0 > 0 && self.chatDataSource.messagesCount() == 0) {
                
                self.chatDataSource.add(self.storedMessages()!)
            }
            
            self.loadMessages()
            
            self.enableTextCheckingTypes = NSTextCheckingAllTypes
        }
    }
    
    func registerCells()
    {
        //Register header view
        let headerNib:UINib = QMHeaderCollectionReusableView.nib()
        let headerView:String = QMHeaderCollectionReusableView.cellReuseIdentifier()
        self.collectionView.register(headerNib, forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: headerView)
        
        // Register contact request cell
        QMChatContactRequestCell.registerForReuse(inView: self.collectionView)
        
        // Register Notification cell
        QMChatNotificationCell.registerForReuse(inView: self.collectionView)
        
        // Register outgoing cell
        QMChatOutgoingCell.registerForReuse(inView: self.collectionView)
        // Register incoming cell
        QMChatIncomingCell.registerForReuse(inView: self.collectionView)
        
        // Register attachment incoming cell
        QMChatAttachmentIncomingCell.registerForReuse(inView: self.collectionView)
        // Register attachment outgoing cell
        QMChatAttachmentOutgoingCell.registerForReuse(inView: self.collectionView)
        
        // Register location outgoing cell
        QMChatLocationOutgoingCell.registerForReuse(inView: self.collectionView)
        // Register location incoming cell
        QMChatLocationIncomingCell.registerForReuse(inView: self.collectionView)
        
        // Register video attachment outgoing cell
        QMVideoOutgoingCell.registerForReuse(inView: self.collectionView)
        // Register video attachment incoming cell
        QMVideoIncomingCell.registerForReuse(inView: self.collectionView)
        
        // Register audio attachment outgoing cell
        QMAudioOutgoingCell.registerForReuse(inView: self.collectionView)
        // Register audio attachment incoming cell
        QMAudioIncomingCell.registerForReuse(inView: self.collectionView)
        
        // Register image attachment outgoing cell
        QMImageOutgoingCell.registerForReuse(inView: self.collectionView)
        // Register image attachment incoming cell
        QMImageIncomingCell.registerForReuse(inView: self.collectionView)
        
        // Register link preview incoming cell
        QMChatIncomingLinkPreviewCell.registerForReuse(inView: self.collectionView)
        // Register link preview outgoing cell
        QMChatOutgoingLinkPreviewCell.registerForReuse(inView: self.collectionView)
    }
    
    func storedMessages() -> [QBChatMessage]?
    {
//        if !ServicesManager.instance().isProcessingLogOut! {
            return ServicesManager.instance().chatService.messagesMemoryStorage.messages(withDialogID: self.dialog.id!)
//        }
    }
    
    func loadMessages() {
        // Retrieving messages for chat dialog ID.
        guard let currentDialogID = self.dialog.id else {
            print ("Current chat dialog is nil")
            return
        }
        
        ServicesManager.instance().chatService.messages(withChatDialogID: currentDialogID, completion: {
            [weak self] (response, messages) -> Void in
            
            print(messages)
            print(response)
            
            guard let strongSelf = self else { return }
            
            guard response.error == nil else {
//                SVProgressHUD.showError(withStatus: response.error?.error?.localizedDescription)
                return
            }
            
            if messages?.count ?? 0 > 0 {
                strongSelf.chatDataSource.add(messages)
            }
//            SVProgressHUD.dismiss()
        })
    }
    
    func sendReadStatusForMessage(message: QBChatMessage) {
        
        guard QBSession.current.currentUser != nil else {
            return
        }
        guard message.senderID != QBSession.current.currentUser?.id else {
            return
        }
        
        if self.messageShouldBeRead(message: message) {
            ServicesManager.instance().chatService.read(message, completion: { (error) -> Void in
                
                guard error == nil else {
                    print("Problems while marking message as read! Error: %@", error!)
                    return
                }
                
                if UIApplication.shared.applicationIconBadgeNumber > 0 {
                    let badgeNumber = UIApplication.shared.applicationIconBadgeNumber
                    UIApplication.shared.applicationIconBadgeNumber = badgeNumber - 1
                }
            })
        }
    }
    
    func messageShouldBeRead(message: QBChatMessage) -> Bool {
        
        let currentUserID = NSNumber(value: QBSession.current.currentUser!.id as UInt)
        
        return !message.isDateDividerMessage && message.senderID != self.senderID && !(message.readIDs?.contains(currentUserID))!
    }
    
    func readMessages(messages: [QBChatMessage]) {
        
        if QBChat.instance.isConnected {
            
            ServicesManager.instance().chatService.read(messages, forDialogID: self.dialog.id!, completion: nil)
        }
        else {
            
            self.unreadMessages = messages
        }
        
        var messageIDs = [String]()
        
        for message in messages {
            messageIDs.append(message.id!)
        }
    }
    
    func statusStringFromMessage(message: QBChatMessage) -> String {
        
        var statusString = ""
        
        let currentUserID = NSNumber(value:self.senderID)
        
        var readLogins: [String] = []
        
        if message.readIDs != nil {
            
            let messageReadIDs = message.readIDs!.filter { (element) -> Bool in
                
                return !element.isEqual(to: currentUserID)
            }
            
            if !messageReadIDs.isEmpty {
                for readID in messageReadIDs {
                    let user = ServicesManager.instance().usersService.usersMemoryStorage.user(withID: UInt(truncating: readID))
                    
                    guard let unwrappedUser = user else {
                        let unknownUserLogin = "@\(readID)"
                        readLogins.append(unknownUserLogin)
                        
                        continue
                    }
                    
                    readLogins.append(unwrappedUser.login!)
                }
                
//                statusString += message.isMediaMessage() ? " SEEN_STATUS" : " READ_STATUS"
//                statusString += ": " + readLogins.joined(separator: ", ")
                
                statusString += message.isMediaMessage() ? " Seen" : " Read"
            }
        }
        
        if message.deliveredIDs != nil {
            var deliveredLogins: [String] = []
            
            let messageDeliveredIDs = message.deliveredIDs!.filter { (element) -> Bool in
                return !element.isEqual(to: currentUserID)
            }
            
            if !messageDeliveredIDs.isEmpty {
                for deliveredID in messageDeliveredIDs {
                    let user = ServicesManager.instance().usersService.usersMemoryStorage.user(withID: UInt(truncating: deliveredID))
                    
                    guard let unwrappedUser = user else {
                        let unknownUserLogin = "@\(deliveredID)"
                        deliveredLogins.append(unknownUserLogin)
                        
                        continue
                    }
                    
                    if readLogins.contains(unwrappedUser.login!) {
                        continue
                    }
                    
                    deliveredLogins.append(unwrappedUser.login!)
                    
                }
                
                if readLogins.count > 0 && deliveredLogins.count > 0 {
                    statusString += "\n"
                }
                
                if deliveredLogins.count > 0 {
//                    statusString += " DELIVERED_STATUS" + ": " + deliveredLogins.joined(separator: ", ")
                    statusString += "Delivered"
                }
            }
        }
        
        if statusString.isEmpty {
            
            let messageStatus: QMMessageStatus = self.queueManager().status(for: message)
            
            switch messageStatus {
            case .sent:
//                statusString = " SENT_STATUS"
                statusString = "Sent"
            case .sending:
//                statusString = " SENDING_STATUS"
                statusString = "Sending"
            case .notSent:
//                statusString = " NOT_SENT_STATUS"
                statusString = "Not Sent"
            }
            
        }
        
        return statusString
    }
    
    
    // MARK: Override
    
    func viewClass(forItem item: QBChatMessage) -> AnyClass? {
        // TODO: check and add QMMessageType.AcceptContactRequest, QMMessageType.RejectContactRequest, QMMessageType.ContactRequest
        
        if item.isNotificationMessage() || item.isDateDividerMessage {
            return QMChatNotificationCell.self
        }
        
        if (item.senderID != self.senderID) {
            
            if (item.isMediaMessage() && item.attachmentStatus != QMMessageAttachmentStatus.error) {
                
                return QMChatAttachmentIncomingCell.self
                
            }
            else {
                
                return QMChatIncomingCell.self
            }
            
        }
        else {
            
            if (item.isMediaMessage() && item.attachmentStatus != QMMessageAttachmentStatus.error) {
                
                return QMChatAttachmentOutgoingCell.self
                
            }
            else {
                
                return QMChatOutgoingCell.self
            }
        }
    }
    
    // MARK: Strings builder
    
    func attributedString(forItem messageItem: QBChatMessage!) -> NSAttributedString? {
        
        guard messageItem.text != nil else {
            return nil
        }
        
        var textColor = messageItem.senderID == self.senderID ? UIColor.white : UIColor.black
        if messageItem.isNotificationMessage() || messageItem.isDateDividerMessage {
            textColor = UIColor.black
        }
        
        var attributes = Dictionary<NSAttributedStringKey, AnyObject>()
        attributes[NSAttributedStringKey.foregroundColor] = textColor
        attributes[NSAttributedStringKey.font] = UIFont(name: "Helvetica", size: 17)
        
        let attributedString = NSAttributedString(string: messageItem.text!, attributes: attributes)
        
        return attributedString
    }
    
    func topLabelAttributedString(forItem messageItem: QBChatMessage!) -> NSAttributedString? {
        
        guard messageItem.senderID != self.senderID else {
            return nil
        }
        
        guard self.dialog.type != QBChatDialogType.private else {
            return nil
        }
        
        let paragrpahStyle: NSMutableParagraphStyle = NSMutableParagraphStyle()
        paragrpahStyle.lineBreakMode = NSLineBreakMode.byTruncatingTail
        var attributes = Dictionary<NSAttributedStringKey, AnyObject>()
        attributes[NSAttributedStringKey.foregroundColor] = UIColor(red: 11.0/255.0, green: 96.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        attributes[NSAttributedStringKey.font] = UIFont(name: "Helvetica", size: 17)
        attributes[NSAttributedStringKey.paragraphStyle] = paragrpahStyle
        
        
        
        print(arrMemberList)
        
        var topLabelAttributedString : NSAttributedString?
        if let topLabelText = ServicesManager.instance().usersService.usersMemoryStorage.user(withID: messageItem.senderID)?.fullName {
            topLabelAttributedString = NSAttributedString(string: topLabelText, attributes: attributes)
        } else { // no user in memory storage
            
            for i in (0..<arrMemberList.count)
            {
                let dicMemberData = arrMemberList[i] as! NSDictionary
                let strUserQBID = dicMemberData["UserJID"] as! String
                
                if "\(messageItem.senderID)" == strUserQBID
                {
                    topLabelAttributedString = NSAttributedString(string: "\(dicMemberData["FullName"] as! String)", attributes: attributes)
                }
                
            }
            
            
//            topLabelAttributedString = NSAttributedString(string: "@\(messageItem.senderID)", attributes: attributes)
        }
        
        return topLabelAttributedString
    }
    
    func bottomLabelAttributedString(forItem messageItem: QBChatMessage!) -> NSAttributedString! {
        
        let textColor = messageItem.senderID == self.senderID ? UIColor.white : UIColor.black
        
        let paragrpahStyle: NSMutableParagraphStyle = NSMutableParagraphStyle()
        paragrpahStyle.lineBreakMode = NSLineBreakMode.byWordWrapping
        
        var attributes = Dictionary<NSAttributedStringKey, AnyObject>()
        attributes[NSAttributedStringKey.foregroundColor] = textColor
        attributes[NSAttributedStringKey.font] = UIFont(name: "Helvetica", size: 13)
        attributes[NSAttributedStringKey.paragraphStyle] = paragrpahStyle
        
        var text = messageItem.dateSent != nil ? messageTimeDateFormatter.string(from: messageItem.dateSent!) : ""
        
        if messageItem.senderID == self.senderID {
            text = text + "\n" + self.statusStringFromMessage(message: messageItem)
        }
        
        let bottomLabelAttributedString = NSAttributedString(string: text, attributes: attributes)
        
        return bottomLabelAttributedString
    }
    
    
    // MARK: QMChatCellDelegate
    
    /**
     Removes size from cache for item to allow cell expand and show read/delivered IDS or unexpand cell
     */
    func chatCellDidTapContainer(_ cell: QMChatCell!) {
        let indexPath = self.collectionView?.indexPath(for: cell)

        guard let currentMessage = self.chatDataSource.message(for: indexPath) else {
            return
        }

        let messageStatus: QMMessageStatus = self.queueManager().status(for: currentMessage)

        if messageStatus == .notSent {
            self.handleNotSentMessage(currentMessage, forCell:cell)
            return
        }

        if self.detailedCells.contains(currentMessage.id!) {
            self.detailedCells.remove(currentMessage.id!)
        } else {
            self.detailedCells.insert(currentMessage.id!)
        }

        self.collectionView?.collectionViewLayout.removeSizeFromCache(forItemID: currentMessage.id)
        self.collectionView?.performBatchUpdates(nil, completion: nil)
        
    }
    
    func chatCell(_ cell: QMChatCell!, didTapAtPosition position: CGPoint) {}
    
    func chatCell(_ cell: QMChatCell!, didPerformAction action: Selector!, withSender sender: Any!) {}
    
    func chatCell(_ cell: QMChatCell!, didTapOn result: NSTextCheckingResult) {

        switch result.resultType {

        case NSTextCheckingResult.CheckingType.link:

            let strUrl : String = (result.url?.absoluteString)!

            let hasPrefix = strUrl.lowercased().hasPrefix("https://") || strUrl.lowercased().hasPrefix("http://")

            if #available(iOS 9.0, *) {
                if hasPrefix {

//                    let controller = SFSafariViewController(url: URL(string: strUrl)!)
//                    self.present(controller, animated: true, completion: nil)

                    break
                }

            }
            // Fallback on earlier versions

            if UIApplication.shared.canOpenURL(URL(string: strUrl)!) {

                UIApplication.shared.openURL(URL(string: strUrl)!)
            }

            break

        case NSTextCheckingResult.CheckingType.phoneNumber:

//            if !self.canMakeACall() {
//
//                SVProgressHUD.showInfo(withStatus: "Your Device can't make a phone call", maskType: .none)
//                break
//            }

            let urlString = String(format: "tel:%@",result.phoneNumber!)
            let url = URL(string: urlString)

            self.view.endEditing(true)

            let alertController = UIAlertController(title: "", message: result.phoneNumber, preferredStyle: .alert)

            let cancelAction = UIAlertAction(title: " CANCEL", style: .cancel) { (action) in

            }

            alertController.addAction(cancelAction)

            let openAction = UIAlertAction(title: " CALL", style: .destructive) { (action) in
                UIApplication.shared.openURL(url!)
            }
            alertController.addAction(openAction)

            self.present(alertController, animated: true) {
            }

            break

        default:
            break
        }
    }
    
    func chatCellDidTapAvatar(_ cell: QMChatCell!) {
    }
    
    // MARK: QMDeferredQueueManager
    
    func deferredQueueManager(_ queueManager: QMDeferredQueueManager, didAddMessageLocally addedMessage: QBChatMessage) {
        
        if addedMessage.dialogID == self.dialog.id {
            self.chatDataSource.add(addedMessage)
        }
    }
    
    func deferredQueueManager(_ queueManager: QMDeferredQueueManager, didUpdateMessageLocally addedMessage: QBChatMessage) {
        
        if addedMessage.dialogID == self.dialog.id {
            self.chatDataSource.update(addedMessage)
        }
    }
    
    
    // MARK: QMChatServiceDelegate
    
    func chatService(_ chatService: QMChatService, didLoadMessagesFromCache messages: [QBChatMessage], forDialogID dialogID: String) {
        
        if self.dialog.id == dialogID {
            
            self.chatDataSource.add(messages)
        }
    }
    
    func chatService(_ chatService: QMChatService, didAddMessageToMemoryStorage message: QBChatMessage, forDialogID dialogID: String) {
        
        if self.dialog.id == dialogID {
            // Insert message received from XMPP or self sent
            if self.chatDataSource.messageExists(message) {
                
                self.chatDataSource.update(message)
            }
            else {
                
                self.chatDataSource.add(message)
            }
        }
    }
    
    func chatService(_ chatService: QMChatService, didUpdateChatDialogInMemoryStorage chatDialog: QBChatDialog) {
        
        if self.dialog.type != QBChatDialogType.private && self.dialog.id == chatDialog.id {
            self.dialog = chatDialog
            self.title = self.dialog.name
        }
    }
    
    func chatService(_ chatService: QMChatService, didUpdate message: QBChatMessage, forDialogID dialogID: String) {
        
        if self.dialog.id == dialogID {
            self.chatDataSource.update(message)
        }
    }
    
    func chatService(_ chatService: QMChatService, didUpdate messages: [QBChatMessage], forDialogID dialogID: String) {
        
        if self.dialog.id == dialogID {
            self.chatDataSource.update(messages)
        }
    }
    
    // MARK: QMChatAttachmentServiceDelegate
    
    func chatAttachmentService(_ chatAttachmentService: QMChatAttachmentService, didChange status: QMMessageAttachmentStatus, for message: QBChatMessage) {
        
        if status != QMMessageAttachmentStatus.notLoaded {
            
            if message.dialogID == self.dialog.id {
                self.chatDataSource.update(message)
            }
        }
    }
    
    func chatAttachmentService(_ chatAttachmentService: QMChatAttachmentService, didChangeLoadingProgress progress: CGFloat, for attachment: QBChatAttachment) {
        
        if let attachmentCell = self.attachmentCellsMap.object(forKey: attachment.id! as AnyObject?) {
            attachmentCell.updateLoadingProgress(progress)
        }
    }
    
    func chatAttachmentService(_ chatAttachmentService: QMChatAttachmentService, didChangeUploadingProgress progress: CGFloat, for message: QBChatMessage) {
        
        guard message.dialogID == self.dialog.id else {
            return
        }
        var cell = self.attachmentCellsMap.object(forKey: message.id as AnyObject?)
        
        if cell == nil && progress < 1.0 {
            
            if let indexPath = self.chatDataSource.indexPath(for: message) {
                cell = self.collectionView?.cellForItem(at: indexPath) as? QMChatAttachmentCell
                self.attachmentCellsMap.setObject(cell, forKey: message.id as AnyObject?)
            }
        }
        
        cell?.updateLoadingProgress(progress)
    }
    
    // MARK : QMChatConnectionDelegate
    
    func refreshAndReadMessages() {
        
//        SVProgressHUD.show(withStatus: " LOADING_MESSAGES", maskType: SVProgressHUDMaskType.clear)
        self.loadMessages()
        
        if let messagesToRead = self.unreadMessages {
            self.readMessages(messages: messagesToRead)
        }
        
        self.unreadMessages = nil
    }
    
    func chatServiceChatDidConnect(_ chatService: QMChatService) {
        
        self.refreshAndReadMessages()
    }
    
    func chatServiceChatDidReconnect(_ chatService: QMChatService) {
        
        self.refreshAndReadMessages()
    }
    
    func handleNotSentMessage(_ message: QBChatMessage, forCell cell: QMChatCell!) {
        
        let alertController = UIAlertController(title: "", message: "MESSAGE FAILED TO SEND", preferredStyle:.actionSheet)
        
        let resend = UIAlertAction(title: "TRY AGAIN MESSAGE", style: .default) { (action) in
            self.queueManager().perfromDefferedAction(for: message, withCompletion: nil)
        }
        alertController.addAction(resend)
        
        let delete = UIAlertAction(title: "DELETE MESSAGE", style: .destructive) { (action) in
            self.queueManager().remove(message)
            self.chatDataSource.delete(message)
        }
        alertController.addAction(delete)
        
        let cancelAction = UIAlertAction(title: "CANCEL", style: .cancel) { (action) in
            
        }
        
        alertController.addAction(cancelAction)
        
        if alertController.popoverPresentationController != nil {
            self.view.endEditing(true)
            alertController.popoverPresentationController!.sourceView = cell.containerView
            alertController.popoverPresentationController!.sourceRect = cell.containerView.bounds
        }
        
        self.present(alertController, animated: true) {
        }
    }
    
    
    
    
    
    
    func placeHolderTextView(_ textView: QMPlaceHolderTextView, shouldPasteWithSender sender: Any) -> Bool {
        
        if UIPasteboard.general.image != nil {
            
            let textAttachment = NSTextAttachment()
            textAttachment.image = UIPasteboard.general.image!
            textAttachment.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
            
            let attrStringWithImage = NSAttributedString.init(attachment: textAttachment)
            self.inputToolbar.contentView.textView.attributedText = attrStringWithImage
            self.textViewDidChange(self.inputToolbar.contentView.textView)
            
            return false
        }
        
        return true
    }
    
    // MARK: UITextViewDelegate
    
    func textViewDidChange(_ textView: UITextView) {
        if (textView != self.inputToolbar.contentView.textView) {
            return;
        }
        
        self.inputToolbar.toggleSendButtonEnabled()
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        // Prevent crashing undo bug
        let currentCharacterCount = textView.text?.length ?? 0
        
        if (range.length + range.location > currentCharacterCount) {
            return false
        }
        
        if !QBChat.instance.isConnected { return true }
        
        if let timer = self.typingTimer {
            timer.invalidate()
            self.typingTimer = nil
            
        } else {
            
//            self.sendBeginTyping()
        }
        
        self.typingTimer = Timer.scheduledTimer(timeInterval: 4.0, target: self, selector: #selector(SocialChatVC.fireSendStopTypingIfNecessary), userInfo: nil, repeats: false)
        
        if maxCharactersNumber > 0 {
            
            if currentCharacterCount >= maxCharactersNumber && text.length > 0 {
                
                self.showCharactersNumberError()
                return false
            }
            
            let newLength = currentCharacterCount + text.length - range.length
            
            if  newLength <= maxCharactersNumber || text.length == 0 {
                return true
            }
            
            let oldString = textView.text ?? ""
            
            let numberOfSymbolsToCut = maxCharactersNumber - oldString.length
            
            var stringRange = NSMakeRange(0, min(text.length, numberOfSymbolsToCut))
            
            
            // adjust the range to include dependent chars
            stringRange = (text as NSString).rangeOfComposedCharacterSequences(for: stringRange)
            
            // Now you can create the short string
            let shortString = (text as NSString).substring(with: stringRange)
            
            let newText = NSMutableString()
            newText.append(oldString)
            newText.insert(shortString, at: range.location)
            textView.text = newText as String
            
            self.showCharactersNumberError()
            
            self.textViewDidChange(textView)
            
            return false
        }
        
        return true
    }
    
    func showCharactersNumberError()
    {
        let title  = " ERROR";
        let subtitle = String(format: "The character limit is %lu.", maxCharactersNumber)
//        print(title + subtitle)
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        
//        super.textViewDidEndEditing(textView)
        
        self.fireSendStopTypingIfNecessary()
    }
    
    @objc func fireSendStopTypingIfNecessary() -> Void {
        
        if let timer = self.typingTimer {
            
            timer.invalidate()
        }
        
        self.typingTimer = nil
//        self.sendStopTyping()
    }
    
    func messagesInputToolbar(_ toolbar: QMInputToolbar!, didPressRightBarButton sender: UIButton!)
    {
        if (toolbar.sendButtonOnRight) {
            
//            [self didPressSendButton:sender];
            self.didPressSendButton(button: sender)
        }
        else {
            
//            [self didPressAccessoryButton:sender];
        }
    }
    
    func messagesInputToolbar(_ toolbar: QMInputToolbar!, didPressLeftBarButton sender: UIButton!)
    {
        
    }
    
    func sendButtonItem() -> UIButton
    {
        let sendTitle = "Send"
        
        let sendButton = UIButton.init(frame: CGRect.zero)
        sendButton.setTitle(sendTitle, for: .normal)
        sendButton.setTitleColor(UIColor.blue, for: .normal)
        sendButton.setTitleColor(UIColor.blue.darkeningColor(withValue: 0.1), for: .highlighted)
        sendButton.setTitleColor(UIColor.lightGray, for: .disabled)
        
        sendButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 17.0)
        sendButton.titleLabel?.adjustsFontSizeToFitWidth = true
        sendButton.titleLabel?.minimumScaleFactor = 0.85
        sendButton.contentMode = UIViewContentMode.center
        sendButton.backgroundColor = UIColor .clear
        sendButton.tintColor = UIColor .blue
        
        let maxHeight:CGFloat = 32.0
        let sendTitleRect: CGRect = sendTitle.boundingRect(with: CGSize(width: 1000, height: maxHeight), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [NSAttributedStringKey.font: sendButton.titleLabel?.font ?? ""], context: nil)
        sendButton.frame = CGRect(x: 0.0, y: 0.0, width: sendTitleRect.integral.width, height: maxHeight)
        
        
        return sendButton
    }
    
    func didPressSendButton(button:UIButton)
    {
        self.didPressSend(button: button, withMessageText: self.currentlyComposedMessageText(), senderID: self.senderID, senderDisplayName: self.senderDisplayName, date: Date())
    }
    
    func didPressSend(button:UIButton, withMessageText text:String!, senderID:UInt, senderDisplayName:String!, date:Date!)
    {
        if !self.queueManager().shouldSendMessagesInDialog(withID: self.dialog.id!)
        {
            return
        }
        self.fireSendStopTypingIfNecessary()
        
        let message = QBChatMessage()
        message.text = text
        message.senderID = self.senderID
        message.deliveredIDs = [(NSNumber(value: self.senderID))]
        message.readIDs = [(NSNumber(value: self.senderID))]
        message.markable = true
        message.dateSent = date
        
        self.sendMessage(message: message)
    }
    
    func currentlyComposedMessageText() -> String
    {
        //  auto-accept any auto-correct siggestions
        self.inputToolbar.contentView.textView.inputDelegate?.selectionWillChange(self.inputToolbar.contentView.textView)
        self.inputToolbar.contentView.textView.inputDelegate?.selectionDidChange(self.inputToolbar.contentView.textView)
        
        return self.inputToolbar.contentView.textView.text.trimingWhitespace()
    }
    
    func queueManager() -> QMDeferredQueueManager
    {
        return ServicesManager.instance().chatService.deferredQueueManager
    }
    
    func sendMessage(message: QBChatMessage) {
        
        self.inputToolbar.contentView.textView.resignFirstResponder()
        
        let notifMessage:String = "\(dicEventDetailData["Title"] as! String): \(message.text!)"
        let payload = NSMutableDictionary()
        let aps = NSMutableDictionary()
        aps.setObject("default", forKey: QBMPushMessageSoundKey as NSCopying)
        aps.setObject(notifMessage, forKey: QBMPushMessageAlertKey as NSCopying)
        aps.setObject("chat", forKey: "type" as NSCopying)
        aps.setObject("\(self.dialog.id!)", forKey: "dialogID" as NSCopying)
        aps.setObject(strEventID, forKey: "eventID" as NSCopying)
        payload.setObject(aps, forKey: QBMPushMessageApsKey as NSCopying)
        print(payload)
        
        
        let pushMessage = QBMPushMessage.init()
        pushMessage.payloadDict = NSMutableDictionary(dictionary: payload)
        
        print(self.dialog.userID)
        print(self.dialog.recipientID)
        print(ServicesManager.instance().currentUser.id)
        
        let opponentCount:Int = (self.dialog.occupantIDs?.count)!
        var recipientID = String()
        
        for i in (0..<opponentCount) {
            
            if ServicesManager.instance().currentUser.id != UInt(truncating: self.dialog.occupantIDs![i])
            {
                print(self.dialog.occupantIDs![i])
                recipientID = "\(self.dialog.occupantIDs![i]),"
            }
        }
        
        recipientID.remove(at: recipientID.index(before: recipientID.endIndex))
        print(recipientID)
        
//        QBRequest.sendPush(pushMessage, toUsers: recipientID, successBlock: { (response, event) in
//
//            print(response)
//
//            self.finishSendingMessage(animated: true)
//
//        }) { (error) in
//            print(error)
//        }
        
        let msg = "\(dicEventDetailData["Title"] as! String): \(message.text!)"
        let event = QBMEvent()
        event.notificationType = QBMNotificationType.push
        event.usersIDs = String(self.dialog.recipientID)
        event.type = QBMEventType.oneShot
        event.pushType = QBMPushType.undefined
        
        let dicPush = ["alert":msg, "message":msg,"ios_badge":"1", "ios_sound":"default", "type":"chat", "dialogID":"\(self.dialog.id!)", "eventID":strEventID]
        
        let sendData: Data? = try? JSONSerialization.data(withJSONObject: dicPush, options: [])
        let jsonString = String(data: sendData!, encoding: .utf8)
        
        event.message = jsonString
        print(event)
        
        
        // Sending message.
        ServicesManager.instance().chatService.send(message, toDialogID: self.dialog.id!, saveToHistory: true, saveToStorage: true) { (error) ->
            Void in
            
            if error != nil {
                
                print(error)
            }
            else {
                
                QBRequest.createEvent(event, successBlock: { (response, events) in
                    
                    print(response)
                    
                }) { (response) in
                    
                    print(response.error?.description)
                    
                }
            }
        }
        
        self.finishSendingMessage(animated: true)
    }
    
    func finishSendingMessage(animated:Bool)
    {
        let textView:QMPlaceHolderTextView = self.inputToolbar.contentView.textView
        textView.setDefaultSettings()
        
        textView.text = nil
        textView.attributedText = nil
        textView.undoManager?.removeAllActions()
        
        self.inputToolbar.toggleSendButtonEnabled()
        NotificationCenter.default.post(name: NSNotification.Name.UITextViewTextDidChange, object: textView)
        
        self.scrollToBottom(animated: true)
    }
    
    func scrollToBottom(animated:Bool)
    {
        if self.collectionView.numberOfItems(inSection: 0) > 0
        {
            let contentOffset = self.collectionView.contentOffset

            if contentOffset.y > 0
            {
                self.collectionView.setContentOffset(contentOffset, animated: true)
            }
        }
    }
    
    func change(_ dataSource: QMChatDataSource!, withMessages messages: [Any]!, update updateType: QMDataSourceActionType) 
    {
        if messages.count == 0 {
            return
        }
        
        let batchUpdatesBlock:() -> () = {() -> Void in
            let indexPaths = self.chatDataSource.performChanges(withMessages: messages, update: updateType)
            if self.collectionView.dataSource == nil {
                return
            }
            
            switch updateType {
            case QMDataSourceActionType.add:
                self.collectionView.insertItems(at: indexPaths as? [IndexPath] ?? [IndexPath]())
            case QMDataSourceActionType.update:
                self.collectionView.reloadItems(at: indexPaths as? [IndexPath] ?? [IndexPath]())
            case QMDataSourceActionType.remove:
                self.collectionView.deleteItems(at: indexPaths as? [IndexPath] ?? [IndexPath]())
            }
        }
        
        self.collectionView.performBatchUpdates(batchUpdatesBlock, completion: nil)
    }
    
    func chatDataSource(_ chatDataSource: QMChatDataSource!, willBeChangedWithMessageIDs messagesIDs: [Any]!) {
        
        for messageID in messagesIDs
        {
            self.collectionView.collectionViewLayout.removeSizeFromCache(forItemID: messageID as! String)
        }
    }
    
    
//    - (CGSize)collectionView:(QMChatCollectionView *)collectionView
//    layout:(QMChatCollectionViewFlowLayout *)collectionViewLayout
//    sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
//
//    return [collectionViewLayout sizeForItemAtIndexPath:indexPath];
//    }
    
    
    // MARK: Collection view data source
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.chatDataSource.messagesCount()
    }
    
//    private func collectionView(_ collectionView: QMChatCollectionView, layout collectionViewLayout: QMChatCollectionViewFlowLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        return collectionViewLayout.sizeForItem(at: indexPath)
//    }
    
    func collectionView(_ collectionView:QMChatCollectionView, itemIdAt indexPath:IndexPath) -> String {

        let message:QBChatMessage = self.chatDataSource.message(for: indexPath)

        return message.id!
    }
    

    
    
    





    func collectionView(_ collectionView: QMChatCollectionView!, dynamicSizeAt indexPath: IndexPath!, maxWidth: CGFloat) -> CGSize {
        
        var size = CGSize.zero
        
        guard let message = self.chatDataSource.message(for: indexPath) else {
            return size
        }
        
        let messageCellClass: AnyClass! = self.viewClass(forItem: message)
        
        
        if messageCellClass === QMChatAttachmentIncomingCell.self {
            
            size = CGSize(width: min(200, maxWidth), height: 200)
        }
        else if messageCellClass === QMChatAttachmentOutgoingCell.self {
            
            let attributedString = self.bottomLabelAttributedString(forItem: message)
            
            let bottomLabelSize = TTTAttributedLabel.sizeThatFitsAttributedString(attributedString, withConstraints: CGSize(width: min(200, maxWidth), height: CGFloat.greatestFiniteMagnitude), limitedToNumberOfLines: 0)
            size = CGSize(width: min(200, maxWidth), height: 200 + ceil(bottomLabelSize.height))
        }
        else if messageCellClass === QMChatNotificationCell.self {
            
            let attributedString = self.attributedString(forItem: message)
            size = TTTAttributedLabel.sizeThatFitsAttributedString(attributedString, withConstraints: CGSize(width: maxWidth, height: CGFloat.greatestFiniteMagnitude), limitedToNumberOfLines: 0)
        }
        else {

            let attributedString = self.attributedString(forItem: message)

            size = TTTAttributedLabel.sizeThatFitsAttributedString(attributedString, withConstraints: CGSize(width: maxWidth, height: CGFloat.greatestFiniteMagnitude), limitedToNumberOfLines: 0)
        }

        return size
    }
    
    func collectionView(_ collectionView: QMChatCollectionView!, minWidthAt indexPath: IndexPath!) -> CGFloat {

        var size = CGSize.zero

        guard let item = self.chatDataSource.message(for: indexPath) else {
            return 0
        }

        if self.detailedCells.contains(item.id!) {

            let str = self.bottomLabelAttributedString(forItem: item)
            let frameWidth = collectionView.frame.width
            let maxHeight = CGFloat.greatestFiniteMagnitude

            size = TTTAttributedLabel.sizeThatFitsAttributedString(str, withConstraints: CGSize(width:frameWidth - 40.0, height: maxHeight), limitedToNumberOfLines:0)
        }
        
        if self.dialog.type != QBChatDialogType.private {

            let topLabelSize = TTTAttributedLabel.sizeThatFitsAttributedString(self.topLabelAttributedString(forItem: item), withConstraints: CGSize(width: collectionView.frame.width - 40.0, height: CGFloat.greatestFiniteMagnitude), limitedToNumberOfLines:0)

            if topLabelSize.width > size.width {
                size = topLabelSize
            }
        }

        return size.width
    }
    
    //    func collectionView(_ collectionView:QMChatCollectionView, layoutModelAt indexPath:IndexPath) -> QMChatCellLayoutModel {
    //
//            let item:QBChatMessage = self.chatDataSource.message(for: indexPath)
//            let clas = self.viewClass(forItem: item)
    //
    //        return (clas?.layoutModel())!
    //    }
    
    func collectionView(_ collectionView: QMChatCollectionView!, layoutModelAt indexPath: IndexPath!) -> QMChatCellLayoutModel {
        
//        var layoutModel: QMChatCellLayoutModel = self.collectionView(collectionView, layoutModelAt: indexPath)
        
        let itemMessage:QBChatMessage = self.chatDataSource.message(for: indexPath)
        let clas = self.viewClass(forItem: itemMessage)
        
        var layoutModel = clas?.layoutModel() as! QMChatCellLayoutModel
        
        layoutModel.avatarSize = CGSize(width: 0, height: 0)
        layoutModel.topLabelHeight = 0.0
        layoutModel.spaceBetweenTextViewAndBottomLabel = 5
        layoutModel.maxWidthMarginSpace = 20.0

        guard let item = self.chatDataSource.message(for: indexPath) else {
            return layoutModel
        }

        let viewClass: AnyClass = self.viewClass(forItem: item)! as AnyClass

        if viewClass === QMChatIncomingCell.self || viewClass === QMChatAttachmentIncomingCell.self {

            if self.dialog.type != QBChatDialogType.private {
                let topAttributedString = self.topLabelAttributedString(forItem: item)
                let size = TTTAttributedLabel.sizeThatFitsAttributedString(topAttributedString, withConstraints: CGSize(width: collectionView.frame.width - 40.0, height: CGFloat.greatestFiniteMagnitude), limitedToNumberOfLines:1)
                layoutModel.topLabelHeight = size.height
            }

            layoutModel.spaceBetweenTopLabelAndTextView = 5
        }

        var size = CGSize.zero

        if self.detailedCells.contains(item.id!) {

            let bottomAttributedString = self.bottomLabelAttributedString(forItem: item)
            size = TTTAttributedLabel.sizeThatFitsAttributedString(bottomAttributedString, withConstraints: CGSize(width: collectionView.frame.width - 40.0, height: CGFloat.greatestFiniteMagnitude), limitedToNumberOfLines:0)
        }

        layoutModel.bottomLabelHeight = floor(size.height)


        return layoutModel
    }
    
    
    func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        
        guard let item = self.chatDataSource.message(for: indexPath) else {
            return false
        }
        
        let viewClass: AnyClass = self.viewClass(forItem: item)! as AnyClass
        
        if  viewClass === QMChatNotificationCell.self ||
            viewClass === QMChatContactRequestCell.self {
            return false
        }
        
        return self.collectionView(collectionView, canPerformAction: action, forItemAt: indexPath, withSender: sender)
    }
    
    func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
        
        let item = self.chatDataSource.message(for: indexPath)
        
        if (item?.isMediaMessage())! {
            ServicesManager.instance().chatService.chatAttachmentService.localImage(forAttachmentMessage: item!, completion: { (image) in
                
                if image != nil {
                    guard let imageData = UIImageJPEGRepresentation(image!, 1) else { return }
                    
                    let pasteboard = UIPasteboard.general
                    
                    //                    pasteboard.setValue(imageData, forPasteboardType:kUTTypeJPEG as String)
                }
            })
        }
        else {
            UIPasteboard.general.string = item?.text
        }
    }
    
    
    
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let lastSection = self.collectionView!.numberOfSections - 1
        
        if (indexPath.section == lastSection && indexPath.item == (self.collectionView?.numberOfItems(inSection: lastSection))! - 1) {
            // the very first message
            // load more if exists
            // Getting earlier messages for chat dialog identifier.
            
            guard let dialogID = self.dialog.id else {
                print("DialogID is nil")
                return self.collectionView(collectionView, cellForItemAt: indexPath)
            }
            
            ServicesManager.instance().chatService.loadEarlierMessages(withChatDialogID: dialogID).continue({ [weak self] (task) -> Any? in
                
                guard let strongSelf = self else { return nil }
                
                if (task.result?.count ?? 0 > 0) {
                    
                    strongSelf.chatDataSource.add(task.result as! [QBChatMessage]!)
                }
                
                return nil
            })
        }
        
        // marking message as read if needed
        if let message = self.chatDataSource.message(for: indexPath) {
            self.sendReadStatusForMessage(message: message)
        }
        
//        return self.collectionView(collectionView, cellForItemAt: indexPath)
//        return self.collectionView(collectionView, cellForItemAt: indexPath)
        
        
        let messageItem:QBChatMessage = self.chatDataSource.message(for: indexPath)
        let clas = self.viewClass(forItem: messageItem)
        let itemIdentifier = clas?.cellReuseIdentifier()
        print(itemIdentifier)
        
        let cell:QMChatCell = collectionView.dequeueReusableCell(withReuseIdentifier: itemIdentifier!, for: indexPath) as! QMChatCell
        
//        self.collectionView(collectionView, configureCell: cell, for IndexPath: indexPath)
        
        self.collectionView(collectionView, confiCell: cell, forIndexPath: indexPath)
        
        return cell
    }
    
    func collectionView(_ collectionView:UICollectionView!, confiCell cell:UICollectionViewCell!, forIndexPath indexPath:IndexPath) {
        
        if cell is QMChatContactRequestCell {
            let contactRequestCell = (cell as? Any) as? QMChatContactRequestCell
            //            contactRequestCell?.actionsHandler = actionsHandler
        }
        
        let messageItem:QBChatMessage = self.chatDataSource.message(for: indexPath)
        
        if cell is QMChatNotificationCell {
            (cell as? QMChatNotificationCell)?.notificationLabel?.attributedText = attributedString(forItem: messageItem)
            return
        }
        
        if cell is QMChatCell {
            let chatCell = cell as? QMChatCell
            if cell is QMChatIncomingCell || cell is QMChatOutgoingCell || cell is QMChatBaseLinkPreviewCell {
                chatCell?.textView.enabledTextCheckingTypes = enableTextCheckingTypes
            }
//            chatCell?.topLabel.text = topLabelAttributedString(forItem: messageItem) as? String
//            chatCell?.textView.text = attributedString(forItem: messageItem) as? String
//            chatCell?.bottomLabel.text = bottomLabelAttributedString(forItem: messageItem) as? String
            
            chatCell?.topLabel.attributedText = topLabelAttributedString(forItem: messageItem)
            chatCell?.textView.attributedText = attributedString(forItem: messageItem)
            chatCell?.bottomLabel.attributedText = bottomLabelAttributedString(forItem: messageItem)
        }
        
        
        
        // subscribing to cell delegate
        let chatCell = cell as! QMChatCell
        
        chatCell.delegate = self
        
        let message = self.chatDataSource.message(for: indexPath)
        print(message)
        
        if let attachmentCell = cell as? QMChatAttachmentCell {
            
            if attachmentCell is QMChatAttachmentIncomingCell {
                chatCell.containerView?.bgColor = UIColor(red: 226.0/255.0, green: 226.0/255.0, blue: 226.0/255.0, alpha: 1.0)
            }
            else if attachmentCell is QMChatAttachmentOutgoingCell {
                chatCell.containerView?.bgColor = UIColor(red: 10.0/255.0, green: 95.0/255.0, blue: 255.0/255.0, alpha: 1.0)
            }
            
            if let attachment = message?.attachments?.first {
                
                var keysToRemove: [String] = []
                
                let enumerator = self.attachmentCellsMap.keyEnumerator()
                
                while let existingAttachmentID = enumerator.nextObject() as? String {
                    let cachedCell = self.attachmentCellsMap.object(forKey: existingAttachmentID as AnyObject?)
                    if cachedCell === cell {
                        keysToRemove.append(existingAttachmentID)
                    }
                }
                
                for key in keysToRemove {
                    self.attachmentCellsMap.removeObject(forKey: key as AnyObject?)
                }
                
                self.attachmentCellsMap.setObject(attachmentCell, forKey: attachment.id as AnyObject?)
                
                attachmentCell.attachmentID = attachment.id
                
                // Getting image from chat attachment cache.
                
                ServicesManager.instance().chatService.chatAttachmentService.image(forAttachmentMessage: message!, completion: { [weak self] (error, image) in
                    
                    guard attachmentCell.attachmentID == attachment.id else {
                        return
                    }
                    
                    self?.attachmentCellsMap.removeObject(forKey: attachment.id as AnyObject?)
                    
                    guard error == nil else {
//                        SVProgressHUD.showError(withStatus: error!.localizedDescription)
                        return
                    }
                    
                    if image == nil {
                        print("Image is nil")
                    }
                    
                    attachmentCell.setAttachmentImage(image)
                    cell.updateConstraints()
                })
            }
        }
        else if cell is QMChatIncomingCell || cell is QMChatAttachmentIncomingCell {
            
            chatCell.containerView?.bgColor = UIColor(red: 226.0/255.0, green: 226.0/255.0, blue: 226.0/255.0, alpha: 1.0)
        }
        else if cell is QMChatOutgoingCell {
            
            let status: QMMessageStatus = self.queueManager().status(for: message!)
            
            switch status {
            case .sent:
                //                chatCell.containerView?.bgColor = UIColor(red: 10.0/255.0, green: 95.0/255.0, blue: 255.0/255.0, alpha: 1.0)
                chatCell.containerView.bgColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            case .sending:
                chatCell.containerView?.bgColor = UIColor(red: 166.3/255.0, green: 171.5/255.0, blue: 171.8/255.0, alpha: 1.0)
            case .notSent:
                chatCell.containerView?.bgColor = UIColor(red: 254.6/255.0, green: 30.3/255.0, blue: 12.5/255.0, alpha: 1.0)
            }
        }
        else if cell is QMChatAttachmentOutgoingCell {
            chatCell.containerView?.bgColor = UIColor(red: 10.0/255.0, green: 95.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        }
        else if cell is QMChatNotificationCell {
            cell.isUserInteractionEnabled = false
            chatCell.containerView?.bgColor = self.collectionView?.backgroundColor
        }
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
//        let collectionViewLay = QMChatCollectionViewFlowLayout()
//        return collectionViewLay.sizeForItem(at: indexPath)
        
        return self.sizeForItemAtIndexPath(indexPath: indexPath)
    }
    
    
    
    
    // ***************** Other Methods ***************//
    func sizeForItemAtIndexPath(indexPath:IndexPath) -> CGSize {
        
        let containerSize:CGSize = self.containerViewSizeForItemAtIndexPath(indexPath: indexPath)
        return CGSize(width: self.itemWidth(), height: CGFloat(ceilf(Float(containerSize.height))))
    }
    
    func itemWidth() -> CGFloat {
        return collectionView.frame.width - collectionView.contentInset.left - collectionView.contentInset.right
    }
    
    func containerViewSizeForItemAtIndexPath(indexPath:IndexPath) -> CGSize {
        
        let itemID:String = self.collectionView(collectionView, itemIdAt: indexPath)
        
        let layoutModel:QMChatCellLayoutModel = self.collectionView(collectionView, layoutModelAt: indexPath)
        var finalSize = CGSize()
        
        if __CGSizeEqualToSize(layoutModel.staticContainerSize, CGSize.zero) {
            
            let spacingBetweenAvatarAndBubble:CGFloat = 2.0
            let horizontalContainerInsets:CGFloat = layoutModel.containerInsets.left + layoutModel.containerInsets.right
            let horizontalInsetsTotal:CGFloat = horizontalContainerInsets + spacingBetweenAvatarAndBubble
            var maximumWidth:CGFloat = self.itemWidth() - layoutModel.avatarSize.width - layoutModel.maxWidthMarginSpace
            
            if layoutModel.maxWidth > 0 {
                
                maximumWidth = min(maximumWidth, layoutModel.maxWidth - layoutModel.avatarSize.width - layoutModel.maxWidthMarginSpace)
            }
            assert(maximumWidth >= 0, "Maximum width cannot be a negative nuber. Please check your maxWidthMarginSpace value.")
            
            let dynamicSize:CGSize = self.collectionView(collectionView, dynamicSizeAt: indexPath, maxWidth: maximumWidth - horizontalInsetsTotal)
            let verticalContainerInsets:CGFloat = layoutModel.containerInsets.top + layoutModel.containerInsets.bottom + layoutModel.topLabelHeight + layoutModel.bottomLabelHeight
            
            let additionalSpace:CGFloat = layoutModel.spaceBetweenTextViewAndBottomLabel + layoutModel.spaceBetweenTopLabelAndTextView
            
            let finalWidth:CGFloat = dynamicSize.width + horizontalContainerInsets
            
            let cellHeight:CGFloat = dynamicSize.height + verticalContainerInsets + additionalSpace
            let finalCellHeight:CGFloat = max(cellHeight, layoutModel.avatarSize.height)
            
            var minWidth = self.collectionView(collectionView, minWidthAt: indexPath)
            minWidth += horizontalContainerInsets
            
            finalSize = CGSize(width: min(max(finalWidth, minWidth), maximumWidth), height: finalCellHeight)
            
        }
        else
        {
            finalSize = layoutModel.staticContainerSize
        }
        
        print(finalSize)
        
        return finalSize
    }
    
    
    
    
    
    
    
    func scrollViewShouldScrollToTop(_ scrollView: UIScrollView) -> Bool {
        return false
    }
    
    func scrollIsAtTop() -> Bool
    {
        return self.scrollVisibleRect().maxX >= self.scrollTopRect().maxX
    }
    
    func scrollVisibleRect() -> CGRect
    {
        var visibleRect:CGRect = CGRect.zero
        visibleRect.origin = self.collectionView.contentOffset
        visibleRect.size = self.collectionView.frame.size
        
        return visibleRect
    }
    
    func scrollTopRect() -> CGRect
    {
        return CGRect(x: 0.0, y: self.collectionView.contentSize.height - self.collectionView.bounds.height, width: self.collectionView.bounds.width, height: self.collectionView.bounds.height)
    }
    
    

    
    

    
    

    
    func updateCollectionViewInsets() {
        
        let topValue:CGFloat = 0
        let bottomValue:CGFloat = self.topContentAdditionalInset
        self.setCollectionViewInsetsTopValue(top: topValue, bottomValue: bottomValue)
    }
    
    func setCollectionViewInsetsTopValue(top:CGFloat, bottomValue bottom:CGFloat)
    {
        let insets:UIEdgeInsets = UIEdgeInsetsMake(top, 0.0, bottom, 0.0)
        
        if UIEdgeInsetsEqualToEdgeInsets(self.collectionView.contentInset, insets) {
            return
        }
        self.collectionView.contentInset = insets
        self.collectionView.scrollIndicatorInsets = insets
        
    }
    
    
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
        coordinator.animateAlongsideTransition(in: nil, animation: { (UIViewControllerTransitionCoordinatorContext) in
            
        }) { (UIViewControllerTransitionCoordinatorContext) in
            self.updateCollectionViewInsets()
        }
        
        if self.inputToolbar.contentView.textView.isFirstResponder && (self.splitViewController != nil) {
            if !(self.splitViewController?.isCollapsed)! {
                self.inputToolbar.contentView.textView.resignFirstResponder()
            }
        }
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
    }
    

    


    
    
    
    
    
    
    
    

    
    
}
































