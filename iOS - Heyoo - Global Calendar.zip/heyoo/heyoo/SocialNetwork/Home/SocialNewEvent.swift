//
//  SocialNewEvent.swift
//  heyoo
//
//  Created by Intorque LLP on 16/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import AVFoundation
import Alamofire
import Quickblox


protocol calendarDraftEventCreateProtocol {
    func setUpdatedCalendarData(dicCalendar : NSMutableDictionary)
}

class SocialNewEvent: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UINavigationControllerDelegate, UIImagePickerControllerDelegate, reminderSelectionProtocol, invitePeopleSelectProtocol, repeatSelectionProtocol {
    var delegate:calendarDraftEventCreateProtocol?
    @IBOutlet weak var imgViewIconStartClock: UIImageView!
    @IBOutlet weak var imgViewIconEndClock: UIImageView!
    @IBOutlet weak var btnSelectCalendar: UIButton!
    @IBOutlet weak var viewMediaPlaceholder: UIView!
    @IBOutlet weak var lblRepeatTitle: UILabel!
    @IBOutlet weak var imgViewAllDay: UIImageView!
    @IBOutlet weak var lblSelectCalendar: UITextField!
    @IBOutlet weak var viewNavBackground: UIView!
    @IBOutlet weak var collectEventMedia: UICollectionView!
    @IBOutlet weak var collectionColor: UICollectionView!
    @IBOutlet weak var scrollViewMain: UIScrollView!
    @IBOutlet weak var viewBackColor: UIView!
    @IBOutlet weak var viewDateTimeSelect: UIView!
    @IBOutlet weak var viewMediaBack: UIView!
    @IBOutlet weak var viewLocationBack: UIView!
    @IBOutlet weak var viewInviteListBack: UIView!
    @IBOutlet weak var btnPublish: UIButton!
    @IBOutlet weak var btnSaveAsDraft: UIButton!
    @IBOutlet weak var tblViewInviteList: UITableView!
    @IBOutlet weak var datePickerSelectDate: UIDatePicker!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var lblStartTime: UILabel!
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var lblEndTime: UILabel!
    @IBOutlet weak var viewDatePickerBack: UIView!
    @IBOutlet weak var btnEventMedia: UIButton!
    @IBOutlet weak var btnInvitePeople: UIButton!
    @IBOutlet weak var tblViewCalendar: UITableView!
    @IBOutlet weak var viewCalColor: UIView!
    @IBOutlet weak var txtEventTitle: UITextField!
    @IBOutlet weak var txtReminder: UITextField!
    @IBOutlet weak var txtNotes: UITextField!
    @IBOutlet weak var txtLocation: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var viewPopup = UIView()
    var arrColor = NSArray()
    var isStartDate = Bool()
    
    var isCustCal = String()
    var dicCustCalData = NSMutableDictionary()
    
    
    var startDate = Date()
    var endDate = Date()
    var arrMediaData = NSMutableArray()
    var arrCalendarData = NSArray()
    var arrInvitePeople = NSMutableArray()
    
    
    var today = Date()
    
    var dicSelectedCalendar = NSDictionary()
    var strEventSelectColor = String()
    var strSelectTick = String()
    var strRemiderIndex = String()
    var strAllDay = String()
    var strRepeat = String()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        AllBackViewMethods()
        
        if isCustCal == "2"
        {
            print(dicCustCalData)
            dicSelectedCalendar = dicCustCalData
            
            lblSelectCalendar.text = dicSelectedCalendar.value(forKey: "Name") as? String
            viewCalColor.backgroundColor = postCalendarColorInTableCell(strColor: dicSelectedCalendar.value(forKey: "Color") as! String)
            btnSelectCalendar.isEnabled = false
            
            getAllCalendarAPICall()
        }
        
        viewCalColor.layer.cornerRadius = viewCalColor.frame.size.width/2
        
        arrColor = [customColor.color1, customColor.color2, customColor.color3, customColor.color4, customColor.color5, customColor.color6, customColor.color7]
        
        lblStartDate.text = self.dateFormatter.string(from: today)
        lblStartTime.text = self.timeFormatter.string(from: today)
        
        endDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: today)!
        lblEndDate.text = self.dateFormatter.string(from: endDate)
        lblEndTime.text = self.timeFormatter.string(from: endDate)
        
        strAllDay = "1"
        strRepeat = "1"
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        scrollViewMain.contentSize = CGSize(width: self.view.frame.size.width, height: btnSaveAsDraft.frame.origin.y + btnSaveAsDraft.frame.size.height + 30)
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    
    // ********** All Button Action ********** //
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionReminderSelect(_ sender: UIButton)
    {
        let reminderVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialSelectReminderVC") as! SocialSelectReminderVC
        reminderVC.delegate = self
        self.navigationController?.pushViewController(reminderVC, animated: true)
    }
    
    @IBAction func ActionDatePickerDone(_ sender: UIButton)
    {
        viewDatePickerBack.isHidden = true
    }
    
    @IBAction func ActionEventMedia(_ sender: UIButton)
    {
        let imag = UIImagePickerController()
        imag.delegate = self
        imag.sourceType = UIImagePickerControllerSourceType.photoLibrary
        imag.mediaTypes = ["public.image", "public.movie"]
        imag.allowsEditing = false
        self.present(imag, animated: true, completion: nil)
    }
    
    @IBAction func ActionInvitePeople(_ sender: UIButton)
    {
        print(arrInvitePeople)
        let inviteVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialInvitePeopleVC") as! SocialInvitePeopleVC
        inviteVC.arrInvitedPeople = arrInvitePeople
        inviteVC.delegate = self
        self.navigationController?.pushViewController(inviteVC, animated: true)
    }
    
    @IBAction func ActionLoadCalendar(_ sender: UIButton)
    {
        if arrCalendarData.count == 0
        {
            getAllCalendarAPICall()
        }
        else
        {
            showCalendarSelectionPopup()
        }
    }
    
    @IBAction func ActionPublishEvent(_ sender: UIButton)
    {
        createEventAndDraftEventAPICall(strEventType: "Publish")
    }
    
    @IBAction func ActionSaveAsDraft(_ sender: UIButton)
    {
        createEventAndDraftEventAPICall(strEventType: "Draft")
    }
    
    @IBAction func ActionAllDay(_ sender: UIButton)
    {
        if strAllDay == "1"
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxOrange")
            strAllDay = "2"
            
            datePickerSelectDate.datePickerMode = .date
            imgViewIconStartClock.isHidden = true
            imgViewIconEndClock.isHidden = true
            lblStartTime.isHidden = true
            lblEndTime.isHidden = true
        }
        else
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxBlack")
            strAllDay = "1"
            
            datePickerSelectDate.datePickerMode = .dateAndTime
            imgViewIconStartClock.isHidden = false
            imgViewIconEndClock.isHidden = false
            lblStartTime.isHidden = false
            lblEndTime.isHidden = false
        }
    }
    
    @IBAction func ActionRepeat(_ sender: UIButton)
    {
        let repeatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialSelectRepeatVC") as! SocialSelectRepeatVC
        repeatVC.strRepeatIndex = strRepeat
        repeatVC.delegate = self
        self.navigationController?.pushViewController(repeatVC, animated: true)
    }
    
    @objc func ActionDeleteMediaButton(sender: UIButton!)
    {
        arrMediaData.removeObject(at: sender.tag)
        collectEventMedia.reloadData()
        
        if arrMediaData.count == 0
        {
            viewMediaPlaceholder.isHidden = false
        }
    }
    
    @IBAction func ActionStartDateSelect(_ sender: UIButton)
    {
        isStartDate = true
        
        viewDatePickerBack.isHidden = false
        datePickerSelectDate.minimumDate = today
        
        if startDate > today
        {
            datePickerSelectDate.date = startDate
        }
        else
        {
            datePickerSelectDate.date = today
        }
    }
    
    @IBAction func ActionEndDateSelect(_ sender: UIButton)
    {
        isStartDate = false
        viewDatePickerBack.isHidden = false
        
        datePickerSelectDate.datePickerMode = UIDatePickerMode.dateAndTime
        if startDate > endDate
        {
//            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
            datePickerSelectDate.minimumDate = startDate
            datePickerSelectDate.date = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
        }
        else
        {
//            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
//            datePickerSelectDate.date = endDate
            
            datePickerSelectDate.minimumDate = startDate
            datePickerSelectDate.date = endDate
        }
    }
    
    // ********** UIDatePickerView Methods ********** //
    
    @IBAction func startDatePickerHandle(_ sender: UIDatePicker)
    {
        if isStartDate == true
        {
            lblStartDate.text = self.dateFormatter.string(from: sender.date)
            lblStartTime.text = self.timeFormatter.string(from: sender.date)
            
            startDate = sender.date
            
            let startTimeInterval = Int(startDate.timeIntervalSinceReferenceDate)
            let endTimeInterval = Int(endDate.timeIntervalSinceReferenceDate)
            
            if startTimeInterval > endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else if startTimeInterval == endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
        }
        else
        {
            endDate = sender.date
            lblEndDate.text = self.dateFormatter.string(from: endDate)
            lblEndTime.text = self.timeFormatter.string(from: endDate)
        }
    }
    
    
    // ********** UIImagePickerControllerDelegate Methods ********** //
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        arrMediaData.add(info as Any)
        collectEventMedia.reloadData()
        
        viewMediaPlaceholder.isHidden = true
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    private func thumbnailForVideoAtURL(url: NSURL) -> UIImage? {
        
        let asset = AVAsset(url: url as URL)
        let assetImageGenerator = AVAssetImageGenerator(asset: asset)
        
        var time = asset.duration
        time.value = min(time.value, 2)
        
        do {
            let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
            
        } catch {
            print("error")
            return nil
        }
    }
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if tableView == tblViewCalendar
        {
            return 1
        }
        else
        {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView == tblViewCalendar
        {
            return arrCalendarData.count
        }
        else
        {
            return arrInvitePeople.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if tableView == tblViewCalendar
        {
            let cellCal : SocialNewEventCalTblCell = tableView.dequeueReusableCell(withIdentifier: "cellCalID") as! SocialNewEventCalTblCell
            
            let dicCalendar = arrCalendarData[indexPath.row] as! NSDictionary
            print(dicCalendar)
            
            cellCal.lblCalendarName.text = dicCalendar.value(forKey: "Name") as? String
            cellCal.imgViewCalColor.backgroundColor = postCalendarColorInTableCell(strColor: dicCalendar.value(forKey: "Color") as! String)
            cellCal.imgViewCalColor.layer.cornerRadius = cellCal.imgViewCalColor.frame.size.width/2
            cellCal.imgViewCalColor.frame.size = CGSize(width: 10, height: 10)
            
            cellCal .selectionStyle = UITableViewCellSelectionStyle.none
            return cellCal
        }
        else
        {
            let cell : UITableViewCell = (tableView.dequeueReusableCell(withIdentifier: "cell"))!
            
            let dicPeople = arrInvitePeople[indexPath.row] as! NSDictionary
            
            cell.textLabel?.text = (dicPeople["FullName"] as! String)
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if tableView == tblViewCalendar
        {
            dicSelectedCalendar = arrCalendarData[indexPath.row] as! NSDictionary
            
            print(dicSelectedCalendar)
            let arrCalMember = dicSelectedCalendar["Members"] as! NSArray
            print(arrCalMember)
            
            arrInvitePeople = NSMutableArray()
            for i in (0..<arrCalMember.count)
            {
                let dicPeople = arrCalMember[i] as! NSDictionary
                let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
                if strUserID != dicPeople["UserID"] as? String
                {
                    let strStatus = dicPeople["Status"] as? String
                    if strStatus != "1"
                    {
                        arrInvitePeople.add(dicPeople)
                    }
                }
            }
            tblViewInviteList.reloadData()
            
            lblSelectCalendar.text = dicSelectedCalendar.value(forKey: "Name") as? String
            viewCalColor.backgroundColor = postCalendarColorInTableCell(strColor: dicSelectedCalendar.value(forKey: "Color") as! String)
            
            self.tblViewCalendar.isHidden = true
            self.viewPopup.isHidden = true
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if tableView == tblViewCalendar
        {
            return 1
        }
        else
        {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        if tableView == tblViewCalendar
        {
            return 1
        }
        else
        {
            return 0
        }
    }
    
    
    // ********** All Backview Shadow Method ********** //
    
    func AllBackViewMethods()
    {
        viewBackColor.layer.shadowColor = UIColor.lightGray.cgColor
        viewBackColor.layer.shadowOpacity = 0.4
        viewBackColor.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewBackColor.layer.shadowRadius = 3
        
        viewDateTimeSelect.layer.shadowColor = UIColor.lightGray.cgColor
        viewDateTimeSelect.layer.shadowOpacity = 0.4
        viewDateTimeSelect.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewDateTimeSelect.layer.shadowRadius = 3
        
        viewMediaBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewMediaBack.layer.shadowOpacity = 0.4
        viewMediaBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewMediaBack.layer.shadowRadius = 3
        
        viewLocationBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewLocationBack.layer.shadowOpacity = 0.4
        viewLocationBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLocationBack.layer.shadowRadius = 3
        
        viewInviteListBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewInviteListBack.layer.shadowOpacity = 0.4
        viewInviteListBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewInviteListBack.layer.shadowRadius = 3
        
        btnPublish.layer.shadowColor = UIColor.lightGray.cgColor
        btnPublish.layer.shadowOpacity = 0.4
        btnPublish.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPublish.layer.shadowRadius = 5.0
        
        btnSaveAsDraft.layer.shadowColor = UIColor.lightGray.cgColor
        btnSaveAsDraft.layer.shadowOpacity = 0.4
        btnSaveAsDraft.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnSaveAsDraft.layer.shadowRadius = 5.0
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    fileprivate lazy var timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        return formatter
    }()
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if collectionView == collectionColor
        {
            return arrColor.count
        }
        else
        {
            return arrMediaData.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        if collectionView == collectionColor
        {
            let cellColor : collectColorCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! collectColorCell
            
            cellColor.viewColor.backgroundColor = arrColor[indexPath.item] as? UIColor
            
            if strSelectTick == "\(indexPath.item)"
            {
                cellColor.imgViewTick.isHidden = false
            }
            else
            {
                cellColor.imgViewTick.isHidden = true
            }
            
            return cellColor
        }
        else
        {
            let cellMedia : collectNewEventMediaCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellMedia", for: indexPath) as! collectNewEventMediaCell
            
            let info = arrMediaData.object(at: indexPath.item) as! [String : Any]
            
            if let mediaType = info[UIImagePickerControllerMediaType] as? String {
                
                if mediaType == "public.image"
                {
                    cellMedia.imgView.image = (info[UIImagePickerControllerOriginalImage] as! UIImage)
                    cellMedia.imgViewPlayIcon.isHidden = true
                }
                
                if mediaType == "public.movie"
                {
                    let videoURL = info[UIImagePickerControllerMediaURL] as? NSURL
                    cellMedia.imgView.image = thumbnailForVideoAtURL(url: videoURL!)
                    cellMedia.imgViewPlayIcon.isHidden = false
                }
            }
            
            cellMedia.btnDelete.tag = indexPath.item
            cellMedia.btnDelete.addTarget(self, action: #selector(self.ActionDeleteMediaButton(sender:)), for: .touchUpInside)
            
            return cellMedia
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if collectionView == collectionColor
        {
            return CGSize(width: collectionColor.frame.size.height, height: collectionColor.frame.size.height)
        }
        else
        {
            return CGSize(width: collectEventMedia.frame.size.height, height: collectEventMedia.frame.size.height)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if collectionView == collectionColor
        {
            viewNavBackground.backgroundColor = arrColor[indexPath.item] as? UIColor
            strEventSelectColor = "\(indexPath.item+1)"
            strSelectTick = "\(indexPath.row)"
            collectionColor.reloadData()
        }
        else
        {
            
        }
    }
    
    // ********** Gel All Calendar Api Call ********** //
    
    func getAllCalendarAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: { (action: UIAlertAction) in
                
                self.getAllCalendarAPICall()
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Userid":strUserID, "Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Type":"2", "Action":"GetAllCalendars"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response.debugDescription)
                        
                        let dicGetAllCalendar = response.result.value as? [String: Any]
                        print(dicGetAllCalendar)
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicGetAllCalendar?["status"] as? String == "success"
                        {
                            self.arrCalendarData = dicGetAllCalendar?["data"] as! NSArray
                            print(self.arrCalendarData)
                            if self.isCustCal == "2"
                            {
                                var dicMatched = NSDictionary()
                                let strSelectedCalID = self.dicSelectedCalendar["CalendarID"] as! String
                                for i in (0..<self.arrCalendarData.count)
                                {
                                    let dicTempCal = self.arrCalendarData[i] as! NSDictionary
                                    if dicTempCal["CalendarID"] as! String == strSelectedCalID
                                    {
                                        dicMatched = dicTempCal
                                        break
                                    }
                                }
                                
                                let arrCalMember = dicMatched["Members"] as! NSArray
                                print(arrCalMember)
                                
                                self.arrInvitePeople = NSMutableArray()
                                for i in (0..<arrCalMember.count)
                                {
                                    let dicPeople = arrCalMember[i] as! NSDictionary
                                    let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
                                    if strUserID != dicPeople["UserID"] as? String
                                    {
                                        let strStatus = dicPeople["Status"] as? String
                                        if strStatus != "1"
                                        {
                                            self.arrInvitePeople.add(dicPeople)
                                        }
                                    }
                                }
                                
                                self.tblViewInviteList.reloadData()
                            }
                            else
                            {
                                self.tblViewCalendar.reloadData()
                                self.showCalendarSelectionPopup()
                            }
                        }
                        else if dicGetAllCalendar?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicGetAllCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    
    func showCalendarSelectionPopup()
    {
        self.tblViewCalendar.isHidden = false
        
        self.viewPopup.frame = self.view.bounds
        self.viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        self.viewPopup.addSubview(self.tblViewCalendar)
        self.view.addSubview(self.viewPopup)
        
        self.viewPopup.isHidden = false
        
        self.tblViewCalendar.frame.size.height = 1
        
        if self.tblViewCalendar.contentSize.height > self.view.frame.size.height - self.tblViewCalendar.frame.origin.y - 30
        {
            UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseOut, animations: {
                self.tblViewCalendar.frame.size.height = self.view.frame.size.height - self.tblViewCalendar.frame.origin.y - 30
            }, completion: nil)
        }
        else
        {
            UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseOut, animations: {
                self.tblViewCalendar.frame.size.height = self.tblViewCalendar.contentSize.height
            }, completion: nil)
            
        }
    }
    
    
    // ********** Repeat Selection Protocol Methods ********** //
    func setSelectedRepeatIndex(selectedIndex: String)
    {
        strRepeat = selectedIndex
    }
    
    func setSelectedRepeat(selectRepeat: String)
    {
        lblRepeatTitle.text = selectRepeat
    }
    
    
    // ********** Reminder Selection Protocol Methods ********** //
    
    func setSelectedReminder(selectReminder: String)
    {
        txtReminder.text = selectReminder
    }
    
    func setSelectedReminderIndex(selectedIndex: String)
    {
        print(selectedIndex)
        strRemiderIndex = selectedIndex
    }
    
    
    // ********** Invite People Selection Protocol Methods ********** //
    func setSelectedInvitedPeople(selectInvite: NSMutableArray)
    {
        arrInvitePeople = NSMutableArray()
        arrInvitePeople = selectInvite
        tblViewInviteList.reloadData()
    }
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == viewPopup
            {
                viewPopup.isHidden = true
                tblViewCalendar.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    func postCalendarColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    // ********** Create And Draft Event WebService Call ********** //
    
    func createEventAndDraftEventAPICall(strEventType: String)
    {
        print(dicSelectedCalendar)
        print(strEventSelectColor)
        print(txtEventTitle.text as Any)
        print("Start Date = \(String(describing: lblStartDate.text))")
        print("Start Time = \(String(describing: lblStartTime.text))")
        print("End Date = \(String(describing: lblEndDate.text))")
        print("End Time = \(String(describing: lblEndTime.text))")
        print("Location = \(String(describing: txtLocation.text))")
        print("Notes = \(String(describing: txtNotes.text))")
        print("Reminder = \(String(describing: txtReminder.text))")
        
        
        var arrImageData = NSMutableArray()
        var arrVideoData = NSMutableArray()
        
        for i in (0..<arrMediaData.count)
        {
            let info = arrMediaData.object(at: i) as! [String : Any]
            print(info)
            
            let strMediaType = info[UIImagePickerControllerMediaType] as? String
            
            if strMediaType == "public.image"
            {
                let image = info[UIImagePickerControllerOriginalImage]
                let imageData = UIImageJPEGRepresentation(image! as! UIImage, 0.5)! as NSData
                arrImageData.add(imageData)
            }
            else
            {
                let videoURL = info[UIImagePickerControllerMediaURL] as? NSURL
                let videoData = NSData(contentsOf: videoURL! as URL)! as NSData
                arrVideoData.add(videoData)
            }
        }
        
        let strCalCheck = dicSelectedCalendar.value(forKey: "CalendarID") as? String
        if strCalCheck?.count == 0 || strCalCheck == nil
        {
            let alertControl = UIAlertController(title: nil, message: "Please Select Calendar", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if txtEventTitle.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Enter Event Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if strEventSelectColor.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Choose Event Color.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strCalID = dicSelectedCalendar.value(forKey: "CalendarID") as? String
        
            let strStartDateServer = self.dateServerFormatter.string(from: startDate)
            let strStartTimeServer = self.timeServerFormatter.string(from: startDate)
        
            let strEndDateServer = self.dateServerFormatter.string(from: endDate)
            let strEndTimeServer = self.timeServerFormatter.string(from: endDate)
        
            let arrAllPeopleUserID = NSMutableArray()
            for dicTempCheck in arrInvitePeople
            {
                let dicTemp = dicTempCheck as! NSDictionary
                let strSelectedU_ID = dicTemp["UserID"] as! String
            
                arrAllPeopleUserID.add(strSelectedU_ID)
            }
        
            let jsonDataForInvitePeople: Data? = try? JSONSerialization.data(withJSONObject: arrAllPeopleUserID, options: [])
            let jsonStringForInvitePeople = String(data: jsonDataForInvitePeople ?? Data(), encoding: .utf8)
        
            var strEventAction = String()
            if strEventType == "Publish"
            {
                strEventAction = "Add"
            }
            else
            {
                strEventAction = "Draft"
            }
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Action":strEventAction, "Val_Calendarid":strCalID, "Val_Userid":strUserID, "Val_Title":txtEventTitle.text! as String, "Val_Color":strEventSelectColor, "Val_Startdate":strStartDateServer, "Val_Starttime":strStartTimeServer, "Val_EndDate":strEndDateServer, "Val_Endtime":strEndTimeServer, "Val_Allday":strAllDay, "Val_Repeat":strRepeat, "Val_Videos":"", "Val_Location":txtLocation.text! as String, "Val_Notes":txtNotes.text! as String, "Val_Reminder":strRemiderIndex, "Val_Images":"", "Val_InvitedUsers": jsonStringForInvitePeople, "Val_Timezone":strTimezone, "Val_IsDST":strDST]
            print(parameters)
        
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    if value?.count == 0
                    {
                        if key == "Val_Images"
                        {
                            for imageData in arrImageData
                            {
                                multipartFormData.append(imageData as! Data, withName: "Val_Images\([])", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                            }
                        }
                        
                        if key == "Val_Videos"
                        {
                            for videoData in arrVideoData
                            {
                                multipartFormData.append(videoData as! Data, withName: "Val_Videos\([])", fileName: "\(Date().timeIntervalSince1970).mp4", mimeType: "video/mp4")
                            }
                        }
                    }
                    else
                    {
                        multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                        
                    }
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        print(response.description)
                        
                        let dicUpdateResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicUpdateResponse?["status"] as? String == "success"
                        {
                            if strEventType == "Publish"
                            {
                                let alertControl = UIAlertController(title: "Event Published", message: "Members Invited to the event will be notified.", preferredStyle: .alert)
                                alertControl.addAction(UIAlertAction(title: "Got it!", style: .default, handler: { (gotIt:UIAlertAction) in
                                    
                                    self.getDialogs()
                                    self.navigationController?.popViewController(animated: true)
                                }))
                                self.present(alertControl, animated: true, completion: nil)
                                
                            }
                            else
                            {
                                if self.isCustCal == "2"
                                {
                                    self.calendarDetailAPICall()
                                }
                                else
                                {
                                    self.navigationController?.popViewController(animated: true)
                                }
                            }
                        }
                        else if dicUpdateResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):

                    MBProgressHUD.hide(for: self.view, animated: true)

                    print(encodingError)
                }
            }
        }
    }
    
    // MARK: - DataSource Action
    
    func getDialogs() {
        
//        SVProgressHUD.show(withStatus: "Loading Dialog", maskType: SVProgressHUDMaskType.clear)
        
        ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
            
        }, completion: { (response: QBResponse?) -> Void in
            
            guard response != nil && response!.isSuccess else {
//                SVProgressHUD.showError(withStatus: "FAILED_LOAD_DIALOGS")
                return
            }
            
//            SVProgressHUD.showSuccess(withStatus: "Completed")
        })
    }
    
    // *********** Calendar Detail API Call ********** //
    func calendarDetailAPICall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Calendar/Fetch"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strCalID = dicCustCalData["CalendarID"] as! String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Calendarid":strCalID, "Val_Userid":strUserID, "Action":"SingleCalendar"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicNotifReadMark = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicNotifReadMark?["status"] as? String == "success"
                    {
                        print(dicNotifReadMark)
                        let arrData = dicNotifReadMark!["data"] as! NSArray
                        let dicCalData = arrData[0] as! NSDictionary
                        print(dicCalData)
                        
                        let dicCalendarTemp = dicCalData.mutableCopy()
                        let dicCalDataTemp = dicCalendarTemp as! NSMutableDictionary
                        
                        self.delegate?.setUpdatedCalendarData(dicCalendar: dicCalDataTemp)
                        self.navigationController?.popViewController(animated: true)
                    }
                    else if dicNotifReadMark?["status"] as? String == "error"
                    {
                        
                    }
                })

            case .failure(let encodingError):

                MBProgressHUD.hide(for: self.view, animated: true)

                print(encodingError)
            }
        }
    }
    
    // ********** ServerSide Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "YYYY-MM-dd"
        return formatter
    }()
    
    fileprivate lazy var timeServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()

}

































