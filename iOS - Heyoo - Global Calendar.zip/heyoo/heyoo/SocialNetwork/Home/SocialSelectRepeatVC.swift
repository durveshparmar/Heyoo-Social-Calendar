//
//  SocialSelectRepeatVC.swift
//  heyoo
//
//  Created by Gaurav Patel on 07/12/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

protocol repeatSelectionProtocol {
    func setSelectedRepeat(selectRepeat : String)
    func setSelectedRepeatIndex(selectedIndex : String)
}

class SocialSelectRepeatVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var delegate:repeatSelectionProtocol?
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var strRepeatIndex = String()
    var arrRepeat = NSMutableArray()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        arrRepeat = ["Never", "Every Day", "Every Week", "Every 2 Weeks", "Every Month", "Every Year"]
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    // ********** UITableviewDeleagete And Datasource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 10
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrRepeat.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        
        cell.textLabel?.text = (arrRepeat[indexPath.row] as! String)
        
        let index = Int(strRepeatIndex)
        if index!-1 == indexPath.row
        {
            cell.accessoryType = .checkmark
        }
        else
        {
            cell.accessoryType = .none
        }
        
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        delegate?.setSelectedRepeatIndex(selectedIndex: "\(indexPath.row+1)")
        delegate?.setSelectedRepeat(selectRepeat: arrRepeat[indexPath.row] as! String)
        self.navigationController?.popViewController(animated: true)
    }
    

}

































