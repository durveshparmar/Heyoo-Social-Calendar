//
//  SocialHomeVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 05/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Quickblox
import QMChatViewController
import QMServices


class SocialHomeVC: UIViewController, UITableViewDelegate, UITableViewDataSource, FSCalendarDataSource, FSCalendarDelegate, FSCalendarDelegateAppearance {
    @IBOutlet weak var imgViewCheckMonthView: UIImageView!
    @IBOutlet weak var imgViewCheckWeekView: UIImageView!
    @IBOutlet weak var viewTopHead: UIView!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var viewCalenderBackCover: UIView!
    @IBOutlet var calendar: FSCalendar!
    @IBOutlet weak var lblCalenderHeader: UILabel!
    @IBOutlet weak var btnAddEvent: UIButton!
    @IBOutlet weak var viewSwitchUser: UIView!
    @IBOutlet weak var viewMore: UIView!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblEventAvailOrNot: UILabel!
    @IBOutlet weak var lblUnpublishBadge: UILabel!
    
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    var viewPopup = UIView()
    var dicEventList = NSMutableDictionary()
    var arrEventListDateKey = NSMutableArray()
    var strSelectedDate = String()
    var isWeek : Bool = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        ServicesManager.instance().chatService.connect(completionBlock: nil)
        ServicesManager.instance().chatService.connect { (error) in
            print(error)
        }
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        lblUnpublishBadge.layer.cornerRadius = lblUnpublishBadge.frame.size.height / 2
        lblUnpublishBadge.isHidden = true
        
        calendar.appearance.eventDefaultColor = UIColor.orange
        calendar.appearance.eventSelectionColor = UIColor.orange
        
        viewCalenderBackCover.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalenderBackCover.layer.shadowOpacity = 0.4
        viewCalenderBackCover.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalenderBackCover.layer.shadowRadius = 3
        
        viewSwitchUser.layer.shadowColor = UIColor.lightGray.cgColor
        viewSwitchUser.layer.shadowOpacity = 0.4
        viewSwitchUser.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewSwitchUser.layer.shadowRadius = 3
        
        viewMore.layer.shadowColor = UIColor.lightGray.cgColor
        viewMore.layer.shadowOpacity = 0.4
        viewMore.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewMore.layer.shadowRadius = 3
        
        let currentDate = Date()
        lblCalenderHeader.text = self.dateFormatter.string(from: currentDate)
        
//        let currentDate = Date()
        calendar.setCurrentPage(currentDate, animated: true)
        
        let calendarGesture = UIPanGestureRecognizer(target: calendar, action: #selector(calendar.handleScopeGesture(_:)));
        calendar.addGestureRecognizer(calendarGesture)
        let calendarBackCoverGesture = UIPanGestureRecognizer(target: calendar, action: #selector(calendar.handleScopeGesture(_:)));
        viewCalenderBackCover.addGestureRecognizer(calendarBackCoverGesture)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
//        strSelectedDate = ""
        
        if self.calendar.scope == .month
        {
            imgViewCheckMonthView.isHidden = false
            imgViewCheckWeekView.isHidden = true
        }
        else
        {
            imgViewCheckMonthView.isHidden = true
            imgViewCheckWeekView.isHidden = false
        }
        
//        let currentDate = Date()
//        calendar.setCurrentPage(currentDate, animated: true)
        
        getProfileImageDocumentDirectory()
        dashboardAPICall()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionVIPCalendar(_ sender: UIButton) {
        let alertCntrl = UIAlertController(title: nil, message: "Coming soon.", preferredStyle: .alert)
        alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alertCntrl, animated: true, completion: nil)
    }
    
    @IBAction func ActionUnpublishedDrafts(_ sender: UIButton)
    {
        let unpubDraftVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialUnpublishDraftVC") as! SocialUnpublishDraftVC
        unpubDraftVC.strIsMainCalendar = "Yes"
        self.navigationController?.pushViewController(unpubDraftVC, animated: true)
        
    }
    
    @IBAction func ActionNewEvent(_ sender: UIButton)
    {
        let newEventVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialNewEvent") as! SocialNewEvent
        self.navigationController?.pushViewController(newEventVC, animated: true)
    }
    
    @IBAction func ActionSwitchUser(_ sender: UIButton)
    {
        viewSwitchUser.isHidden = false
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.0)
        viewPopup.addSubview(viewSwitchUser)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
    }
    
    
    @IBAction func ActionMoreButton(_ sender: UIButton)
    {
        viewMore.isHidden = false
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.0)
        viewPopup.addSubview(viewMore)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
    }
    
    @IBAction func ActionMonthView(_ sender: UIButton)
    {
        self.calendar.setScope(.month, animated: true)
        
        imgViewCheckMonthView.isHidden = false
        imgViewCheckWeekView.isHidden = true
        
        viewPopup.isHidden = true
        viewMore.isHidden = true
    }
    
    @IBAction func ActionListView(_ sender: UIButton)
    {
        self.calendar.setScope(.week, animated: true)
        
        imgViewCheckMonthView.isHidden = true
        imgViewCheckWeekView.isHidden = false
        
        viewPopup.isHidden = true
        viewMore.isHidden = true
    }
    
    @IBAction func ActionCalNext(_ sender: UIButton)
    {
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = 1
        }
        else
        {
            dateComponents.weekOfMonth = 1
        }
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    @IBAction func ActionCalPrev(_ sender: UIButton)
    {
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = -1
        }
        else
        {
            dateComponents.weekOfMonth = -1
        }
        
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    // ********** UITableViewDelegate And Datasource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if strSelectedDate != ""
        {
            return 1
        }
        else
        {
            return dicEventList.count
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            return arrEventSelectedDate.count
            
        }
        else
        {
            print(dicEventList[arrEventListDateKey[section]])
            let arrEventSectionWise = dicEventList[arrEventListDateKey[section]] as! NSArray
            return arrEventSectionWise.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : socialHomeTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! socialHomeTblCell
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        
        print(dicPerticularEvent)
        if dicPerticularEvent["EventClickable"] as! String == "1"
        {
            cell.viewColor.backgroundColor = UIColor .black
            
            cell.imgImage.image = cell.imgImage.image!.withRenderingMode(.alwaysTemplate)
            cell.imgImage.tintColor = UIColor .black
            
            cell.imgVideo.image = cell.imgVideo.image!.withRenderingMode(.alwaysTemplate)
            cell.imgVideo.tintColor = UIColor .black
        }
        else
        {
            cell.viewColor.backgroundColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
            
            cell.imgImage.image = cell.imgImage.image!.withRenderingMode(.alwaysTemplate)
            cell.imgImage.tintColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
            
            cell.imgVideo.image = cell.imgVideo.image!.withRenderingMode(.alwaysTemplate)
            cell.imgVideo.tintColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
        }
        
        cell.lblEventName.text = dicPerticularEvent["EventTitle"] as? String
        var countImgAndVideo = dicPerticularEvent["EventVideos"] as! Int64
        cell.lblVideoCount.text = String(countImgAndVideo)
        countImgAndVideo = dicPerticularEvent["EventImages"] as! Int64
        cell.lblMessageCount.text = String(countImgAndVideo)
        
        if dicPerticularEvent["EventAllDay"] as! String == "2" {
            
            cell.lblTime.text = "All Day"
        }
        else {
            
            let inFormatter = DateFormatter()
            inFormatter.dateFormat = "HH:mm:ss"
            let outFormatter = DateFormatter()
            outFormatter.dateFormat = "hh:mma"
            
            let inTime = dicPerticularEvent["EventStartTime"] as! String
            let date = inFormatter.date(from: inTime)!
            let outTime = outFormatter.string(from: date)
            cell.lblTime.text = outTime
        }
        
        
        let arrInviteImages = dicPerticularEvent["EventMembers"] as! NSArray
        print(arrInviteImages)
        
        cell.imgView2.layer.cornerRadius = cell.imgView2.frame.size.width/2
        cell.imgView3.layer.cornerRadius = cell.imgView3.frame.size.width/2
        cell.imgView4.layer.cornerRadius = cell.imgView4.frame.size.width/2
        
        if arrInviteImages.count == 0
        {
            cell.imgView4.image = nil
            cell.imgView3.image = nil
            cell.imgView2.image = nil
            cell.imgView4.backgroundColor = UIColor.clear
            cell.viewInviteUsers.isHidden = true
        }
        else if arrInviteImages.count == 1
        {
            let dicImg0 = arrInviteImages[0] as! NSDictionary
            cell.imgView4.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            cell.imgView3.image = nil
            cell.imgView2.image = nil
            cell.viewInviteUsers.isHidden = false
        }
        else if arrInviteImages.count == 2
        {
            let dicImg0 = arrInviteImages[0] as! NSDictionary
            cell.imgView4.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            
            let dicImg1 = arrInviteImages[1] as! NSDictionary
            cell.imgView3.sd_setImage(with: URL(string : dicImg1["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            cell.imgView2.image = nil
            cell.viewInviteUsers.isHidden = false
        }
        else
        {
            if arrInviteImages.count > 3
            {
                cell.imgView4.image = #imageLiteral(resourceName: "iconGrayDots")
                
                let dicImg0 = arrInviteImages[0] as! NSDictionary
                cell.imgView3.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                
                let dicImg1 = arrInviteImages[1] as! NSDictionary
                cell.imgView2.sd_setImage(with: URL(string : dicImg1["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                cell.viewInviteUsers.isHidden = false
            }
            else
            {
                if arrInviteImages.count != 0
                {
                    let dicImg0 = arrInviteImages[0] as! NSDictionary
                    cell.imgView4.sd_setImage(with: URL(string : dicImg0["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    
                    let dicImg1 = arrInviteImages[1] as! NSDictionary
                    cell.imgView3.sd_setImage(with: URL(string : dicImg1["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    
                    let dicImg2 = arrInviteImages[2] as! NSDictionary
                    cell.imgView2.sd_setImage(with: URL(string : dicImg2["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    cell.viewInviteUsers.isHidden = false
                }
            }
        }
        
        cell.setEditing(true, animated: true)
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 25
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView : socialHomeHeaderViewCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! socialHomeHeaderViewCell
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        
        var strTempDate = String()
        if strSelectedDate != ""
        {
            strTempDate = strSelectedDate
        }
        else
        {
            strTempDate = arrEventListDateKey[section] as! String
        }
        
        let date = dateFormatter.date(from: strTempDate)
        headerView.lblDateTitle.text = self.dateFormatterHeader.string(from: date!)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?
    {
        let viewFooter = UIView()
        viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
        viewFooter.backgroundColor = UIColor .white
        
        return viewFooter
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        var strEventDate = String()
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
            strEventDate = strSelectedDate
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            strEventDate = arrEventListDateKey[indexPath.section] as! String
        }
        print(dicPerticularEvent)
        print(strEventDate)
        
        if dicPerticularEvent["EventClickable"] as! String == "1"
        {
            
        }
        else
        {
            ServicesManager.instance().chatService.fetchDialog(withID: (dicPerticularEvent["EventJID"] as? String)!) { (dialog) in
                
                print(dialog)
                
                if dialog != nil
                {
                    let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                    eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
                    eventDetailVC.dicEventDetPass = dicPerticularEvent
                    eventDetailVC.dialog = dialog
                    eventDetailVC.arrMemberList = dicPerticularEvent["EventMembers"] as! NSArray
                    eventDetailVC.strGroupDate = strEventDate
                    self.navigationController?.pushViewController(eventDetailVC, animated: true)
                }
                else
                {
                    self.getDialogs(dicPerticularEvent: dicPerticularEvent)
                }
            }
        }
    }
    
    func getDialogs(dicPerticularEvent:NSDictionary) {
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
            
        }, completion: { (response: QBResponse?) -> Void in
            
            guard response != nil && response!.isSuccess else {
                
                return
            }
            
            MBProgressHUD.hide(for: self.view, animated: true)
            
            ServicesManager.instance().chatService.fetchDialog(withID: (dicPerticularEvent["EventJID"] as? String)!) { (dialogFetch) in
            
            MBProgressHUD.hide(for: self.view, animated: true)
            
                
                let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
                eventDetailVC.dicEventDetPass = dicPerticularEvent
                eventDetailVC.dialog = dialogFetch
                eventDetailVC.arrMemberList = dicPerticularEvent["EventMembers"] as! NSArray
                self.navigationController?.pushViewController(eventDetailVC, animated: true)
            }
        })
        
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        
        if dicPerticularEvent["EventClickable"] as! String == "1"
        {
            
        }
        else
        {
            deleteEventAPICall(indexPath: indexPath)
        }
        
    }
    
//    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]?
//    {
//        var dicPerticularEvent = NSDictionary()
//        if strSelectedDate != ""
//        {
//            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
//            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
//        }
//        else
//        {
//            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
//            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
//        }
//
//        if dicPerticularEvent["EventEditable"] as! String == "2"
//        {
//            let delete = UITableViewRowAction(style: .default, title: "Delete") { (action:UITableViewRowAction, indexPath:IndexPath) in
//                self.deleteEventAPICall(indexPath: indexPath)
//
//            }
//            delete.backgroundColor = .red
//
//            let edit = UITableViewRowAction(style: .default, title: "Edit") { (action:UITableViewRowAction, indexPath:IndexPath) in
//                print("Edit at:\(indexPath)")
//            }
//
//            edit.backgroundColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
//
//            return [delete, edit]
//        }
//        else
//        {
//            let delete = UITableViewRowAction(style: .default, title: "Delete") { (action:UITableViewRowAction, indexPath:IndexPath) in
//                self.deleteEventAPICall(indexPath: indexPath)
//
//
//            }
//            delete.backgroundColor = .red
//            return [delete]
//        }
//
//
//
//    }
    
    
    // ********** FSCalendar Deleagete Methods ********** //
    
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM yyyy"
        return formatter
    }()
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar)
    {
        lblCalenderHeader.text = self.dateFormatter.string(from: calendar.currentPage)
        strSelectedDate = ""
        
        let calTemp = Calendar.current
        let year = calTemp.component(.year, from: calendar.currentPage)
        let month = calTemp.component(.month, from: calendar.currentPage)
        print(year)
        print(month)
        
        
        let currentDate = Date()
        let curYear = calTemp.component(.year, from: currentDate)
        let curMonth = calTemp.component(.month, from: currentDate)
        print(curYear)
        print(curMonth)
        
        
        if self.calendar.scope == .month
        {
            getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
        }
        else
        {
            var weekEndDate = Date()
            weekEndDate = NSCalendar.current.date(byAdding: .day, value: 6, to: calendar.currentPage)!
            
            let yearWeek = calTemp.component(.year, from: weekEndDate)
            
            let custCal = Calendar.current
            let weekOfYear = custCal.component(.weekOfYear, from: weekEndDate)
            print(weekOfYear)
            
            let strWeekOfYear = "\(weekOfYear)"
            if strWeekOfYear.count == 1
            {
                getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(yearWeek)")
            }
            else
            {
                getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(yearWeek)")
            }
        }
    }
    
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool)
    {
        self.calendarHeightConstraint.constant = bounds.height
        self.view.layoutIfNeeded()
        
        if self.calendar.scope == .month
        {
            imgViewCheckMonthView.isHidden = false
            imgViewCheckWeekView.isHidden = true
        }
        else
        {
            imgViewCheckMonthView.isHidden = true
            imgViewCheckWeekView.isHidden = false
        }
        print(bounds.height)
        if bounds.height < 100 || bounds.height > 222
        {
            strSelectedDate = ""
            
            self.calendarHeightConstraint.constant = bounds.height
            self.view.layoutIfNeeded()
            
            let calTemp = Calendar.current
            let year = calTemp.component(.year, from: calendar.currentPage)
            let month = calTemp.component(.month, from: calendar.currentPage)
            print(year)
            print(month)
            
            let currentDate = Date()
            let curYear = calTemp.component(.year, from: currentDate)
            let curMonth = calTemp.component(.month, from: currentDate)
            print(curYear)
            print(curMonth)
            
            if self.calendar.scope == .month
            {
                getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
            }
            else
            {
                var weekEndDate = Date()
                weekEndDate = NSCalendar.current.date(byAdding: .day, value: 6, to: calendar.currentPage)!
                
                let yearWeek = calTemp.component(.year, from: weekEndDate)
                
                let custCal = Calendar.current
                let weekOfYear = custCal.component(.weekOfYear, from: weekEndDate)
                print(weekOfYear)
                
                let strWeekOfYear = "\(weekOfYear)"
                if strWeekOfYear.count == 1
                {
                    getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(yearWeek)")
                }
                else
                {
                    getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(yearWeek)")
                }
            }
        }
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition)
    {
        print(date)
        let custCal = Calendar.current
        let weekOfYear = custCal.component(.weekOfYear, from: date)
        print(weekOfYear)
        
        let dateString = self.dateFormatter2.string(from: date as Date)
        if arrEventListDateKey.contains(dateString)
        {
            strSelectedDate = "\(dateString)"
            tblView.reloadData()
        }
        else
        {
            let alertCntrl = UIAlertController(title: "Reminder:", message: "No events scheduled on this day.", preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in
               
                self.strSelectedDate = ""
                self.tblView.reloadData()
            }))
            self.present(alertCntrl, animated: true, completion: nil)
        }
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillSelectionColorFor date: Date) -> UIColor?
    {
        return UIColor.orange.withAlphaComponent(0.3)
    }
    
    func calendar(_ calendar: FSCalendar!, appearance: FSCalendarAppearance!, titleDefaultColorFor date: Date!) -> UIColor!
    {
        let dateString = self.dateFormatter2.string(from: date as Date)
        
        if arrEventListDateKey.contains(dateString)
        {
            return UIColor.orange
        }
        
        return nil
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int
    {
        let dateString = self.dateFormatter2.string(from: date)
        if arrEventListDateKey.contains(dateString) {
            return 1
        }
        return 0
    }
    
    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == viewPopup
            {
                viewPopup.isHidden = true
                viewMore.isHidden = true
                viewSwitchUser.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    // ********** Get Profile Picture Document Directory ********** //
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
    
    
    // MARK:
    // MARK: All WebServices
    
    // ********** Get Week wise Events ********** //
    
    func getWeekWiseEventList(strWeek:String, strYear:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/DateWiseList"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Userid":strUserID, "Val_Status":"2", "Val_Year":strYear, "Val_Week":strWeek, "Action":"GetWeekWise", "Val_Timezone":strTimezone, "Val_IsDST":strDST]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    print(response)
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary
                        print(dicData)
                        
                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicData.mutableCopy() as! NSMutableDictionary
                        
                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }
                        
                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)
                            
                        }
                        
                        if self.arrEventListDateKey.count == 0
                        {
                            self.lblEventAvailOrNot.isHidden = false
                        }
                        else
                        {
                            self.lblEventAvailOrNot.isHidden = true
                        }
                        
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                        self.lblEventAvailOrNot.isHidden = false
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                        self.lblEventAvailOrNot.isHidden = false
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    
    // ********** Get Month wise Events ********** //
    
    func getMonthWiseEventList(strMonth:String, strYear:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/DateWiseList"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Userid":strUserID, "Val_Status":"2", "Val_Year":strYear, "Val_Month":strMonth, "Action":"GetMonthWise", "Val_Timezone":strTimezone, "Val_IsDST":strDST]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    print(response)
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary
                        print(dicData)
                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicData.mutableCopy() as! NSMutableDictionary
                        
                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }
                        
                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)
                            
                        }
                        
                        if self.arrEventListDateKey.count == 0
                        {
                            self.lblEventAvailOrNot.isHidden = false
                        }
                        else
                        {
                            self.lblEventAvailOrNot.isHidden = true
                        }
                        
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                        self.lblEventAvailOrNot.isHidden = false
                        
//                        let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
//                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        self.lblEventAvailOrNot.isHidden = false
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    
    
    // ********** Dateboard API CAll ********** //
    
    func dashboardAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
                //                self.deleteEventAPICall(indexPath: indexPath)
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Dashboard"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Userid":strUserID, "Action":"GetData", "Val_Timezone":strTimezone, "Val_IsDST":strDST]
            print(parameters)
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        print(response)
                        
                        let dicLoginResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicLoginResponse?["status"] as? String == "success"
                        {
                            let dicData = dicLoginResponse?["data"] as! NSDictionary
                            print(dicData)
                            
                            let dicUserData = dicData["UserData"] as! NSDictionary
                            if dicUserData["status"] as! String == "error"
                            {
                                let alertCntrl = UIAlertController(title: "Warning", message: "\(dicUserData["message"] as! String)", preferredStyle: .alert)
                                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in
                                    
                                    UserDefaults.standard.set(nil, forKey: "socialUserID")
                                    UserDefaults.standard.synchronize()
                                    
                                    let selectVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginSelectionVC") as! LoginSelectionVC
                                    self.navigationController?.pushViewController(selectVC, animated: false)
                                }))
                                self.present(alertCntrl, animated: true, completion: nil)
                                
                            }
                            else
                            {
                                let strPrivacy = dicUserData["Privacy"] as! String
                                UserDefaults.standard.set(strPrivacy, forKey: "isAccountPrivacy")
                                UserDefaults.standard.synchronize()
                                
                                if let tabItems = self.tabBarController?.tabBar.items as NSArray!
                                {
                                    let dicMiscData = dicData["MiscData"] as! NSDictionary
                                    let tabItem = tabItems[4] as! UITabBarItem
                                    if dicMiscData["status"] as! String == "error"
                                    {
                                        tabItem.badgeValue = nil
                                        self.lblUnpublishBadge.isHidden = true
                                    }
                                    else
                                    {
                                        let tabBadge:Int = dicMiscData["NotificationCount"] as! Int
                                        if tabBadge == 0
                                        {
                                            tabItem.badgeValue = nil
                                        }
                                        else
                                        {
                                            tabItem.badgeValue = String(tabBadge)
                                        }
                                        
                                        let unpubBadge:Int = dicMiscData["UnpublishedCount"] as! Int
                                        if unpubBadge == 0
                                        {
                                            self.lblUnpublishBadge.isHidden = true
                                        }
                                        else
                                        {
                                            self.lblUnpublishBadge.isHidden = false
                                            self.lblUnpublishBadge.text = String(unpubBadge)
                                        }
                                    }
                                }
                                
                                
                                let cal = Calendar.current
                                var dateComponents = DateComponents()
                                dateComponents.day = 1
                                
                                let formatter = DateFormatter()
                                formatter.dateFormat = "YYYY-MM"
                                
                                let strCalDate = formatter.string(from: cal.date(byAdding: dateComponents, to: self.calendar.currentPage)!)
                                let strCurrDate = formatter.string(from: Date())
                                
                                if strCalDate == strCurrDate
                                {
                                    let dicEventListTemp = dicData["EventsData"] as! NSDictionary
                                    self.dicEventList = NSMutableDictionary()
                                    self.dicEventList = dicEventListTemp.mutableCopy() as! NSMutableDictionary
                                    
                                    let testArray = self.dicEventList.allKeys as NSArray
                                    var convertedArray: [Date] = []
                                    
                                    let dateFormatter = DateFormatter()
                                    dateFormatter.dateFormat = "yyyy-MM-dd"
                                    
                                    for dat in testArray {
                                        let strDate = dat as! String
                                        let date = dateFormatter.date(from: strDate)
                                        if let date = date {
                                            convertedArray.append(date)
                                        }
                                    }
                                    
                                    self.arrEventListDateKey = NSMutableArray()
                                    let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                                    for dateArr in ready
                                    {
                                        let strFinalDate = dateFormatter.string(from: dateArr)
                                        self.arrEventListDateKey.add(strFinalDate)
                                        
                                    }
                                    
                                    if self.arrEventListDateKey.count == 0
                                    {
                                        self.lblEventAvailOrNot.isHidden = false
                                    }
                                    else
                                    {
                                        self.lblEventAvailOrNot.isHidden = true
                                    }
                                    
                                    
                                    self.tblView.reloadData()
                                    self.calendar.reloadData()
                                }
                                
                            }
                        }
                        else if dicLoginResponse?["status"] as? String == "error"
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            self.calendar.reloadData()
                            
                            let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            self.calendar.reloadData()
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
        
    }
    
    // ********** Delete Event Api Call ********** //
    
    func deleteEventAPICall(indexPath: IndexPath)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
//                self.deleteEventAPICall(indexPath: indexPath)
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            var dicPerticularEvent = NSDictionary()
            if strSelectedDate != ""
            {
                let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
                dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
            }
            else
            {
                let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
                dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            }
            let strEventID = dicPerticularEvent.value(forKey: "EventID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Eventid":strEventID, "Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"Delete", "Val_Userid":strUserID]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDeleteCalendar = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDeleteCalendar?["status"] as? String == "success"
                        {
                            let calTemp = Calendar.current
                            let year = calTemp.component(.year, from: self.calendar.currentPage)
                            let month = calTemp.component(.month, from: self.calendar.currentPage)
                            print(year)
                            print(month)
                            
                            if self.calendar.scope == .month
                            {
                                self.getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
                            }
                            else
                            {
                                let custCal = Calendar.current
                                let weekOfYear = custCal.component(.weekOfYear, from: self.calendar.currentPage)
                                print(weekOfYear)
                                
                                let strWeekOfYear = "\(weekOfYear)"
                                if strWeekOfYear.count == 1
                                {
                                    self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)")
                                }
                                else
                                {
                                    let strWeekOfYear = "\(weekOfYear)"
                                    if strWeekOfYear.count == 1
                                    {
                                        self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)")
                                    }
                                    else
                                    {
                                        self.getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(year)")
                                    }
                                }
                            }
                            
                        }
                        else if dicDeleteCalendar?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDeleteCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
        
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatterHeader: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
}





























