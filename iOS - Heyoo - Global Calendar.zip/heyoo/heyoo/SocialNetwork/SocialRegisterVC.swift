//
//  SocialRegisterVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 03/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire

class SocialRegisterVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    var strPhoneNumber = NSString()
    var strCountryCode = NSString()
    var strCheck = NSString()
    
    
    
    @IBOutlet var viewRegister: UIView!
    @IBOutlet var btnRegister: UIButton!
    @IBOutlet weak var btnSelectCountry: UIButton!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var txtEmailAddress: UITextField!
    @IBOutlet var txtCountryCode: UITextField!
    @IBOutlet var txtMobileNumber: UITextField!
    @IBOutlet var txtSearchBar: UISearchBar!
    
    var searchActive : Bool = false
    var filtered = NSArray()
    
    var viewPopup = UIView()
    var blurView = UIVisualEffectView()
    var arrCountryCode = NSArray()
    var strSelectCountryCode = NSString()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewRegister.layer.shadowColor = UIColor.lightGray.cgColor
        viewRegister.layer.shadowOpacity = 0.4
        viewRegister.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewRegister.layer.shadowRadius = 3
        
//        btnRegister.layer.shadowColor = UIColor.lightGray.cgColor
//        btnRegister.layer.shadowOpacity = 1.0
//        btnRegister.layer.shadowOffset = CGSize(width: 0.0, height: 0.5)
//        btnRegister.layer.shadowRadius = 5.0
//        btnRegister.layer.masksToBounds = false
        
        btnRegister.layer.shadowColor = UIColor.lightGray.cgColor
        btnRegister.layer.shadowOpacity = 0.4
        btnRegister.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnRegister.layer.shadowRadius = 5.0
        
        let swipeGestureInBackVC = UISwipeGestureRecognizer(target: self, action: #selector(swipeToBackPop))
        swipeGestureInBackVC.direction = .right
        self.view.addGestureRecognizer(swipeGestureInBackVC)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        strSelectCountryCode = "+1"
        
        print(strCountryCode)
        
        self.getCountryCode()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @objc func swipeToBackPop()
    {
        for viewCntrl in (self.navigationController?.viewControllers)!
        {
            if viewCntrl.isKind(of: LoginSelectionVC.self)
            {
                self.navigationController?.popToViewController(viewCntrl, animated: true)
                break
            }
        }
    }
    
    // ********** Email Address Validation ********** //
    
    func isValidEmail(testStr:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    // ********** Mobile Register Or Not Check Webservice call ********** //
    func mobileNumberRegisterOrNotWebserviceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/UserMobile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Email":txtEmailAddress.text! as String, "Val_IsDST":strDST, "Val_Countrycode":strSelectCountryCode as String, "Val_Mobile":txtMobileNumber.text! as String, "Action":"UserCheckMobile"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append((value ).data(using: .utf8)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    print(dicLoginResponse as Any)
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary
                        
                        let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialOTPVC") as! SocialOTPVC
                        otpVC.strSelectCountryCode = self.strSelectCountryCode
                        otpVC.strEmailAddress = self.txtEmailAddress.text! as NSString
                        otpVC.strPhoneNumber = self.txtMobileNumber.text! as NSString
                        otpVC.strScreenCheck = "regScreen" as NSString
                        otpVC.strOTP = dicData["OTP"] as! String
                        self.navigationController?.pushViewController(otpVC, animated: true)
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (okAction:UIAlertAction) in
                            self.navigationController?.popViewController(animated: true)
                        }))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
                
                print(encodingError)
            }
        }
    }
    
    // ********** All Button Action ********** //
    
    @IBAction func ActionRegister(_ sender: UIButton)
    {
        if txtEmailAddress.text?.count == 0 || txtMobileNumber.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "All field are require", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            if self.isValidEmail(testStr: txtEmailAddress.text!)
            {
//                let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialOTPVC") as! SocialOTPVC
//                otpVC.strSelectCountryCode = strSelectCountryCode
//                otpVC.strEmailAddress = txtEmailAddress.text! as NSString
//                otpVC.strPhoneNumber = txtMobileNumber.text! as NSString
//                otpVC.strScreenCheck = "regScreen" as NSString
//                self.navigationController?.pushViewController(otpVC, animated: true)
                
                mobileNumberRegisterOrNotWebserviceCall()
            }
            else
            {
                let alertCntrl = UIAlertController(title: nil, message: "Your Email is invalid", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alertCntrl, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func ActionSelectCountryCode(_ sender: UIButton)
    {
        tblView.isHidden = false
        showAnimateCountry()
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        let effect = UIBlurEffect(style: UIBlurEffectStyle.light)
        blurView = UIVisualEffectView(effect: effect)
        blurView.frame = viewPopup.bounds
        blurView.alpha = 0.7
        viewPopup.addSubview(blurView)
        viewPopup.addSubview(tblView)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
        
        txtSearchBar.becomeFirstResponder()
    }
    
    @IBAction func ActionSignIn(_ sender: UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    // ********* Tableview Delegate DataSource Methods ********* //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if searchActive
        {
            if filtered.count == 0
            {
                return arrCountryCode.count
            }
            else
            {
                return filtered.count
            }
        }
        else
        {
            return arrCountryCode.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        if searchActive
        {
            if filtered.count == 0
            {
                let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
            else
            {
                let dicCountry = filtered[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
        }
        else
        {
            let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
            cell.textLabel?.text = dicCountry["name"] as? String
            cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if searchActive
        {
            if filtered.count == 0
            {
                let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
            else
            {
                let dicSelectCountry = filtered[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
        }
        else
        {
            let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
            txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
            
            strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
        }
        
        txtSearchBar.text = nil
        txtSearchBar.resignFirstResponder()
        viewPopup.isHidden = true
        filtered = NSArray()
        tblView.reloadData()
    }
    
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == blurView
            {
                txtSearchBar.text = nil
                txtSearchBar.resignFirstResponder()
                viewPopup.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    func showAnimateCountry()
    {
        viewPopup.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        viewPopup.alpha = 0.0
        UIView.animate(withDuration: 0.25, animations: {
            self.viewPopup.alpha = 1.0
            self.viewPopup.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        })
    }
    
    func getCountryCode()
    {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json")
        {
            let jsonData = NSData(contentsOfFile: path)
            do
            {
                arrCountryCode = try JSONSerialization.jsonObject(with: jsonData! as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSArray
                
                tblView.reloadData()
                
            } catch {}
        }
    }
    
    // ********** UISearchbarDelegate Methods ********** //
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)
    {
        searchActive = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        filtered = arrCountryCode.filter({ (text) -> Bool in
            let dicCountry = text as! NSDictionary
            let tmp: NSString = dicCountry["name"] as! NSString
            let range = tmp.range(of: searchText, options: .caseInsensitive)
            return range.location != NSNotFound
        }) as! [NSDictionary] as NSArray
        
        if filtered.count == 0
        {
            searchActive = false
        }
        else
        {
            searchActive = true
        }
        tblView.reloadData()
    }
    
}























