//
//  SocialLoginVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 03/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire

class SocialLoginVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    @IBOutlet var viewLogin: UIView!
    @IBOutlet var btnLogin: UIButton!
    @IBOutlet var tblView: UITableView!
    @IBOutlet var txtCountryCode: UITextField!
    @IBOutlet var txtMobileNumber: UITextField!
    @IBOutlet var txtSearchBar: UISearchBar!
    
    var searchActive : Bool = false
    var filtered = NSArray()
    
    var viewPopup = UIView()
    var blurView = UIVisualEffectView()
    var arrCountryCode = NSArray()
    var strSelectCountryCode = NSString()
    var imageProPic = UIImage()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        viewLogin.layer.shadowColor = UIColor.lightGray.cgColor
        viewLogin.layer.shadowOpacity = 0.4
        viewLogin.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLogin.layer.shadowRadius = 3
        
        btnLogin.layer.shadowColor = UIColor.lightGray.cgColor
        btnLogin.layer.shadowOpacity = 0.4
        btnLogin.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnLogin.layer.shadowRadius = 5.0
        
        let swipeGestureInBackVC = UISwipeGestureRecognizer(target: self, action: #selector(swipeToBackPop))
        swipeGestureInBackVC.direction = .right
        self.view.addGestureRecognizer(swipeGestureInBackVC)
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        strSelectCountryCode = "+1"
        
        self.getCountryCode()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    @objc func swipeToBackPop()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    // ********** Call Login WibService Method ********** //
    
    func LoginWebServiceCall()
    {
        if txtMobileNumber.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Authentication/SignIn"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let tokenString = UserDefaults.standard.value(forKey: "deviceToken") as! String
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_IsDST":strDST, "Val_Countrycode":strSelectCountryCode as String, "Val_iOSToken":tokenString, "Val_Mobile":txtMobileNumber.text! as String, "Action":"UserSignIn"]
            print(parameters)
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append((value ).data(using: .utf8)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicLoginResponse = response.result.value as? [String: Any]
                        print(dicLoginResponse)
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicLoginResponse?["status"] as? String == "success"
                        {
                            let dicData = dicLoginResponse?["data"] as! NSDictionary
                            print(dicData)
                            
                            let strUserID = dicData["UserID"] as! String
                            let strPrivacy = dicData["Privacy"] as! String
                            
//                            UserDefaults.standard.set(strUserID, forKey: "socialUserID")
                            UserDefaults.standard.set(strPrivacy, forKey: "isAccountPrivacy")
                            UserDefaults.standard.set("2", forKey: "InvitePopup")
                            UserDefaults.standard.synchronize()
                            
                            if dicData["ProfileImage"] as? String != nil
                            {
                                MBProgressHUD.showAdded(to: self.view, animated: true)
                                
                                let strImgURL = dicData["ProfileImage"] as? String
                                let imgURL = NSURL(string: strImgURL!)
                                
                                self.getDataFromUrl(url: imgURL! as URL) { data, response, error in
                                    guard let data = data, error == nil else { return }
                                    DispatchQueue.main.async() {
                                        
                                        self.imageProPic = UIImage(data: data)!
                                        self.saveProfileImageDocumentDirectory()
                                        
                                        MBProgressHUD.hide(for: self.view, animated: true)
                                        
                                        let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialOTPVC") as! SocialOTPVC
                                        otpVC.strScreenCheck = "logScreen" as NSString
                                        otpVC.strPhoneNumber = dicData["Mobile"] as! NSString
                                        otpVC.strEmailAddress = dicData["Email"] as! NSString
                                        otpVC.strOTP = dicData["OTP"] as! String
                                        otpVC.strSelectCountryCode = self.strSelectCountryCode
                                        otpVC.strUserID = strUserID
                                        self.navigationController?.pushViewController(otpVC, animated: true)
                                    }
                                }
                            }
                            else
                            {
                                let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialOTPVC") as! SocialOTPVC
                                otpVC.strScreenCheck = "logScreen" as NSString
                                self.navigationController?.pushViewController(otpVC, animated: true)
                            }
                            
                        }
                        else if dicLoginResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** Image URL Convert To Data ********** //
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    @IBAction func ActionLogin(_ sender: UIButton)
    {
        LoginWebServiceCall()
    }
    
    @IBAction func ActionSelectCountryCode(_ sender: UIButton)
    {
        tblView.isHidden = false
        showAnimateCountry()
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        let effect = UIBlurEffect(style: UIBlurEffectStyle.light)
        blurView = UIVisualEffectView(effect: effect)
        blurView.frame = viewPopup.bounds
        blurView.alpha = 0.7
        viewPopup.addSubview(blurView)
        viewPopup.addSubview(tblView)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
        
        txtSearchBar.becomeFirstResponder()
    }
    
    @IBAction func ActionSignUp(_ sender: UIButton)
    {
        let regVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialRegisterVC") as! SocialRegisterVC
        self.navigationController?.pushViewController(regVC, animated: true)
        
    }
    
    // ********* Tableview Delegate DataSource Methods ********* //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if searchActive
        {
            if filtered.count == 0
            {
                return arrCountryCode.count
            }
            else
            {
                return filtered.count
            }
        }
        else
        {
            return arrCountryCode.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        if searchActive
        {
            if filtered.count == 0
            {
                let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
            else
            {
                let dicCountry = filtered[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
        }
        else
        {
            let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
            cell.textLabel?.text = dicCountry["name"] as? String
            cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if searchActive
        {
            if filtered.count == 0
            {
                let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
            else
            {
                let dicSelectCountry = filtered[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
        }
        else
        {
            let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
            txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
            
            strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
        }
        
        txtSearchBar.text = nil
        txtSearchBar.resignFirstResponder()
        viewPopup.isHidden = true
        filtered = NSArray()
        tblView.reloadData()
    }
    
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == blurView
            {
                txtSearchBar.text = nil
                txtSearchBar.resignFirstResponder()
                viewPopup.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    func showAnimateCountry()
    {
        viewPopup.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        viewPopup.alpha = 0.0
        UIView.animate(withDuration: 0.25, animations: {
            self.viewPopup.alpha = 1.0
            self.viewPopup.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        })
    }
    
    func getCountryCode()
    {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json")
        {
            let jsonData = NSData(contentsOfFile: path)
            do
            {
                arrCountryCode = try JSONSerialization.jsonObject(with: jsonData! as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSArray
                
                tblView.reloadData()
                
            } catch {}
        }
    }
    
    // ********** UISearchbarDelegate Methods ********** //
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)
    {
        searchActive = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        filtered = arrCountryCode.filter({ (text) -> Bool in
            let dicCountry = text as! NSDictionary
            let tmp: NSString = dicCountry["name"] as! NSString
            let range = tmp.range(of: searchText, options: .caseInsensitive)
            return range.location != NSNotFound
        }) as! [NSDictionary] as NSArray
        
        if filtered.count == 0
        {
            searchActive = false
        }
        else
        {
            searchActive = true
        }
        tblView.reloadData()
    }
    
    // ********** Save Profile Picture Document Directory ********** //
    
    func saveProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        do {
            try UIImageJPEGRepresentation(imageProPic, 1.0)!.write(to: fileURL)
        } catch {
            print(error)
        }
    }
    
}


























