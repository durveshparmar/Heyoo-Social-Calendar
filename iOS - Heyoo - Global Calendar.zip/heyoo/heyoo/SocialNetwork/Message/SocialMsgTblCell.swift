//
//  SocialMsgTblCell.swift
//  heyoo
//
//  Created by Gaurav Patel on 07/12/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class SocialMsgTblCell: UITableViewCell {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblLastMsg: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblUnreadMessageCount: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)

        
    }

}







