//
//  SocialChatUserSearchVC.swift
//  heyoo
//
//  Created by Gaurav Patel on 21/12/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Alamofire
import Quickblox
import QMChatViewController
import QMServices
 

class SocialChatUserSearchVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, QMChatServiceDelegate, QMChatConnectionDelegate {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var arrGlobalSearchList = NSArray()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.height/2
        self.getProfileImageDocumentDirectory()
        
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** UITableView Delegate And DataSource Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrGlobalSearchList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell : SocialInviteTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! SocialInviteTblCell
        
        let dicGlobal = arrGlobalSearchList[indexPath.row] as! NSDictionary
        
        cell.lblFullName.text = dicGlobal["FullName"] as? String
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
        
        cell.imgViewIcon.image = #imageLiteral(resourceName: "iconHeyoo")
        cell.lblUserType.text = "\(dicGlobal["City"] as! String), \(dicGlobal["Country"] as! String)"
        
        let strProPicURL = dicGlobal["ProfileImage"] as! String
        cell.imgViewProPic.sd_setImage(with: URL(string : strProPicURL), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let dicGlobal = arrGlobalSearchList[indexPath.row] as! NSDictionary
        print(dicGlobal)
        
        var userSelected: [QBUUser] = []
        QBRequest.user(withLogin: "\(dicGlobal["Mobile"] as! String)", successBlock: { (response, user) in
            userSelected.append(user)
            
            let completion = {[weak self] (response: QBResponse?, createdDialog: QBChatDialog?) -> Void in
                
                if createdDialog != nil {
                    
                    self?.openNewDialog(dialog: createdDialog)
                }
                
                guard let unwrappedResponse = response else {
                    print("Error empty response")
                    return
                }
                
                if let error = unwrappedResponse.error {
                    print(error.error as Any)
//                    SVProgressHUD.showError(withStatus: error.error?.localizedDescription)
                }
                else {
                    
                }
            }
            
            self.createChat(name: nil, users: userSelected, completion: completion)
            
            
        }) { (response) in
            
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let cellHeader : SocialInviteTblCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! SocialInviteTblCell
        
        return cellHeader
    }
    
    func openNewDialog(dialog: QBChatDialog!)
    {
        let navigationArray = self.navigationController?.viewControllers
        let newStack = [] as NSMutableArray
        for vc in navigationArray!
        {
            newStack.add(vc)
            if vc is SocialMessageVC
            {
                let chatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
                chatVC.dialog = dialog
                newStack.add(chatVC)
                self.navigationController?.setViewControllers(newStack.copy() as! [UIViewController], animated: true)
                return
            }
        }
        
        let chatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
        chatVC.dialog = dialog
        self.navigationController?.pushViewController(chatVC, animated: true)
    }
    
    func createChat(name: String?, users:[QBUUser], completion: ((_ response: QBResponse?, _ createdDialog: QBChatDialog?) -> Void)?)
    {
        ServicesManager.instance().chatService.createPrivateChatDialog(withOpponent: users.first!, completion: { (response, chatDialog) in
            
            completion?(response, chatDialog)
        })
    }
    
    
    
    // ********** All Button Action ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionFinishSearch(_ sender: UIButton)
    {
        txtSearch.text = nil
        tblView.reloadData()
    }
    
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        GlobalUserAutoCompleteSearchAPICall()
    }
    
    
    // ********** Global AutoComplete API Call *********** //
    
    func GlobalUserAutoCompleteSearchAPICall()
    {
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Search"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        //        let strSearchText = txtSearch.text
        let strUserID = UserDefaults.standard.value(forKey: "socialUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_User":"\(txtSearch.text ?? "")", "Val_Start":"0", "Action":"GetAllUsers", "Val_Userid":strUserID]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicGlobalSearchResponse = response.result.value as? [String: Any]
                    print(dicGlobalSearchResponse)
                    if dicGlobalSearchResponse?["status"] as? String == "success"
                    {
                        self.arrGlobalSearchList = dicGlobalSearchResponse?["data"] as! NSArray
                        print(self.arrGlobalSearchList)
                        
                        self.tblView.reloadData()
                        
                    }
                    else if dicGlobalSearchResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicGlobalSearchResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                    else
                    {
                        self.arrGlobalSearchList = NSArray()
                        self.tblView.reloadData()
                    }
                })
                
            case .failure(let encodingError):
                
                print(encodingError)
            }
        }
    }
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
    
    
}








































