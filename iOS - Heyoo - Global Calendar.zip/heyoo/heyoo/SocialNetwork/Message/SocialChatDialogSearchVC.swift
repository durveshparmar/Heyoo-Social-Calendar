//
//  SocialChatDialogSearchVC.swift
//  heyoo
//
//  Created by Gaurav Patel on 10/01/18.
//  Copyright © 2018 I N T O R Q U E. All rights reserved.
//

import UIKit
import Quickblox
import QMServices


var lastMessageTimeDateSearchFormatter: DateFormatter {
    struct Static {
        static let instance : DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "hh:mma"
            return formatter
        }()
    }
    
    return Static.instance
}



class SocialChatDialogSearchVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var allDialog = NSMutableArray()
    var filtered = NSArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtSearch.becomeFirstResponder()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.height/2
        self.getProfileImageDocumentDirectory()
        
//        allDialog = self.dialogs()! as NSArray
        self.getPrivateDialog()
        print(allDialog)
        
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    func getPrivateDialog()
    {
        allDialog = NSMutableArray()
        for i in (0..<self.dialogs()!.count)
        {
            let chatDialog:QBChatDialog = (self.dialogs()?[i])!
            if chatDialog.type.rawValue == 3
            {
                allDialog.add(chatDialog)
            }
        }
        tblView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func dialogs() -> [QBChatDialog]?
    {
        return ServicesManager.instance().chatService.dialogsMemoryStorage.dialogsSortByUpdatedAt(withAscending: false)
    }
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        filtered = allDialog.filter({ (text) -> Bool in
            let chatDialog = text as! QBChatDialog
            let tmp: NSString = chatDialog.name as! NSString
            let range = tmp.range(of: txtSearch.text!, options: .caseInsensitive)
            return range.location != NSNotFound
        }) as! [QBChatDialog] as NSArray
        
        tblView.reloadData()
    }
    
    
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
//        return allDialog.count
        return filtered.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cellID") as! SocialMsgTblCell
        
//        guard let chatDialog = self.dialogs()?[indexPath.row] else {
//            return cell
//        }
        
//        let chatDialog = allDialog[indexPath.row] as! QBChatDialog
        let chatDialog = filtered[indexPath.row] as! QBChatDialog
        
        print(chatDialog)
        cell.lblName.text = chatDialog.name
        cell.lblLastMsg.text = chatDialog.lastMessageText
        if chatDialog.lastMessageDate != nil
        {
            cell.lblDate.isHidden = false
            cell.lblDate.text = lastMessageTimeDateFormatter.string(from: chatDialog.lastMessageDate!)
        }
        else
        {
            cell.lblDate.isHidden = true
        }
        cell.lblUnreadMessageCount.layer.cornerRadius = cell.lblUnreadMessageCount.frame.size.height/2
        let unreadMsgCount = Int(chatDialog.unreadMessagesCount)
        if unreadMsgCount == 0
        {
            cell.lblUnreadMessageCount.isHidden = true
        }
        else if unreadMsgCount > 10
        {
            cell.lblUnreadMessageCount.isHidden = false
            cell.lblUnreadMessageCount.text = "9+"
        }
        else
        {
            cell.lblUnreadMessageCount.isHidden = false
            cell.lblUnreadMessageCount.text = "\(unreadMsgCount)"
        }
        
        
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.height/2
        
        //        QBUUser *recipient = [QMCore.instance.usersService.usersMemoryStorage userWithID:[chatDialog opponentID]];
        let recipient = ServicesManager.instance().usersService.usersMemoryStorage.user(withID: chatDialog.userID)
        print(recipient)
        
        print(ServicesManager.instance().currentUser.id)
        
        for i in (0..<(chatDialog.occupantIDs?.count)!) {
            let occuIDCheck:UInt = UInt(truncating: chatDialog.occupantIDs![i])
            if ServicesManager.instance().currentUser.id != occuIDCheck {
                
                QBRequest.user(withID: occuIDCheck, successBlock: { (response, user) in
                    
                    ServicesManager.instance().usersService.usersMemoryStorage.add(user)
                    
                    cell.imgViewProPic.sd_setImage(with: URL(string : user.customData as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    
                }) { (response) in
                    
                }
            }
        }
        
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let chatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
        chatVC.dialog = filtered[indexPath.row] as! QBChatDialog
        self.navigationController?.pushViewController(chatVC, animated: true)
    }
    
    
    // ********** All Button Action ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
    
}






























