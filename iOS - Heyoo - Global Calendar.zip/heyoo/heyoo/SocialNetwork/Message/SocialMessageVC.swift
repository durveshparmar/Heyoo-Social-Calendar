//
//  SocialMessageVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 05/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import Quickblox
import QMServices

var lastMessageTimeDateFormatter: DateFormatter {
    struct Static {
        static let instance : DateFormatter = {
            let formatter = DateFormatter()
            formatter.dateFormat = "hh:mma"
            return formatter
        }()
    }
    
    return Static.instance
}

class DialogTableViewCellModel: NSObject {
    
    var detailTextLabelText: String = ""
    var textLabelText: String = ""
    var unreadMessagesCounterLabelText : String?
    var unreadMessagesCounterHiden = true
    var dialogIcon : UIImage?
    
    
    init(dialog: QBChatDialog) {
        super.init()
        
        switch (dialog.type){
        case .publicGroup:
            self.detailTextLabelText = " PUBLIC_GROUP"
        case .group:
            self.detailTextLabelText = " GROUP"
        case .private:
            self.detailTextLabelText = " PRIVATE"
            
            if dialog.recipientID == -1 {
                return
            }
            
            // Getting recipient from users service.
            if let recipient = ServicesManager.instance().usersService.usersMemoryStorage.user(withID: UInt(dialog.recipientID)) {
//                self.textLabelText = recipient.login ?? recipient.email!
                self.textLabelText = recipient.fullName ?? ""
            }
        }
        
        
        print(dialog)
        
        if self.textLabelText.isEmpty {
            // group chat
            
            if let dialogName = dialog.name {
                self.textLabelText = dialogName
            }
        }
        
        
        // Unread messages counter label
        
        if (dialog.unreadMessagesCount > 0) {
            
            var trimmedUnreadMessageCount : String
            
            if dialog.unreadMessagesCount > 99 {
                trimmedUnreadMessageCount = "99+"
            } else {
                trimmedUnreadMessageCount = String(format: "%d", dialog.unreadMessagesCount)
            }
            
            self.unreadMessagesCounterLabelText = trimmedUnreadMessageCount
            self.unreadMessagesCounterHiden = false
            
        }
        else {
            
            self.unreadMessagesCounterLabelText = nil
            self.unreadMessagesCounterHiden = true
        }
        
        // Dialog icon
        
        if dialog.type == .private {
            self.dialogIcon = UIImage(named: "user")
        }
        else {
            self.dialogIcon = UIImage(named: "group")
        }
    }
}

class SocialMessageVC: UIViewController, UITableViewDelegate, UITableViewDataSource, QMChatServiceDelegate, QMChatConnectionDelegate, QMAuthServiceDelegate, QMUsersServiceDelegate {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    private var didEnterBackgroundDate: NSDate?
    private var observer: NSObjectProtocol?
    
    var controlCheck = Bool()
    var allDialog = NSMutableArray()
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // calling awakeFromNib due to viewDidLoad not being called by instantiateViewControllerWithIdentifier
        self.navigationItem.title = ServicesManager.instance().currentUser.login!
        
        ServicesManager.instance().chatService.addDelegate(self)
        ServicesManager.instance().authService.add(self)
        ServicesManager.instance().usersService.add(self)
        
        self.observer = NotificationCenter.default.addObserver(forName: NSNotification.Name.UIApplicationDidBecomeActive, object: nil, queue: OperationQueue.main) { (notification) -> Void in
            
            if !QBChat.instance.isConnected {
//                SVProgressHUD.show(withStatus: "CONNECTING_TO_CHAT", maskType: SVProgressHUDMaskType.clear)
            }
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(SocialMessageVC.didEnterBackgroundNotification), name: NSNotification.Name.UIApplicationDidEnterBackground, object: nil)
        
        if (QBChat.instance.isConnected) {
            self.getDialogs()
        }
        
    }
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.getPrivateDialog()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        controlCheck = true
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        ServicesManager.instance().chatService.connect(completionBlock: nil)
        
        getProfileImageDocumentDirectory()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    
    @IBAction func ActionSearch(_ sender: UIBarButtonItem)
    {
        let searchChatDialog = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatDialogSearchVC") as! SocialChatDialogSearchVC
        self.navigationController?.pushViewController(searchChatDialog, animated: true)
    }
    
    @IBAction func ActionAddNewMember(_ sender: UIButton)
    {
        let addUserVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatUserSearchVC") as! SocialChatUserSearchVC
        self.navigationController?.pushViewController(addUserVC, animated: true)
    }
    
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
//        if let dialogs = self.dialogs() {
//
//            var dialogCount:Int = 0
//
//            for i in (0..<dialogs.count)
//            {
//                let chatDialog = self.dialogs()?[i]
//                if chatDialog?.type.rawValue == 3
//                {
//                    dialogCount = dialogCount + 1
//                }
//            }
//
//            return dialogCount
//        }
//        return 0
        
        
        return allDialog.count
        
//        if let dialogs = self.dialogs() {
//            return dialogs.count
//        }
//        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cellID") as! SocialMsgTblCell
        
//        if ((self.dialogs()?.count)! < indexPath.row) {
//            return cell
//        }
//
//        guard let chatDialog = self.dialogs()?[indexPath.row] else {
//            return cell
//        }
        
        let chatDialog = allDialog[indexPath.row] as! QBChatDialog
        print(chatDialog)
        
        cell.lblName.text = chatDialog.name
        cell.lblLastMsg.text = chatDialog.lastMessageText
        if chatDialog.lastMessageDate != nil
        {
            cell.lblDate.isHidden = false
            cell.lblDate.text = lastMessageTimeDateFormatter.string(from: chatDialog.lastMessageDate!)
        }
        else
        {
            cell.lblDate.isHidden = true
        }
        cell.lblUnreadMessageCount.layer.cornerRadius = cell.lblUnreadMessageCount.frame.size.height/2
        let unreadMsgCount = Int(chatDialog.unreadMessagesCount)
        if unreadMsgCount == 0
        {
            cell.lblUnreadMessageCount.isHidden = true
        }
        else if unreadMsgCount > 10
        {
            cell.lblUnreadMessageCount.isHidden = false
            cell.lblUnreadMessageCount.text = "9+"
        }
        else
        {
            cell.lblUnreadMessageCount.isHidden = false
            cell.lblUnreadMessageCount.text = "\(unreadMsgCount)"
        }
        
        
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.height/2
        
//        QBUUser *recipient = [QMCore.instance.usersService.usersMemoryStorage userWithID:[chatDialog opponentID]];
        let recipient = ServicesManager.instance().usersService.usersMemoryStorage.user(withID: chatDialog.userID)
        print(recipient)
        
        print(ServicesManager.instance().currentUser.id)
        
        for i in (0..<(chatDialog.occupantIDs?.count)!) {
            let occuIDCheck:UInt = UInt(truncating: chatDialog.occupantIDs![i])
            if ServicesManager.instance().currentUser.id != occuIDCheck {
                
                QBRequest.user(withID: occuIDCheck, successBlock: { (response, user) in
                    
                    ServicesManager.instance().usersService.usersMemoryStorage.add(user)
                    
                    cell.imgViewProPic.sd_setImage(with: URL(string : user.customData as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                    
                }) { (response) in
                    
                }
            }
        }
        
        
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.setEditing(true, animated: true)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
//        guard let dialog = self.dialogs()?[indexPath.row] else {
//            return
//        }
        
        let dialog = allDialog[indexPath.row] as! QBChatDialog
        
        let chatVC = self.storyboard?.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
        chatVC.dialog = dialog
        self.navigationController?.pushViewController(chatVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
//        guard let chatDialog = self.dialogs()?[indexPath.row] else {
//            return
//        }
        
        let chatDialog = allDialog[indexPath.row] as! QBChatDialog
        
        print(chatDialog)
        let chatDiaogID = "\(chatDialog.id ?? "")"
        QBRequest.deleteDialogs(withIDs: Set(arrayLiteral: "\(chatDiaogID)"), forAllUsers: false, successBlock: { (response: QBResponse!, deletedObjectsIDs: [String]?, notFoundObjectsIDs: [String]?, wrongPermissionsObjectsIDs: [String]?) -> Void in
            
            ServicesManager.instance().chatService.deleteDialog(withID: deletedObjectsIDs![0])
            
        }) { (response: QBResponse!) -> Void in
            print(response)
        }
        
    }
    
    // MARK: - Notification handling
    
    @objc func didEnterBackgroundNotification()
    {
        self.didEnterBackgroundDate = NSDate()
    }
    
    // MARK: - DataSource Action
    
    func getDialogs() {
        
        //        if let lastActivityDate = ServicesManager.instance().lastActivityDate {
        //
        //            ServicesManager.instance().chatService.fetchDialogsUpdated(from: lastActivityDate as Date, andPageLimit: kDialogsPageLimit, iterationBlock: { (response, dialogObjects, dialogsUsersIDs, stop) -> Void in
        //
        //            }, completionBlock: { (response) -> Void in
        //
        //                if (response.isSuccess) {
        //
        //                    ServicesManager.instance().lastActivityDate = NSDate()
        //                }
        //            })
        //        }
        //        else {
        
        
//        SVProgressHUD.show(withStatus: "", maskType: SVProgressHUDMaskType.clear)
        
        ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
            
        }, completion: { (response: QBResponse?) -> Void in
            
            guard response != nil && response!.isSuccess else {
//                SVProgressHUD.showError(withStatus: "FAILED")
                return
            }
            
//            SVProgressHUD.showSuccess(withStatus: "")
            //                ServicesManager.instance().lastActivityDate = NSDate()
        })
        //        }
    }
    
    // MARK: - DataSource
    
    func dialogs() -> [QBChatDialog]?
    {
        // Returns dialogs sorted by updatedAt date.
        return ServicesManager.instance().chatService.dialogsMemoryStorage.dialogsSortByUpdatedAt(withAscending: false)
    }
    
    
    // ********** Get Profile Picture Document Directory ********** //
    
    func getProfileImageDocumentDirectory()
    {
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("propic.jpg")
        if FileManager.default.fileExists(atPath: fileURL.path)
        {
            imgViewProPic.image = UIImage(contentsOfFile: fileURL.path)
        }
        else
        {
            
        }
    }
    
    // MARK: - QMChatServiceDelegate
    
    func chatService(_ chatService: QMChatService, didUpdateChatDialogInMemoryStorage chatDialog: QBChatDialog)
    {
        self.getPrivateDialog()
//        self.reloadTableViewIfNeeded()
    }
    
    func chatService(_ chatService: QMChatService,didUpdateChatDialogsInMemoryStorage dialogs: [QBChatDialog])
    {
        self.getPrivateDialog()
//        self.reloadTableViewIfNeeded()
    }
    
    func chatService(_ chatService: QMChatService, didAddChatDialogsToMemoryStorage chatDialogs: [QBChatDialog])
    {
        self.getPrivateDialog()
//        self.reloadTableViewIfNeeded()
    }
    
    func chatService(_ chatService: QMChatService, didAddChatDialogToMemoryStorage chatDialog: QBChatDialog)
    {
        print(chatDialog)
        getDialogs()
        self.getPrivateDialog()
//        self.reloadTableViewIfNeeded()
    }
    
    func chatService(_ chatService: QMChatService, didDeleteChatDialogWithIDFromMemoryStorage chatDialogID: String)
    {
        self.getPrivateDialog()
//        self.reloadTableViewIfNeeded()
    }
    
    func chatService(_ chatService: QMChatService, didAddMessagesToMemoryStorage messages: [QBChatMessage], forDialogID dialogID: String)
    {
        self.getPrivateDialog()
//        self.reloadTableViewIfNeeded()
    }
    
    func chatService(_ chatService: QMChatService, didAddMessageToMemoryStorage message: QBChatMessage, forDialogID dialogID: String)
    {
        self.getPrivateDialog()
//        self.reloadTableViewIfNeeded()
    }
    
    
    // MARK: QMUsersServiceDelegate
    
    func usersService(_ usersService: QMUsersService, didLoadUsersFromCache users: [QBUUser])
    {
        reloadTableViewIfNeeded()
    }
    
    func usersService(_ usersService: QMUsersService, didAdd users: [QBUUser])
    {
        reloadTableViewIfNeeded()
    }
    
    func usersService(_ usersService: QMUsersService, didUpdate users: [QBUUser])
    {
        reloadTableViewIfNeeded()
    }
    
    
    
    
    // MARK: QMChatConnectionDelegate
    
    func chatServiceChatDidFail(withStreamError error: Error)
    {
//        SVProgressHUD.showError(withStatus: error.localizedDescription)
    }
    
    func chatServiceChatDidAccidentallyDisconnect(_ chatService: QMChatService)
    {
//        SVProgressHUD.showError(withStatus: "Chat Disconnected")
    }
    
    func chatServiceChatDidConnect(_ chatService: QMChatService)
    {
//        SVProgressHUD.showSuccess(withStatus: "Chat Connected", maskType:.clear)
        //        if !ServicesManager.instance().isProcessingLogOut! {
        self.getDialogs()
        //        }
    }
    
    func chatService(_ chatService: QMChatService,chatDidNotConnectWithError error: Error)
    {
//        SVProgressHUD.showError(withStatus: error.localizedDescription)
    }
    
    
    func chatServiceChatDidReconnect(_ chatService: QMChatService)
    {
//        SVProgressHUD.showSuccess(withStatus: "Chat Connected", maskType: .clear)
        //        if !ServicesManager.instance().isProcessingLogOut! {
        self.getDialogs()
        //        }
    }
    
    // MARK: - Helpers
    func reloadTableViewIfNeeded()
    {
//                if !ServicesManager.instance().isProcessingLogOut! {
//        self.tblView.reloadData()
//                }
        
        if controlCheck == true
        {
            self.tblView.reloadData()
        }
    }
    
    func getPrivateDialog()
    {
        var UserUnreadCount:Int = 0
        
        allDialog = NSMutableArray()
        for i in (0..<self.dialogs()!.count)
        {
            let chatDialog:QBChatDialog = (self.dialogs()?[i])!
            if chatDialog.type.rawValue == 3
            {
                if chatDialog.unreadMessagesCount != 0
                {
                    UserUnreadCount = UserUnreadCount + 1
                }
                allDialog.add(chatDialog)
            }
        }
        
        if let tabItems = self.tabBarController?.tabBar.items as NSArray!
        {
            let tabItem = tabItems[2] as! UITabBarItem
            
            if UserUnreadCount == 0
            {
                tabItem.badgeValue = nil
            }
            else
            {
                tabItem.badgeValue = String(UserUnreadCount)
            }
        }
        
        reloadTableViewIfNeeded()
        
        
        
//        guard let chatDialog = self.dialogs()?[indexPath.row] else {
//            return
//        }
    }

}































