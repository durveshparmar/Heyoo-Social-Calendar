//
//  TabBarSocial.swift
//  heyoo
//
//  Created by I N T O R Q U E on 05/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class TabBarSocial: UITabBarController, UITabBarControllerDelegate {
    var imageView = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        self.tabBar.tintColor = UIColor.black
        self.tabBar.unselectedItemTintColor = UIColor(red: 199.0/255.0, green: 199.0/255.0, blue: 199.0/255.0, alpha: 1.0)
        
        // ********** Make Tab Bar Underline ********** //
        let view = UIView()
        view.frame = CGRect(x: self.tabBar.frame.origin.x, y: self.tabBar.frame.origin.y, width: self.view.frame.size.width/5, height: 56)
        let border = UIImageView()
        border.frame = CGRect(x: view.frame.origin.x, y: view.frame.size.height-6, width: self.view.frame.size.width/5, height: 3)
        border.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
        view.addSubview(border)
        self.tabBar.selectionIndicatorImage = changeViewToImage(viewForImage: view)
        
        
        
        
//        let itemWidth = tabBar.frame.width / CGFloat(tabBar.items!.count)
//        let size : CGFloat = CGFloat(itemWidth) * CGFloat(2)
//        imageView.frame = CGRect(x: size, y: 5, width: itemWidth-10, height: tabBar.frame.height-10)
//        let image = UIImage(named: "tabIconCalender")
//        let tintedImage = image?.withRenderingMode(.alwaysOriginal)
//        imageView.setImage(tintedImage, for: .normal)
//        imageView.tintColor = UIColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 1.0)
//        tabBar.insertSubview(imageView, at: 1)
        
        
//        self.tabBarController?.tabBar.items![2].image = tintedImage
//        self.tabBarController?.tabBar.items![2].selectedImage = tintedImage
    }
    
    func changeViewToImage(viewForImage: UIView) -> UIImage
    {
        UIGraphicsBeginImageContext(viewForImage.bounds.size)
        viewForImage.layer .render(in: UIGraphicsGetCurrentContext()!)
        let img: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return img
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillLayoutSubviews()
    {
//        var tabFrame = self.tabBar.frame
//        tabFrame.size.height = 80
//        tabFrame.origin.y = self.view.frame.size.height - 80
//        self.tabBar.frame = tabFrame
        
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem)
    {
//        item.badgeValue = nil
        
//        if tabBar.selectedItem {
//            <#code#>
//        }
    }

}
































