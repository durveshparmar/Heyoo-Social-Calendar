//
//  AppDelegate.swift
//  heyoo
//
//  Created by I N T O R Q U E on 02/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import Fabric
import Crashlytics
import Quickblox
import QMServices
import GoogleSignIn
import Google
import UserNotifications

//let kQBApplicationID:UInt = 66237        // My Account Credential
//let kQBAuthKey = "jpzw3EL3e5yN-vz"
//let kQBAuthSecret = "68hYEeS7JEBqKDs"
//let kQBAccountKey = "xQYxs2odtrCxdpxHEMMm"


// Linda's Account Credential
let kQBApplicationID:UInt = 67974
let kQBAuthKey = "6dCYMJBG2pvZ6b-"
let kQBAuthSecret = "azKsRGwrDtZG8Qq"
let kQBAccountKey = "C95iJsCHneCty9KsJPVc"

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool
    {
        // Initialize sign-in
        var configureError: NSError?
        GGLContext.sharedInstance().configureWithError(&configureError)
        assert(configureError == nil, "Error configuring Google services: \(configureError)")
        
        let date = Date()
        let tz = TimeZone.current
        if tz.isDaylightSavingTime(for: date) {
            
            UserDefaults.standard.set("2", forKey: "DST")
        }
        else {
            
            UserDefaults.standard.set("1", forKey: "DST")
        }
        
        
        application.applicationIconBadgeNumber = 0
        
        // Set QuickBlox credentials (You must create application in admin.quickblox.com).
        QBSettings.applicationID = kQBApplicationID
        QBSettings.authKey = kQBAuthKey
        QBSettings.authSecret = kQBAuthSecret
        QBSettings.accountKey = kQBAccountKey
        QBSettings.carbonsEnabled = true
        QBSettings.logLevel = .nothing
        QBSettings.enableXMPPLogging()
        QBSettings.autoReconnectEnabled = true
        
        IQKeyboardManager.sharedManager().enable = true
        SSASwiftReachability.sharedManager?.startMonitoring()
        
        
        UIApplication.shared.registerForRemoteNotifications()
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound, .badge]) { (granted, error) in
            print("Permission granted: \(granted)")
        }
        
        
        
//        http://demo.intorque.net/Heyoo/
//        http://projects.intorque.tech/Heyoo/
        UserDefaults.standard.set("http://heyoo.life/App/WebServices/", forKey: "baseURL")
        UserDefaults.standard.synchronize()
        
        
        if UserDefaults.standard.value(forKey: "socialUserID") as? String != nil
        {
//            ServicesManager.instance().chatService.connect(completionBlock: nil)
            let navigationController = window?.rootViewController as? UINavigationController
            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "TabBarSocial"), animated: false)
            
        }
        else
        {
            let navigationController = window?.rootViewController as? UINavigationController
            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//            navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "LoginSelectionVC"), animated: false)
            navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "SocialLoginVC"), animated: false)
        }
    
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        
    }
    
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool
    {
        return GIDSignIn.sharedInstance().handle(url, sourceApplication: sourceApplication, annotation: annotation)
    }
    
    @available(iOS 9.0, *)
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any]) -> Bool
    {
        let sourceApplication = options[UIApplicationOpenURLOptionsKey.sourceApplication] as? String
        let annotation = options[UIApplicationOpenURLOptionsKey.annotation]
        return GIDSignIn.sharedInstance().handle(url, sourceApplication: sourceApplication, annotation: annotation)
    }
    
    
    
    // ----------------------------------------------- //
    // ********** Push Notification Methods ********** //
    // ----------------------------------------------- //
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        
        print("didReceiveRemoteNotification userInfo=\(userInfo) completionHandler")
        if application.applicationState == UIApplicationState.inactive
        {
            self.postPushNotificationWithUserInfo(userInfo: userInfo)
            
            completionHandler(UIBackgroundFetchResult.noData)
        }
    }
    
    func postPushNotificationWithUserInfo(userInfo:Dictionary<AnyHashable, Any>) {
        
        print(userInfo)
        print(userInfo["aps"])
        print(userInfo["reDirectKey"])
        print(userInfo["dialogID"])
        
        if userInfo["type"] as! String == "chat"
        {
            if let eventID = userInfo["eventID"]
            {
                ServicesManager.instance().chatService.fetchDialog(withID: userInfo["dialogID"] as! String) { (dialog) in
                    
                    print(dialog)
                    
                    if dialog != nil
                    {
                        let navigationController = self.window?.rootViewController as? UINavigationController
                        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let eventDetail = storyboard.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                        eventDetail.dialog = dialog
                        eventDetail.strEventID = eventID as! String
                        navigationController?.pushViewController(eventDetail, animated: false)
                    }
                    else
                    {
                        getDialogs(userInfo: userInfo)
                    }
                }
            }
            else
            {
                ServicesManager.instance().chatService.fetchDialog(withID: userInfo["dialogID"] as! String) { (dialog) in
                    
                    print(dialog)
                    
                    if dialog != nil
                    {
                        let navigationController = self.window?.rootViewController as? UINavigationController
                        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let chatVC = storyboard.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
                        chatVC.dialog = dialog
                        navigationController?.pushViewController(chatVC, animated: false)
                    }
                    else
                    {
                        getDialogs(userInfo: userInfo)
                    }
                }
            }
        }
        else if userInfo["type"] as! String == "Event"
        {
            if let eventID = userInfo["eventID"]
            {
                ServicesManager.instance().chatService.fetchDialog(withID: userInfo["dialogID"] as! String) { (dialog) in
                    
                    print(dialog)
                    
                    if dialog != nil
                    {
                        let navigationController = self.window?.rootViewController as? UINavigationController
                        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let eventDetail = storyboard.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                        eventDetail.dialog = dialog
                        eventDetail.strEventID = eventID as! String
                        navigationController?.pushViewController(eventDetail, animated: false)
                    }
                    else
                    {
                        getDialogs(userInfo: userInfo)
                    }
                }
            }
        }
        else
        {
//            let navigationController = self.window?.rootViewController as? UINavigationController
//            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//            let notoificationVC = storyboard.instantiateViewController(withIdentifier: "SocialNotificationVC") as! SocialNotificationVC
//            navigationController?.pushViewController(notoificationVC, animated: false)
        }
        
        func getDialogs(userInfo:Dictionary<AnyHashable, Any>) {
            
            ServicesManager.instance().chatService.allDialogs(withPageLimit: kDialogsPageLimit, extendedRequest: nil, iterationBlock: { (response: QBResponse?, dialogObjects: [QBChatDialog]?, dialogsUsersIDS: Set<NSNumber>?, stop: UnsafeMutablePointer<ObjCBool>) -> Void in
                
            }, completion: { (response: QBResponse?) -> Void in
                
                guard response != nil && response!.isSuccess else {
                    
                    return
                }
                
                if let eventID = userInfo["eventID"]
                {
                    ServicesManager.instance().chatService.fetchDialog(withID: userInfo["dialogID"] as! String) { (dialog) in
                        
                        print(dialog)
                        
                        let navigationController = self.window?.rootViewController as? UINavigationController
                        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let eventDetail = storyboard.instantiateViewController(withIdentifier: "SocialEventDetailVC") as! SocialEventDetailVC
                        eventDetail.dialog = dialog
                        eventDetail.strEventID = eventID as! String
                        navigationController?.pushViewController(eventDetail, animated: false)
                    }
                }
                else
                {
                    ServicesManager.instance().chatService.fetchDialog(withID: userInfo["dialogID"] as! String) { (dialog) in
                        
                        print(dialog)
                        
                        let navigationController = self.window?.rootViewController as? UINavigationController
                        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let chatVC = storyboard.instantiateViewController(withIdentifier: "SocialChatVC") as! SocialChatVC
                        chatVC.dialog = dialog
                        navigationController?.pushViewController(chatVC, animated: false)
                        
                    }
                }
                
            })
            
        }
        
        
        
        
        
        
        
//        let message = userInfo[QBMPushMessageApsKey] as! String
//        print(message)
        
        
//        NSString *message = userInfo[QBMPushMessageApsKey][QBMPushMessageAlertKey];
//        NSMutableDictionary *pushInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:message, @"message", nil];
//
//        [[NSNotificationCenter defaultCenter] postNotificationName:@"kPushDidReceive" object:nil userInfo:pushInfo];
        
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let deviceIdentifier: String = UIDevice.current.identifierForVendor!.uuidString
        
        let subscription: QBMSubscription! = QBMSubscription()
        subscription.notificationChannel = QBMNotificationChannel.APNS
        subscription.deviceUDID = deviceIdentifier
        subscription.deviceToken = deviceToken
        print(deviceToken)
        
//        let deviceTokenString:String = deviceToken.base64EncodedString()
//        print(deviceTokenString)
        
        let   tokenString = deviceToken.reduce("", {$0 + String(format: "%02X",    $1)})
        print("deviceToken: \(tokenString)")
        
        UserDefaults.standard.set(tokenString, forKey: "deviceToken")
        UserDefaults.standard.set(deviceToken, forKey: "deviceTokenData")
        UserDefaults.standard.synchronize()
        
        QBRequest.createSubscription(subscription, successBlock: { (response: QBResponse!, objects: [QBMSubscription]?) -> Void in
            
            print("Successfull response!")
            
        }) { (response: QBResponse!) -> Void in
            print(response.error?.description)
        }
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
        print(error)
        
    }
    
    
    

}






































