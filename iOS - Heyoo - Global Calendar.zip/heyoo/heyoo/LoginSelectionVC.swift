//
//  LoginSelectionVC.swift
//  heyoo
//
//  Created by I N T O R Q U E on 02/10/17.
//  Copyright © 2017 I N T O R Q U E. All rights reserved.
//

import UIKit

class LoginSelectionVC: UIViewController {
    @IBOutlet var btnRegSocialNetwork: UIButton!
    @IBOutlet var btnRegVIPNetwork: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func ActionRegisterForSocialNetwork(_ sender: UIButton)
    {
        let socialLogin = self.storyboard?.instantiateViewController(withIdentifier: "SocialLoginVC") as! SocialLoginVC
        self.navigationController?.pushViewController(socialLogin, animated: true)
    }
    
    @IBAction func ActionRegisterForVIPNetwork(_ sender: UIButton)
    {
        let alertCntrl = UIAlertController(title: nil, message: "Coming soon.", preferredStyle: .alert)
        alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alertCntrl, animated: true, completion: nil)
        
    }
    
}




























