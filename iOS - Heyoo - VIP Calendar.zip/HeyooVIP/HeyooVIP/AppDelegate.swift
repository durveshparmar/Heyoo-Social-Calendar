//
//  AppDelegate.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 25/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
import UserNotifications

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, UIAlertViewDelegate {
    
    var window: UIWindow?
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        Thread.sleep(forTimeInterval: 3.0)
        
        let date = Date()
        let tz = TimeZone.current
        if tz.isDaylightSavingTime(for: date) {
            
            UserDefaults.standard.set("2", forKey: "DST")
        }
        else {
            
            UserDefaults.standard.set("1", forKey: "DST")
        }
        
        IQKeyboardManager.sharedManager().enable = true
        
        application.applicationIconBadgeNumber = 0
        
        UIApplication.shared.registerForRemoteNotifications()
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound, .badge]) { (granted, error) in
            print("Permission granted: \(granted)")
        }
        
        UserDefaults.standard.set("http://heyoo.life/VIPApp/WebServices/", forKey: "baseURL")
        UserDefaults.standard.synchronize()
        
        if UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String != nil
        {
            let navigationController = window?.rootViewController as? UINavigationController
            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "VIPSavedEventVC"), animated: false)
            
        }
        else if UserDefaults.standard.value(forKey: "celeUserID") as? String != nil
        {
            let navigationController = window?.rootViewController as? UINavigationController
            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "CeleHomeVC"), animated: false)
        }
        else
        {
//            if UserDefaults.standard.value(forKey: "VideoScreen") as? String != nil {
//                if UserDefaults.standard.value(forKey: "myProfile") as? String != nil {
//                    let navigationController = window?.rootViewController as? UINavigationController
//                    let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                    navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "VIPSelectionVC"), animated: false)
//                }else {
//                    let navigationController = window?.rootViewController as? UINavigationController
//                    let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                    navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "VIPSelectionVC"), animated: false)
//                }
//            }else {
//                let navigationController = window?.rootViewController as? UINavigationController
//                let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//                navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "VIPSelectionVC"), animated: false)
//            }
            let navigationController = window?.rootViewController as? UINavigationController
            let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "VIPSelectionVC"), animated: false)
        }
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        
    }

    func applicationWillTerminate(_ application: UIApplication) {
        
    }
    
    
    
    
    // ----------------------------------------------- //
    // ********** Push Notification Methods ********** //
    // ----------------------------------------------- //
    
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {

        if application.applicationState == UIApplicationState.inactive
        {
            self.postPushNotificationWithUserInfo(userInfo: userInfo)
            completionHandler(UIBackgroundFetchResult.noData)
        }else if application.applicationState == UIApplicationState.background
        {
            self.postPushNotificationWithUserInfo(userInfo: userInfo)
            completionHandler(UIBackgroundFetchResult.noData)
        }else if application.applicationState == UIApplicationState.active
        {
            let apsNotification = userInfo["aps"] as? NSDictionary
            let apsString       = apsNotification?["alert"] as? String
            
            let alert = UIAlertController(title: apsString, message: nil, preferredStyle: .actionSheet)
            let okAction = UIAlertAction(title: "OK", style: .default) { _ in
                self.postPushNotificationWithUserInfo(userInfo: userInfo)
                completionHandler(UIBackgroundFetchResult.noData)
            }
            alert.view.tintColor = UIColor(red: 172/255, green: 84/255, blue: 200/255, alpha: 1)
            let cancelAction = UIAlertAction(title: "Cancel", style: .default)
            
            alert.addAction(okAction)
            alert.addAction(cancelAction)
            
            var currentViewController = self.window?.rootViewController
            while currentViewController?.presentedViewController != nil {
                currentViewController = currentViewController?.presentedViewController
            }
            
            currentViewController?.present(alert, animated: true) {}
        }
    }
    

    
    func postPushNotificationWithUserInfo(userInfo:Dictionary<AnyHashable, Any>) {
        
        
        if userInfo["type"] as! String == "Event"
        {
            if let eventID = userInfo["eventID"]
            {
                let navigationController = self.window?.rootViewController as? UINavigationController
                let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                let eventDetail = storyboard.instantiateViewController(withIdentifier: "VIPCeleEventDetailVC") as! VIPCeleEventDetailVC
                eventDetail.strEventID = eventID as! String
                navigationController?.pushViewController(eventDetail, animated: false)
            }
        }
        else
        {
            
        }
    }
        
    
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
        let   tokenString = deviceToken.reduce("", {$0 + String(format: "%02X",    $1)})
        UserDefaults.standard.set(tokenString, forKey: "deviceToken")
        UserDefaults.standard.synchronize()
        
    }
    
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        
        UserDefaults.standard.set("sdjasdlfjkaslf;jkasf", forKey: "deviceToken")
        UserDefaults.standard.synchronize()
        
    }


}
































