//
//  VIPGlobalSearchTblCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 07/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class VIPGlobalSearchTblCell: UITableViewCell {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var imgViewVerifiy: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
