//
//  VIPCeleCalendarVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 07/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class VIPCeleCalendarVC: UIViewController, UITableViewDelegate, UITableViewDataSource, FSCalendarDelegateAppearance {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var viewCalendarMainBak: UIView!
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var btnFollow: UIButton!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var imgViewCalendarBackground: UIImageView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var dicUser = NSDictionary()
    var dicEventList = NSMutableDictionary()
    var arrEventListDateKey = NSMutableArray()
    var strSelectedDate = String()
    var strIsFollow = String()
    
    
    
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnHome.layer.cornerRadius = btnHome.frame.size.width / 2
        btnHome.setImage(#imageLiteral(resourceName: "IC_Home").withRenderingMode(.alwaysTemplate), for: .normal)
        btnHome.tintColor = UIColor.white
        
        btnFollow.layer.borderWidth = 1.0
        btnFollow.layer.borderColor = UIColor.white.cgColor
        
        calendar.appearance.eventDefaultColor = UIColor.red
        calendar.appearance.eventSelectionColor = UIColor.red
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.height/2
        
        viewCalendarMainBak.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalendarMainBak.layer.shadowOpacity = 0.4
        viewCalendarMainBak.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalendarMainBak.layer.shadowRadius = 3
        
        lblUserName.text = (dicUser["FullName"] as! String)
        imgViewProPic.sd_setImage(with: URL(string : dicUser["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        
        let calTemp = Calendar.current
        let year = calTemp.component(.year, from: calendar.currentPage)
        let month = calTemp.component(.month, from: calendar.currentPage)
        
//        getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
        self.GetUserProfileAndEventsDataFetchedAPICall()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        
        
    }
    
    
    // ********** All Button Actions ********** //
    @IBAction func ActionGoToHome(_ sender: UIButton) {
        
        for controller in self.navigationController!.viewControllers as Array {
            if controller.isKind(of: VIPSavedEventVC.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionCalPrev(_ sender: UIButton) {
        
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = -1
        }
        else
        {
            dateComponents.weekOfMonth = -1
        }
        
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    @IBAction func ActionCalNext(_ sender: UIButton) {
        
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = 1
        }
        else
        {
            dateComponents.weekOfMonth = 1
        }
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    @IBAction func ActionFollowUnFollow(_ sender: UIButton) {
        
//        if strIsFollow == "1" {
//
//            self.btnFollow.backgroundColor = UIColor.white
//            self.btnFollow.setTitle("Following", for: .normal)
//            self.btnFollow.setTitleColor(UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0), for: .normal)
//            strIsFollow = "2"
//        }
//        else {
//
//            self.btnFollow.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
//            self.btnFollow.setTitle("+ Follow", for: .normal)
//            self.btnFollow.setTitleColor(UIColor.white, for: .normal)
//            strIsFollow = "1"
//        }
        
        self.UserFollowUnfollowAPICall()
        
    }
    
    
    // ********** FSCalendar Deleagete Methods ********** //
    
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM yyyy"
        return formatter
    }()
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar)
    {
        //        lblCalenderHeader.text = self.dateFormatter.string(from: calendar.currentPage)
        strSelectedDate = ""
        
        let calTemp = Calendar.current
        let year = calTemp.component(.year, from: calendar.currentPage)
        let month = calTemp.component(.month, from: calendar.currentPage)
        let currentDate = Date()
        let curYear = calTemp.component(.year, from: currentDate)
        let curMonth = calTemp.component(.month, from: currentDate)
        getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
    }
    
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool)
    {
        self.calendarHeightConstraint.constant = bounds.height
        self.view.layoutIfNeeded()
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition)
    {
        let custCal = Calendar.current
        let weekOfYear = custCal.component(.weekOfYear, from: date)
        
        let dateString = self.dateFormatter2.string(from: date as Date)
        if arrEventListDateKey.contains(dateString)
        {
            strSelectedDate = "\(dateString)"
            tblView.reloadData()
        }
        else
        {
            let alertCntrl = UIAlertController(title: "Reminder:", message: "No events scheduled on this day.", preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in
                
                self.strSelectedDate = ""
                self.tblView.reloadData()
            }))
            self.present(alertCntrl, animated: true, completion: nil)
        }
    }
    
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillSelectionColorFor date: Date) -> UIColor?
    {
        return UIColor.orange.withAlphaComponent(0.3)
    }
    
    func calendar(_ calendar: FSCalendar!, appearance: FSCalendarAppearance!, titleDefaultColorFor date: Date!) -> UIColor!
    {
        let dateString = self.dateFormatter2.string(from: date as Date)
        if arrEventListDateKey.contains(dateString)
        {
            return UIColor.orange
        }
        return nil
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int
    {
        let dateString = self.dateFormatter2.string(from: date)
        if arrEventListDateKey.contains(dateString) {
            return 1
        }
        return 0
    }
    
    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    
    
    // ********** UITableview Delegate And DataSourece Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        if strSelectedDate != ""
        {
            return 1
        }
        else
        {
            return dicEventList.count
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            return arrEventSelectedDate.count
            
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[section]] as! NSArray
            return arrEventSectionWise.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : CeleHomeTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! CeleHomeTblCell
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        
        cell.viewColor.backgroundColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
        cell.lblEventName.text = dicPerticularEvent["EventTitle"] as? String
        
//        let inFormatter = DateFormatter()
//        inFormatter.dateFormat = "HH:mm:ss"
//        let outFormatter = DateFormatter()
//        outFormatter.dateFormat = "hh:mma"
//
//        let inTime = dicPerticularEvent["EventStartTime"] as! String
//        let date = inFormatter.date(from: inTime)!
//        let outTime = outFormatter.string(from: date)
//        cell.lblTime.text = outTime
        
        if dicPerticularEvent["EventAllDay"] as! String == "2" {
            
            cell.lblTime.text = "All Day"
        }
        else {
            
            let inFormatter = DateFormatter()
            inFormatter.dateFormat = "HH:mm:ss"
            let outFormatter = DateFormatter()
            outFormatter.dateFormat = "hh:mma"
            
            let inTime = dicPerticularEvent["EventStartTime"] as! String
            let date = inFormatter.date(from: inTime)!
            let outTime = outFormatter.string(from: date)
            cell.lblTime.text = outTime
        }
        
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
//        var dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPCeleEventDetailVC") as! VIPCeleEventDetailVC
        eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
        self.navigationController?.pushViewController(eventDetailVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 25
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView : CeleHomeHeaderCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! CeleHomeHeaderCell
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        var strTempDate = String()
        if strSelectedDate != ""
        {
            strTempDate = strSelectedDate
        }
        else
        {
            strTempDate = arrEventListDateKey[section] as! String
        }
        
//        let strTempDate = arrEventListDateKey[section] as! String
//        let dateConverted:Date = dateFormatter.date(from: strTempDate)!
        let date = dateFormatter.date(from: strTempDate)
        headerView.lblDateTitle.text = self.dateFormatterHeader.string(from: date!)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let viewFooter = UIView()
        viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
        viewFooter.backgroundColor = UIColor .white
        
        return viewFooter
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatterHeader: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    
    // ********** Get Month wise Events ********** //
    func getMonthWiseEventList(strMonth:String, strYear:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/DateWiseList"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = dicUser["UserID"] as! String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Val_Status":"2", "Val_Year":strYear, "Val_Month":strMonth, "Action":"GetMonthWise"]
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            for (key,value) in parameters {
                multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
            }
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    let dicLoginResponse = response.result.value as? [String: Any]
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary
                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicData.mutableCopy() as! NSMutableDictionary
                        
                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }
                        
                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)
                            
                        }
                        
                        if self.arrEventListDateKey.count == 0
                        {
                            //                            self.lblEventAvailOrNot.isHidden = false
                        }
                        else
                        {
                            //                            self.lblEventAvailOrNot.isHidden = true
                        }
                        
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    func GetUserProfileAndEventsDataFetchedAPICall() {

        MBProgressHUD.showAdded(to: self.view, animated: true)

        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Fetch"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = dicUser["UserID"] as! String
        let strFollowerID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Val_Memberid":strFollowerID, "Action":"SingleUserWithEvents"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    let dicLoginResponse = response.result.value as? [String: Any]
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary
                        let dicMiscData = dicData["MiscData"] as! NSDictionary
                        if dicMiscData["CalendarBGFlag"] as! String == "2" {
                            self.imgViewCalendarBackground.sd_setImage(with: URL(string : "\(dicMiscData["CalendarBGBaseURL"] as! String)\(dicMiscData["CalendarBGImage"] as! String)"), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                        }
                        let dicUserData = dicData["UserData"] as! NSDictionary
                        self.strIsFollow = dicUserData["Following"] as! String
                        
                        if dicUserData["Following"] as! String == "1" {
                            
                            self.btnFollow.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
                            self.btnFollow.setTitle("+ Follow", for: .normal)
                            self.btnFollow.setTitleColor(UIColor.white, for: .normal)
                        }
                        else {
                            
                            self.btnFollow.backgroundColor = UIColor.white
                            self.btnFollow.setTitle("Following", for: .normal)
                            self.btnFollow.setTitleColor(UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0), for: .normal)
                        }
                        
                        
                        
                        let dicEventData = dicData["EventsData"] as! NSDictionary
                        
                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicEventData.mutableCopy() as! NSMutableDictionary

                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"

                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }
                        
                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)
                        }

                        if self.arrEventListDateKey.count == 0
                        {
                            //                            self.lblEventAvailOrNot.isHidden = false
                        }
                        else
                        {
                            //                            self.lblEventAvailOrNot.isHidden = true
                        }

                        self.tblView.reloadData()
                        self.calendar.reloadData()

                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                    }
                })

            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    func UserFollowUnfollowAPICall() {
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = dicUser["UserID"] as! String
        let strFollowerID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        
        var strAction = String()
        if self.strIsFollow == "1" {
            
            strAction = "Follow"
        }
        else {
            
            strAction = "Unfollow"
        }
        
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Val_Memberid":strFollowerID, "Action":strAction]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        if self.strIsFollow == "1" {
                            self.btnFollow.backgroundColor = UIColor.white
                            self.btnFollow.setTitle("Following", for: .normal)
                            self.btnFollow.setTitleColor(UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0), for: .normal)
                            self.strIsFollow = "2"
                        }
                        else {
                            
                            self.btnFollow.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
                            self.btnFollow.setTitle("+ Follow", for: .normal)
                            self.btnFollow.setTitleColor(UIColor.white, for: .normal)
                            self.strIsFollow = "1"
                        }
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                    }
                    else
                    {
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    
    
    
    
}












































