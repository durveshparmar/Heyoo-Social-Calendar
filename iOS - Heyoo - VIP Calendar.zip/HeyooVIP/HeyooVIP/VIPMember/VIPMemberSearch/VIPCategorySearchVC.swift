//
//  VIPCategorySearchVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 07/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class VIPCategorySearchVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    @IBOutlet weak var viewSearchBack: UIView!
    @IBOutlet weak var lblNavTitle: UILabel!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var strNavTitle = String()
    var strCategoryIndex = String()
    var arrSearchUserList = NSArray()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnHome.layer.cornerRadius = btnHome.frame.size.width / 2
        btnHome.setImage(#imageLiteral(resourceName: "IC_Home").withRenderingMode(.alwaysTemplate), for: .normal)
        btnHome.tintColor = UIColor.white
        
        lblNavTitle.text = strNavTitle
        txtSearch.placeholder = "Search \(strNavTitle)..."
        
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        categoryWiserAutoCompleteSearchAPICall()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionClearSearch(_ sender: UIButton) {
        
        txtSearch.text = ""
        categoryWiserAutoCompleteSearchAPICall()
    }
    
    @IBAction func ActionGoToHome(_ sender: UIButton) {
        
        for controller in self.navigationController!.viewControllers as Array {
            if controller.isKind(of: VIPSavedEventVC.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrSearchUserList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cellID") as! VIPGlobalSearchTblCell
        let dicUser = arrSearchUserList[indexPath.row] as! NSDictionary
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
        cell.imgViewProPic.sd_setImage(with: URL(string : dicUser["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        cell.lblUserName.text = (dicUser["FullName"] as! String)
        if dicUser["VerifiedStatus"] as! String == "1" {
            cell.imgViewVerifiy.isHidden = true
        }
        else {
            cell.imgViewVerifiy.isHidden = false
        }
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.setEditing(true, animated: true)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let CalVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPCeleCalendarVC") as! VIPCeleCalendarVC
        CalVC.dicUser = arrSearchUserList[indexPath.row] as! NSDictionary
        self.navigationController?.pushViewController(CalVC, animated: true)
    }
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        categoryWiserAutoCompleteSearchAPICall()
    }
    
    
    // ********** Global AutoComplete API Call *********** //
    
    func categoryWiserAutoCompleteSearchAPICall()
    {
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Search"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_User":"\(txtSearch.text ?? "")", "Val_Start":"0", "Action":"GetCategoryUsers", "Val_Memberid":strUserID, "Val_Category":strCategoryIndex]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicGlobalSearchResponse = response.result.value as? [String: Any]
                    
                    if dicGlobalSearchResponse?["status"] as? String == "success"
                    {
                        self.arrSearchUserList = dicGlobalSearchResponse!["data"] as! NSArray
                        self.tblView.reloadData()
                    }
                    else if dicGlobalSearchResponse?["status"] as? String == "error"
                    {
                        self.arrSearchUserList = NSArray()
                        self.tblView.reloadData()
                    }
                    else
                    {
                        self.arrSearchUserList = NSArray()
                        self.tblView.reloadData()
                    }
                })
                
            case .failure(let encodingError):
                print(encodingError)
            }
        }
    }
    
    
    
}







































