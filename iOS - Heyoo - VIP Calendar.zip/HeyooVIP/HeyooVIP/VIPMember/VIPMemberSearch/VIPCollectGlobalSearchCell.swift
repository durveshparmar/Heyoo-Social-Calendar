//
//  VIPCollectGlobalSearchCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 07/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class VIPCollectGlobalSearchCell: UICollectionViewCell {
    @IBOutlet weak var lblCategoryName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        lblCategoryName.layer.borderWidth = 1.0
        lblCategoryName.layer.borderColor = UIColor.black.cgColor
    }
    
}
