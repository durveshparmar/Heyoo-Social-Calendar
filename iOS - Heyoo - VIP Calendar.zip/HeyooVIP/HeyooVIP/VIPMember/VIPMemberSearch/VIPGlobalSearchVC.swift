//
//  VIPGlobalSearchVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 07/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class VIPGlobalSearchVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    @IBOutlet weak var collectView: UICollectionView!
    @IBOutlet weak var viewNavBack: UIView!
    @IBOutlet weak var viewCategorySelectBack: UIView!
    @IBOutlet weak var txtGlobalSearch: UITextField!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var arrCategory = NSArray()
    var arrSearchUserList = NSArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewNavBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewNavBack.layer.shadowOpacity = 0.4
        viewNavBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewNavBack.layer.shadowRadius = 3
        
        viewCategorySelectBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewCategorySelectBack.layer.shadowOpacity = 0.4
        viewCategorySelectBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCategorySelectBack.layer.shadowRadius = 3
        
        arrCategory = ["Actor","Musician","Pro Athlete","Comedian","Model","Influencer","Organization","Other"] as NSArray
        
        txtGlobalSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionCearSearch(_ sender: UIBarButtonItem) {
        
        txtGlobalSearch.text = ""
        arrSearchUserList = NSArray()
        tblView.reloadData()
    }
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrCategory.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellCategory : VIPCollectGlobalSearchCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellID", for: indexPath) as! VIPCollectGlobalSearchCell
        
        cellCategory.lblCategoryName.text = "\(arrCategory[indexPath.item])"
        
        return cellCategory
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: 90, height: collectView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let cateSearch = self.storyboard?.instantiateViewController(withIdentifier: "VIPCategorySearchVC") as! VIPCategorySearchVC
        cateSearch.strNavTitle = arrCategory[indexPath.item] as! String
        cateSearch.strCategoryIndex = "\(indexPath.item + 1)"
        self.navigationController?.pushViewController(cateSearch, animated: true)
    }
    
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrSearchUserList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cellID") as! VIPGlobalSearchTblCell
        let dicUser = arrSearchUserList[indexPath.row] as! NSDictionary
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
        cell.imgViewProPic.sd_setImage(with: URL(string : dicUser["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        cell.lblUserName.text = (dicUser["FullName"] as! String)
        if dicUser["VerifiedStatus"] as! String == "1" {
            cell.imgViewVerifiy.isHidden = true
        }
        else {
            cell.imgViewVerifiy.isHidden = false
        }
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.setEditing(true, animated: true)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let CalVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPCeleCalendarVC") as! VIPCeleCalendarVC
        CalVC.dicUser = arrSearchUserList[indexPath.row] as! NSDictionary
        self.navigationController?.pushViewController(CalVC, animated: true)
    }
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        GlobalUserAutoCompleteSearchAPICall()
    }
    
    
    // ********** Global AutoComplete API Call *********** //
    
    func GlobalUserAutoCompleteSearchAPICall()
    {
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Search"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        print("my timezone : \(strTimezone)")
        let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        print("my DST : \(strDST)")
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_User":"\(txtGlobalSearch.text ?? "")", "Val_Start":"0", "Action":"GetAllUsers", "Val_Memberid":strUserID]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    let dicGlobalSearchResponse = response.result.value as? [String: Any]
                    if dicGlobalSearchResponse?["status"] as? String == "success"
                    {
                        self.arrSearchUserList = dicGlobalSearchResponse!["data"] as! NSArray
                        print(self.arrSearchUserList)
                        self.tblView.reloadData()
                    }
                    else if dicGlobalSearchResponse?["status"] as? String == "error"
                    {
                        self.arrSearchUserList = NSArray()
                        self.tblView.reloadData()
                    }
                    else
                    {
                        self.arrSearchUserList = NSArray()
                        self.tblView.reloadData()
                    }
                })
                
            case .failure(let encodingError):
                print(encodingError)
            }
        }
    }
    
    

}













































