//
//  VIPSettingVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 03/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class VIPSettingVC: UIViewController, editVIPMemberProfileProtocol, followersCountProtocol {
    
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblFollowingCount: UILabel!
    @IBOutlet weak var lblPastEventCount: UILabel!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var dicUserData = NSDictionary()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if dicUserData != nil {
            imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
            lblFollowingCount.text = (dicUserData["FollowingCount"] as! String)
            lblPastEventCount.text = (dicUserData["PreviousEventsCount"] as! String)
            
            let strProfilePic = dicUserData["ProfileImage"] as! String
            if strProfilePic == "" {
                
                self.profileNameImaageGenerater(strFName: dicUserData["FirstName"] as! String, strLName: dicUserData["LastName"] as! String)
            }
            else {
                
                self.imgViewProPic.sd_setImage(with: URL(string : strProfilePic), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            }
        }else {
            imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        }
        
        
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionEditProfile(_ sender: UIButton) {
        
        let editPro = self.storyboard?.instantiateViewController(withIdentifier: "VIPEditProfileVC") as! VIPEditProfileVC
        editPro.dicUserData = dicUserData
        editPro.delegate = self
        self.navigationController?.pushViewController(editPro, animated: true)
    }
    
    @IBAction func ActionPreviousEvents(_ sender: UIButton) {
        
        let prevEvent = self.storyboard?.instantiateViewController(withIdentifier: "VIPPastEventVC") as! VIPPastEventVC
        self.navigationController?.pushViewController(prevEvent, animated: true)
    }
    
    @IBAction func ActionLogout(_ sender: UIButton) {
        
        self.logoutAPICall()
    }
    
    @IBAction func Tremsofuse_Click(_ sender: UIButton) {
        if let url = URL(string: "http://heyoo.life/terms-of-use.html") {
            if #available(iOS 10, *){
                UIApplication.shared.open(url)
            }else{
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    @IBAction func Policy_Click(_ sender: UIButton) {
        if let url = URL(string: "https://www.iubenda.com/privacy-policy/35888035") {
            if #available(iOS 10, *){
                UIApplication.shared.open(url)
            }else{
                UIApplication.shared.openURL(url)
            }
            
        }
    }
    
    
    
    
    func profileNameImaageGenerater(strFName:String, strLName:String)
    {
        let lblNameInitialize = UILabel()
        lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
        lblNameInitialize.textColor = UIColor.white
        lblNameInitialize.font = UIFont.systemFont(ofSize: 30.0)
        
        lblNameInitialize.text = String(strFName.characters.first!) + String(strLName.characters.first!)
        lblNameInitialize.textAlignment = NSTextAlignment.center
        lblNameInitialize.backgroundColor = UIColor.gray
        
        UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
        lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
        self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    
    // ********** LogOut API Call ********** //
    
    func logoutAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Authentication/SignOut"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Action":"UserSignOut"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            UserDefaults.standard.set(nil, forKey: "VIPMemberUserID")
                            UserDefaults.standard.synchronize()
                            self.navigationController?.popToRootViewController(animated: true)
                            
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    func setChangedProfilePic(strProfilePic: String) {
        
        self.imgViewProPic.sd_setImage(with: URL(string : strProfilePic), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
    }
    
    func setFollowCount(strFollowCount: String) {
        
        lblFollowingCount.text = strFollowCount
    }
    
    
}










































