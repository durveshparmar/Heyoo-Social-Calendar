//
//  VIPPastEventVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 17/03/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class VIPPastEventVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var dicEventList = NSMutableDictionary()
    var arrEventListDateKey = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnHome.layer.cornerRadius = btnHome.frame.size.width / 2
        btnHome.setImage(#imageLiteral(resourceName: "IC_Home").withRenderingMode(.alwaysTemplate), for: .normal)
        btnHome.tintColor = UIColor.white
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.getPastEventAPICall()
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func ActionGoToHome(_ sender: UIButton) {
        
        for controller in self.navigationController!.viewControllers as Array {
            if controller.isKind(of: VIPSavedEventVC.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    
    
    // ********** UITableview Delegate And DataSourece Methods ********** //
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return dicEventList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        let arrEventSectionWise = dicEventList[arrEventListDateKey[section]] as! NSArray
        return arrEventSectionWise.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : CeleHomeTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! CeleHomeTblCell
        
        let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
        let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        cell.viewColor.backgroundColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
        cell.lblEventName.text = dicPerticularEvent["EventTitle"] as? String
        
        if dicPerticularEvent["EventAllDay"] as! String == "2" {
            
            cell.lblTime.text = "All Day"
        }
        else {
            
            let inFormatter = DateFormatter()
            inFormatter.dateFormat = "HH:mm:ss"
            let outFormatter = DateFormatter()
            outFormatter.dateFormat = "hh:mma"
            
            let inTime = dicPerticularEvent["EventStartTime"] as! String
            let date = inFormatter.date(from: inTime)!
            let outTime = outFormatter.string(from: date)
            cell.lblTime.text = outTime
        }
        
        cell.setEditing(true, animated: true)
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
        let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary

        let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPCeleEventDetailVC") as! VIPCeleEventDetailVC
        eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
        eventDetailVC.strCheckScreen = "saved"
        self.navigationController?.pushViewController(eventDetailVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 25
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView : CeleHomeHeaderCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! CeleHomeHeaderCell
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"

        let strTempDate = arrEventListDateKey[section] as! String
        
        let date = dateFormatter.date(from: strTempDate)
        headerView.lblDateTitle.text = self.dateFormatterHeader.string(from: date!)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        let viewFooter = UIView()
        viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
        viewFooter.backgroundColor = UIColor .white
        
        return viewFooter
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
        let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        self.unsaveEventAPICall(strEventID: dicPerticularEvent["EventID"] as! String)
        
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatterHeader: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    
    // ********** Dateboard API CAll ********** //
    
    func getPastEventAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/DateWiseList"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Val_Status":"2", "Action":"GetPastEvents"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            let dicEventListTemp = dicDashResponse?["data"] as! NSDictionary
                            self.dicEventList = NSMutableDictionary()
                            self.dicEventList = dicEventListTemp.mutableCopy() as! NSMutableDictionary
                            
                            let testArray = self.dicEventList.allKeys as NSArray
                            var convertedArray: [Date] = []
                            
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "yyyy-MM-dd"
                            
                            for dat in testArray {
                                let strDate = dat as! String
                                let date = dateFormatter.date(from: strDate)
                                if let date = date {
                                    convertedArray.append(date)
                                }
                            }
                            
                            self.arrEventListDateKey = NSMutableArray()
                            let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedDescending })
                            for dateArr in ready
                            {
                                let strFinalDate = dateFormatter.string(from: dateArr)
                                self.arrEventListDateKey.add(strFinalDate)
                                
                            }
                            
                            self.tblView.reloadData()
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            //                            self.calendar.reloadData()
                            
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            //                            self.calendar.reloadData()
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    func unsaveEventAPICall(strEventID:String) {
        
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Val_Eventid":strEventID, "Action":"Remove"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            self.getPastEventAPICall()
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    

    
    
}













































