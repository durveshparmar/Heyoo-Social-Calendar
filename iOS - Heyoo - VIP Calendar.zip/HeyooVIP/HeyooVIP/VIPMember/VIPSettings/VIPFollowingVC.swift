//
//  VIPFollowingVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 15/03/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

protocol followersCountProtocol {
    func setFollowCount(strFollowCount : String)
}

class VIPFollowingVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    var delegate:followersCountProtocol?
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var arrFollowingList = NSArray()
    var arrFolloOrNotTemp = NSMutableArray()
    var searchActive : Bool = false
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.getFollowingListAPICall()
    }
    
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        var count:Int = 0
        
        for i in (0..<arrFolloOrNotTemp.count)
        {
            if arrFolloOrNotTemp[i] as! String == "2"
            {
                count = count + 1
            }
        }
        
        delegate?.setFollowCount(strFollowCount: "\(count)")
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionFinishSearch(_ sender: UIButton) {
        
        txtSearch.text = ""
//        filtered = NSArray()
        txtSearch.resignFirstResponder()
        tblView.reloadData()
    }
    
    // ********** UITextField Delegate Methods ********** //
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        searchActive = true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        searchActive = true
    }
    
    @objc func textFieldDidChange(textField: UITextField)
    {
//        filtered = arrContactListServer.filter({ (text) -> Bool in
//            let dicContact = text as! NSDictionary
//            let tmp: NSString = dicContact["FullName"] as! NSString
//            let search = textField.text!
//            let rang = tmp.range(of: search, options: .caseInsensitive)
//            return rang.location != NSNotFound
//        }) as! [NSDictionary] as NSArray
//
//        if filtered.count == 0
//        {
//            searchActive = false
//        }
//        else
//        {
//            searchActive = true
//        }
//        tblView.reloadData()
        
        followingUserAutoCompleteSearchAPICall()
    }
    
    
    // ********** UITableView Delegate And DataSource Methods ********** //
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrFollowingList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! VIPFollowingTblCell
        
        let dicFollowing = arrFollowingList[indexPath.row] as! NSDictionary
        
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.height / 2
        
        cell.imgViewProPic.sd_setImage(with: URL(string : dicFollowing["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        cell.lblName.text = "\(dicFollowing["FirstName"] as! String) \(dicFollowing["LastName"] as! String)"
        
        if arrFolloOrNotTemp[indexPath.row] as! String == "1" {
            
            cell.btnFollowing.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            cell.btnFollowing.setTitle("+ Follow", for: .normal)
            cell.btnFollowing.setTitleColor(UIColor.white, for: .normal)
            cell.btnFollowing.layer.borderWidth = 1.0
            cell.btnFollowing.layer.borderColor = UIColor.clear.cgColor
        }
        else {
            
            cell.btnFollowing.backgroundColor = UIColor.clear
            cell.btnFollowing.setTitle("Following", for: .normal)
            cell.btnFollowing.setTitleColor(UIColor.black, for: .normal)
            cell.btnFollowing.layer.borderWidth = 1.0
            cell.btnFollowing.layer.borderColor = UIColor.black.cgColor
        }
        
        if dicFollowing["VerifiedStatus"] as! String == "1" {
            
            cell.imgViewVerify.isHidden = true
        }
        else {
            
            cell.imgViewVerify.isHidden = false
        }
        
        cell.btnFollowing.tag = indexPath.row
        cell.btnFollowing.addTarget(self, action: #selector(ActionfollowUnfollow(sender:)), for: .touchUpInside)
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let CalVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPCeleCalendarVC") as! VIPCeleCalendarVC
        CalVC.dicUser = arrFollowingList[indexPath.row] as! NSDictionary
        self.navigationController?.pushViewController(CalVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 70
    }
    
    @objc func ActionfollowUnfollow(sender:UIButton) {
        let dicFollowing = arrFollowingList[sender.tag] as! NSDictionary
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = dicFollowing["UserID"] as! String
        let strFollowerID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        
        var strAction = String()
        if arrFolloOrNotTemp[sender.tag] as! String == "1" {
            
            strAction = "Follow"
        }
        else {
            
            strAction = "Unfollow"
        }
        
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Val_Memberid":strFollowerID, "Action":strAction]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        if self.arrFolloOrNotTemp[sender.tag] as! String == "1" {
                            
                            self.arrFolloOrNotTemp.replaceObject(at: sender.tag, with: "2")
                        }
                        else {
                            
                            self.arrFolloOrNotTemp.replaceObject(at: sender.tag, with: "1")
                        }
                        
                        self.tblView.reloadData()
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        
                    }
                    else
                    {
                        
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
        
    }
    
    
    // ********** Get Following List API CAll ********** //
    func getFollowingListAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Action":"GetAllFollowing"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            self.arrFollowingList = dicDashResponse!["data"] as! NSArray
                            
                            self.arrFolloOrNotTemp.removeAllObjects()
                            for _ in (0..<self.arrFollowingList.count)
                            {
                                self.arrFolloOrNotTemp.add("2")
                            }
                            
                            self.tblView.reloadData()
                            
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.tblView.reloadData()
                            
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    func followingUserAutoCompleteSearchAPICall() {
        
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
//            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Search"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Action":"SearchFollowing", "Val_User":txtSearch.text!, "Val_Start":"0"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            self.arrFollowingList = dicDashResponse!["data"] as! NSArray
                            
                            self.arrFolloOrNotTemp.removeAllObjects()
                            for _ in (0..<self.arrFollowingList.count)
                            {
                                self.arrFolloOrNotTemp.add("2")
                            }
                            
                            self.tblView.reloadData()
                            
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.arrFollowingList = NSArray()
                            self.arrFolloOrNotTemp.removeAllObjects()
                            self.tblView.reloadData()
                            
//                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
//                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else if dicDashResponse?["status"] as? String == "warning"
                        {
                           self.getFollowingListAPICall()
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }

}











































