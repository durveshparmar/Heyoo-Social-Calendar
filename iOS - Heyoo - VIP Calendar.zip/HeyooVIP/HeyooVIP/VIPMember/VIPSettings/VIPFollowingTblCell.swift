//
//  VIPFollowingTblCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 15/03/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class VIPFollowingTblCell: UITableViewCell {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnFollowing: UIButton!
    @IBOutlet weak var imgViewVerify: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
