
//
//  VIPSavedEventVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 03/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import UserNotifications

class VIPSavedEventVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var navItem: UINavigationItem!
    @IBOutlet weak var button_View: UIView!
    @IBOutlet weak var following_btn: UIButton!
    @IBOutlet weak var savedevents_btn: UIButton!
    @IBOutlet weak var search_text: UITextField!
    @IBOutlet weak var tblView1: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    
    
    var dicEventList = NSMutableDictionary()
    var arrEventListDateKey = NSMutableArray()
    var dicUserData = NSDictionary()
    var dicEventList1 = NSMutableDictionary()
    
    var settingBarButtonItem = UIBarButtonItem()
    var notificationBarButtonItem = UIBarButtonItem()
    var searchBarButtonItem = UIBarButtonItem()
    
    var lblNotificationBadge = UILabel()
    var arrFollowingList = NSArray()
    var dicFollowerList = NSMutableDictionary()
    var arrFolloOrNotTemp = NSMutableArray()
    var searchActive : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        imgViewProPic.layer.borderWidth = 2
        imgViewProPic.layer.borderColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0).cgColor
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        settingBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconSettingWhite"), style: .plain, target: self, action: #selector(VIPSavedEventVC.ActionSettings(_:)))
        settingBarButtonItem.tintColor = UIColor.white
        
        searchBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconSearchWhite"), style: .plain, target: self, action: #selector(VIPSavedEventVC.ActionGlobalSearch(_:)))
        searchBarButtonItem.tintColor = UIColor.white
        
        lblNotificationBadge = UILabel(frame: CGRect(x: 10, y: -10, width: 18, height: 18))
        lblNotificationBadge.backgroundColor = UIColor.red
        lblNotificationBadge.layer.cornerRadius = lblNotificationBadge.bounds.size.height / 2
        lblNotificationBadge.textAlignment = .center
        lblNotificationBadge.layer.masksToBounds = true
        lblNotificationBadge.font = UIFont.systemFont(ofSize: 11)
        lblNotificationBadge.textColor = UIColor.white
        lblNotificationBadge.text = "00"
        
        // button
        let rightButton = UIButton(frame: CGRect(x: 0, y: 0, width: 18, height: 16))
        rightButton.setBackgroundImage(UIImage(named: "iconNotifWhite"), for: .normal)
        rightButton.addTarget(self, action: #selector(VIPSavedEventVC.ActionNotification(_:)), for: .touchUpInside)
        rightButton.addSubview(lblNotificationBadge)
        
        // Bar button item
        let notificationBarButtonItem = UIBarButtonItem(customView: rightButton)
        self.navItem.rightBarButtonItems = [settingBarButtonItem, notificationBarButtonItem, searchBarButtonItem]
        lblNotificationBadge.isHidden = true
        
        following_btn.isSelected = true
        savedevents_btn.isSelected = false
        tblView1.isHidden = false
        tblView.isHidden = true
        tblView.delegate = self
        tblView.dataSource = self
        tblView1.delegate = self
        tblView1.dataSource = self
        
        button_View.layer.shadowColor = UIColor.lightGray.cgColor
        button_View.layer.shadowOpacity = 0.4
        button_View.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        button_View.layer.shadowRadius = 5.0
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(VIPSavedEventVC.respondToSwipeGesture(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        swipeRight.numberOfTouchesRequired = 1
        self.view.isUserInteractionEnabled = true
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(VIPSavedEventVC.respondToSwipeGesture(gesture:)))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        swipeLeft.numberOfTouchesRequired = 1
        self.view.isUserInteractionEnabled = true
        self.view.addGestureRecognizer(swipeLeft)
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if tblView.isHidden == false {
            self.dashboardAPICall()
            self.tblView.reloadData()
        }else {
            self.getFollowingListAPICall()
            self.tblView1.reloadData()
        }
    }
    
    
    // ********** All Button Actions ********** //
    @objc func ActionSettings(_ sender: UIBarButtonItem) {
        
        let settingVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPSettingVC") as! VIPSettingVC
        settingVC.dicUserData = dicUserData
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
    
    @objc func ActionNotification(_ sender: UIBarButtonItem) {
        
        let notifVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPNotificationVC") as! VIPNotificationVC
        self.navigationController?.pushViewController(notifVC, animated: true)
    }
    
    @objc func ActionGlobalSearch(_ sender: UIBarButtonItem) {
        
        let globSearch = self.storyboard?.instantiateViewController(withIdentifier: "VIPGlobalSearchVC") as! VIPGlobalSearchVC
        self.navigationController?.pushViewController(globSearch, animated: true)
    }
    
    @IBAction func following_Click(_ sender: UIButton) {
        following_btn.isSelected = true
        savedevents_btn.isSelected = false
        tblView1.isHidden = false
        tblView.isHidden = true
        self.getFollowingListAPICall()
    }
    
    @IBAction func savedevents_Click(_ sender: UIButton) {
        following_btn.isSelected = false
        savedevents_btn.isSelected = true
        tblView1.isHidden = true
        tblView.isHidden = false
        self.dashboardAPICall()
    }
    
    @IBAction func searchcencel_Click(_ sender: UIButton) {
        
        if tblView.isHidden == false {
            txtSearch.text = ""
            tblView.reloadData()
            txtSearch.resignFirstResponder()
        }else {
            txtSearch.text = ""
            tblView1.reloadData()
            txtSearch.resignFirstResponder()
        }
        
    }
    
    
    //************* SwipGesture methods **************//
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                following_btn.isSelected = true
                savedevents_btn.isSelected = false
                tblView1.isHidden = false
                tblView.isHidden = true
                self.dashboardAPICall()
            case UISwipeGestureRecognizerDirection.left:
                following_btn.isSelected = false
                savedevents_btn.isSelected = true
                tblView1.isHidden = true
                tblView.isHidden = false
                self.getFollowingListAPICall()
            default:
                break
            }
        }
    }
    
    // ********** UITextField Delegate Methods ********** //
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        searchActive = true
    }

    func textFieldDidEndEditing(_ textField: UITextField)
    {
        searchActive = true
    }
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        if tblView.isHidden == false {
            EventAutoCompleteSearchAPICall()
        }else {
            followingUserAutoCompleteSearchAPICall()
        }
    }
    
    
    
    // ********** UITableview Delegate And DataSourece Methods ********** //
    func numberOfSections(in tableView: UITableView) -> Int {
        var count = Int()
        if tableView == self.tblView {
            count = dicEventList.count
        }else if tableView == self.tblView1 {
            count = 1
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = Int()
        if tableView == self.tblView {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[section]] as! NSArray
            count = arrEventSectionWise.count
        }else if tableView == self.tblView1{
            count = arrFollowingList.count
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var myCell = UITableViewCell()
        
        if tableView == self.tblView {
            let cell : CeleHomeTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! CeleHomeTblCell
            
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            print("my Save event:=  \(arrEventListDateKey)")
            let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            
            cell.viewColor.backgroundColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
            cell.lblEventName.text = dicPerticularEvent["EventTitle"] as? String
            cell.lblEventPersonName.text = dicPerticularEvent["EventCelebrityName"] as? String
          
            if dicPerticularEvent["EventAllDay"] as! String == "2" {
                
                cell.lblTime.text = "All Day"
            }
            else {
                
                let inFormatter = DateFormatter()
                inFormatter.dateFormat = "HH:mm:ss"
                let outFormatter = DateFormatter()
                outFormatter.dateFormat = "hh:mma"
                
                let inTime = dicPerticularEvent["EventStartTime"] as! String
                let date = inFormatter.date(from: inTime)!
                let outTime = outFormatter.string(from: date)
                cell.lblTime.text = outTime
            }
            
            cell.setEditing(true, animated: true)
            cell .selectionStyle = UITableViewCellSelectionStyle.none
            myCell = cell
        }else if tableView == self.tblView1 {
            let cell : VIPFollowingTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID1") as! VIPFollowingTblCell
            
            let dicFollowing = arrFollowingList[indexPath.row] as! NSDictionary
            
            cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.height / 2
            
            cell.imgViewProPic.sd_setImage(with: URL(string : dicFollowing["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            cell.lblName.text = "\(dicFollowing["FirstName"] as! String) \(dicFollowing["LastName"] as! String)"
            
            if arrFolloOrNotTemp[indexPath.row] as! String == "1" {
                
                cell.btnFollowing.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
                cell.btnFollowing.setTitle("+ Follow", for: .normal)
                cell.btnFollowing.setTitleColor(UIColor.white, for: .normal)
                cell.btnFollowing.layer.borderWidth = 1.0
                cell.btnFollowing.layer.borderColor = UIColor.clear.cgColor
            }
            else {
                
                cell.btnFollowing.backgroundColor = UIColor.clear
                cell.btnFollowing.setTitle("Following", for: .normal)
                cell.btnFollowing.setTitleColor(UIColor.black, for: .normal)
                cell.btnFollowing.layer.borderWidth = 1.0
                cell.btnFollowing.layer.borderColor = UIColor.black.cgColor
            }
            
            if dicFollowing["VerifiedStatus"] as! String == "1" {
                
                cell.imgViewVerify.isHidden = true
            }
            else {
                
                cell.imgViewVerify.isHidden = false
            }
            
            cell.btnFollowing.tag = indexPath.row
            cell.btnFollowing.addTarget(self, action: #selector(ActionfollowUnfollow(sender:)), for: .touchUpInside)
            
            cell.selectionStyle = .none
            myCell = cell
        }
        
        return myCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.tblView {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            
            let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPCeleEventDetailVC") as! VIPCeleEventDetailVC
            eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
            eventDetailVC.strCheckScreen = "saved"
            self.navigationController?.pushViewController(eventDetailVC, animated: true)
        }else if tableView == self.tblView1 {
            let CalVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPCeleCalendarVC") as! VIPCeleCalendarVC
            CalVC.dicUser = arrFollowingList[indexPath.row] as! NSDictionary
            self.navigationController?.pushViewController(CalVC, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var Height: CGFloat!
        if tableView == self.tblView {
            Height = 50
        }else if tableView == self.tblView1 {
            Height = 70
        }
        return Height
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        var Height: CGFloat!
        if tableView == self.tblView {
            Height = 25
        }else if tableView == self.tblView1 {
            Height = 0
        }
        return Height
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        var myView: UIView!
        if tableView == self.tblView {
            let headerView : CeleHomeHeaderCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! CeleHomeHeaderCell
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            
            
            let strTempDate = arrEventListDateKey[section] as! String
            
            let date = dateFormatter.date(from: strTempDate)
            headerView.lblDateTitle.text = self.dateFormatterHeader.string(from: date!)
            
            myView = headerView.contentView
        }else if tableView == self.tblView1 {
            let viewFooter = UIView()
            viewFooter.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
            viewFooter.backgroundColor = UIColor .clear
            
            myView = viewFooter
        }
        return myView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        var Height: CGFloat!
        if tableView == self.tblView {
            Height = 1
        }else if tableView == self.tblView1 {
            Height = 0
        }
        return Height
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        var myView: UIView!
        if tableView == self.tblView {
            let viewFooter = UIView()
            viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
            viewFooter.backgroundColor = UIColor .white
            
            myView = viewFooter
        }else if tableView == self.tblView1 {
            let viewFooter = UIView()
            viewFooter.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
            viewFooter.backgroundColor = UIColor .clear
            
            myView = viewFooter
        }
        return myView
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if tableView == self.tblView {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            self.unsaveEventAPICall(strEventID: dicPerticularEvent["EventID"] as! String)
        }else if tableView == self.tblView1 {
            
        }
    }
    
    @objc func ActionfollowUnfollow(sender:UIButton) {
        
        let dicFollowing = arrFollowingList[sender.tag] as! NSDictionary
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = dicFollowing["UserID"] as! String
        let strFollowerID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        
        var strAction = String()
        if arrFolloOrNotTemp[sender.tag] as! String == "1" {
            
            strAction = "Follow"
        }
        else {
            
            strAction = "Unfollow"
        }
        
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Val_Memberid":strFollowerID, "Action":strAction]
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        if self.arrFolloOrNotTemp[sender.tag] as! String == "1" {
                            
                            self.arrFolloOrNotTemp.replaceObject(at: sender.tag, with: "2")
                        }
                        else {
                            
                            self.arrFolloOrNotTemp.replaceObject(at: sender.tag, with: "1")
                        }
                        
                        self.tblView1.reloadData()
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        
                    }
                    else
                    {
                        
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
        
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatterHeader: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    
    
    // ********** Dateboard API CAll ********** //
    
    func dashboardAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Dashboard"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            let tokenString = UserDefaults.standard.value(forKey: "deviceToken") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Val_iOStoken":tokenString, "Action":"GetSavedData"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            let dicData = dicDashResponse?["data"] as! NSDictionary
                            print(dicData)
                            let dicUserData = dicData["UserData"] as! NSDictionary
                            if dicUserData["status"] as! String == "error"
                            {
                                let alertCntrl = UIAlertController(title: "Warning", message: "\(dicUserData["message"] as! String)", preferredStyle: .alert)
                                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in

                                    UserDefaults.standard.set(nil, forKey: "VIPMemberUserID")
                                    UserDefaults.standard.synchronize()
                                    
                                    let selectVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPSelectionVC") as! VIPSelectionVC
                                    self.navigationController?.pushViewController(selectVC, animated: false)

                                    self.navigationController?.popToRootViewController(animated: true)
                                }))
                                self.present(alertCntrl, animated: true, completion: nil)

                            }
                            else
                            {
                                self.dicUserData = dicData["UserData"] as! NSDictionary
                                
                                let strProfilePic = dicUserData["ProfileImage"] as! String
                                if strProfilePic == "" {
                                    
                                    self.profileNameImaageGenerater(strFName: dicUserData["FirstName"] as! String, strLName: dicUserData["LastName"] as! String)
                                }
                                else {

                                    self.imgViewProPic.sd_setImage(with: URL(string : strProfilePic), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                                }
                                let dicMiscData = dicData["MiscData"] as! NSDictionary
                                if dicMiscData["status"] as! String == "error"
                                {
                                    self.lblNotificationBadge.isHidden = true
                                }
                                else
                                {
                                    let unpubBadge:Int = dicMiscData["NotificationCount"] as! Int
                                    if unpubBadge == 0
                                    {
                                        self.lblNotificationBadge.isHidden = true
                                    }
                                    else
                                    {
                                        self.lblNotificationBadge.isHidden = false
                                        self.lblNotificationBadge.text = String(unpubBadge)
                                    }
                                }
                                
                                
                                
                                let dicEventListTemp = dicData["EventsData"] as! NSDictionary
                                self.dicEventList = NSMutableDictionary()
                                self.dicEventList = dicEventListTemp.mutableCopy() as! NSMutableDictionary
                                
                                let testArray = self.dicEventList.allKeys as NSArray
                                var convertedArray: [Date] = []
                                
                                let dateFormatter = DateFormatter()
                                dateFormatter.dateFormat = "yyyy-MM-dd"
                                
                                for dat in testArray {
                                    let strDate = dat as! String
                                    let date = dateFormatter.date(from: strDate)
                                    if let date = date {
                                        convertedArray.append(date)
                                    }
                                }
                                
                                self.arrEventListDateKey = NSMutableArray()
                                let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                                for dateArr in ready
                                {
                                    let strFinalDate = dateFormatter.string(from: dateArr)
                                    self.arrEventListDateKey.add(strFinalDate)
                                    print(self.arrEventListDateKey)
                                    
                                }
                                
                                self.tblView.reloadData()
//                                self.calendar.reloadData()
                                
                            }
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
//                            self.calendar.reloadData()

                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
//                            self.calendar.reloadData()
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    func unsaveEventAPICall(strEventID:String) {
        
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Val_Eventid":strEventID, "Action":"Remove"]
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            self.dashboardAPICall()
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** Get Following List API CAll ********** //
    func getFollowingListAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Dashboard"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            let tokenString = UserDefaults.standard.value(forKey: "deviceToken") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Val_iOStoken":tokenString, "Action":"GetFollowingData"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            let dicData = dicDashResponse?["data"] as! NSDictionary
                            
                            let dicUserData = dicData["UserData"] as! NSDictionary
                            if dicUserData["status"] as! String == "error"
                            {
                                let alertCntrl = UIAlertController(title: "Warning", message: "\(dicUserData["message"] as! String)", preferredStyle: .alert)
                                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in
                                    
                                    UserDefaults.standard.set(nil, forKey: "VIPMemberUserID")
                                    UserDefaults.standard.synchronize()
                                    
                                    let selectVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPSelectionVC") as! VIPSelectionVC
                                    self.navigationController?.pushViewController(selectVC, animated: false)
                                    
                                    self.navigationController?.popToRootViewController(animated: true)
                                }))
                                self.present(alertCntrl, animated: true, completion: nil)
                                
                            }
                            else
                            {
                                self.dicUserData = dicData["UserData"] as! NSDictionary
                                
                                let strProfilePic = dicUserData["ProfileImage"] as! String
                                if strProfilePic == "" {
                                    
                                    self.profileNameImaageGenerater(strFName: dicUserData["FirstName"] as! String, strLName: dicUserData["LastName"] as! String)
                                }
                                else {
                                    
                                    self.imgViewProPic.sd_setImage(with: URL(string : strProfilePic), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                                }
                                let dicMiscData = dicData["MiscData"] as! NSDictionary
                                if dicMiscData["status"] as! String == "error"
                                {
                                    self.lblNotificationBadge.isHidden = true
                                }
                                else
                                {
                                    let unpubBadge:Int = dicMiscData["NotificationCount"] as! Int
                                    if unpubBadge == 0
                                    {
                                        self.lblNotificationBadge.isHidden = true
                                    }
                                    else
                                    {
                                        self.lblNotificationBadge.isHidden = false
                                        self.lblNotificationBadge.text = String(unpubBadge)
                                    }
                                }
                                
                                self.arrFollowingList = dicData["FollowingData"] as! NSArray
                                self.arrFolloOrNotTemp.removeAllObjects()
                                for _ in (0..<self.arrFollowingList.count)
                                {
                                    self.arrFolloOrNotTemp.add("2")
                                }
                                
                                self.tblView1.reloadData()
                                
                            }
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    // ***************** Followersearch Api Call ******************** //
    
    func followingUserAutoCompleteSearchAPICall() {
        
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            //            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Search"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Action":"SearchFollowing", "Val_User":txtSearch.text!, "Val_Start":"0"]
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            let dicData = dicDashResponse?["data"] as! NSDictionary
                            self.arrFollowingList = dicData["FollowingData"] as! NSArray
                            self.arrFolloOrNotTemp.removeAllObjects()
                            for _ in (0..<self.arrFollowingList.count)
                            {
                                self.arrFolloOrNotTemp.add("2")
                            }
                            
                            self.tblView1.reloadData()
                            
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.arrFollowingList = NSArray()
                            self.arrFolloOrNotTemp.removeAllObjects()
                            self.tblView1.reloadData()
                            
                            //                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            //                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            //                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else if dicDashResponse?["status"] as? String == "warning"
                        {
                            self.getFollowingListAPICall()
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    // ************** SearchEvents Api Call *************** //
    func EventAutoCompleteSearchAPICall() {
        
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            //            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/DateWiseList"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Action":"SearchSavedEvents", "Val_Event":txtSearch.text!, "Val_Start":"0"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            let dicEventListTemp = dicDashResponse!["data"] as! NSDictionary
                            self.dicEventList = NSMutableDictionary()
                            self.dicEventList = dicEventListTemp.mutableCopy() as! NSMutableDictionary
                            
                            let testArray = self.dicEventList.allKeys as NSArray
                            var convertedArray: [Date] = []
                            
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "yyyy-MM-dd"
                            
                            for dat in testArray {
                                let strDate = dat as! String
                                let date = dateFormatter.date(from: strDate)
                                if let date = date {
                                    convertedArray.append(date)
                                }
                            }
                            
                            self.arrEventListDateKey = NSMutableArray()
                            let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                            for dateArr in ready
                            {
                                let strFinalDate = dateFormatter.string(from: dateArr)
                                self.arrEventListDateKey.add(strFinalDate)
                                
                            }
                            
                            self.tblView.reloadData()
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            
                            //                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            //                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            //                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else if dicDashResponse?["status"] as? String == "warning"
                        {
                            self.dashboardAPICall()
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    
    func profileNameImaageGenerater(strFName:String, strLName:String)
    {
        let lblNameInitialize = UILabel()
        lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
        lblNameInitialize.textColor = UIColor.white
        lblNameInitialize.font = UIFont.systemFont(ofSize: 30.0)
        
        lblNameInitialize.text = String(strFName.characters.first!) + String(strLName.characters.first!)
        lblNameInitialize.textAlignment = NSTextAlignment.center
        lblNameInitialize.backgroundColor = UIColor.gray
        
        UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
        lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
        self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    

}












































