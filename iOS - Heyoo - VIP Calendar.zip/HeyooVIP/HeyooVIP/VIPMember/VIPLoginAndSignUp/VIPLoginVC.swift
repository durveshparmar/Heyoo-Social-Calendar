//
//  VIPLoginVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 02/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class VIPLoginVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtCountryCode: UITextField!
    @IBOutlet weak var txtSearchBar: UISearchBar!
    @IBOutlet weak var viewLogin: UIView!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtMobileNumber: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var searchActive : Bool = false
    var filtered = NSArray()
    
    var viewPopup = UIView()
    var arrCountryCode = NSArray()
    var blurView = UIVisualEffectView()
    var strSelectCountryCode = NSString()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewLogin.layer.shadowColor = UIColor.lightGray.cgColor
        viewLogin.layer.shadowOpacity = 0.4
        viewLogin.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLogin.layer.shadowRadius = 3
        
        btnLogin.layer.shadowColor = UIColor.lightGray.cgColor
        btnLogin.layer.shadowOpacity = 0.4
        btnLogin.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnLogin.layer.shadowRadius = 5.0
        
        let swipeGestureInBackVC = UISwipeGestureRecognizer(target: self, action: #selector(swipeToBackPop))
        swipeGestureInBackVC.direction = .right
        self.view.addGestureRecognizer(swipeGestureInBackVC)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        strSelectCountryCode = "+1"
        
        self.getCountryCode()
    }
    
    @objc func swipeToBackPop()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionSelectCountryCode(_ sender: UIButton) {
        
        tblView.isHidden = false
        showAnimateCountry()
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        let effect = UIBlurEffect(style: UIBlurEffectStyle.light)
        blurView = UIVisualEffectView(effect: effect)
        blurView.frame = viewPopup.bounds
        blurView.alpha = 0.7
        viewPopup.addSubview(blurView)
        viewPopup.addSubview(tblView)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
        
        txtSearchBar.becomeFirstResponder()
    }
    
    @IBAction func Back_Click(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func ActionSignUp(_ sender: UIButton) {
        
        let regVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPRegisterVC") as! VIPRegisterVC
        self.navigationController?.pushViewController(regVC, animated: true)
    }
    
    @IBAction func ActionLogin(_ sender: UIButton) {
        
//        let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPOTPVC") as! VIPOTPVC
//        otpVC.strScreenCheck = "VIPLogin"
//        self.navigationController?.pushViewController(otpVC, animated: true)
        
        LoginWebServiceCall()
    }
    
    // ********** Call Login WibService Method ********** //
    
    func LoginWebServiceCall()
    {
        if txtMobileNumber.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Authentication/SignIn"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let tokenString = UserDefaults.standard.value(forKey: "deviceToken") as! String
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Countrycode":strSelectCountryCode as String, "Val_iOStoken":tokenString, "Val_Mobile":txtMobileNumber.text! as String, "Val_Type":"2", "Action":"UserSignIn"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append((value ).data(using: .utf8)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicLoginResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicLoginResponse?["status"] as? String == "success"
                        {
                            let dicData = dicLoginResponse?["data"] as! NSDictionary
                            let strUserID = dicData["UserID"] as! String
                            
                            let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPOTPVC") as! VIPOTPVC
                            otpVC.strScreenCheck = "VIPLogin"
                            otpVC.strUserID = strUserID
                            otpVC.strSelectCountryCode = self.strSelectCountryCode
                            otpVC.strPhoneNumber = self.txtMobileNumber.text! as NSString
                            otpVC.strOTP = dicData["OTP"] as! String
                            self.navigationController?.pushViewController(otpVC, animated: true)
                            
                        }
                        else if dicLoginResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    // ********* Tableview Delegate DataSource Methods ********* //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if searchActive
        {
            if filtered.count == 0
            {
                return arrCountryCode.count
            }
            else
            {
                return filtered.count
            }
        }
        else
        {
            return arrCountryCode.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        if searchActive
        {
            if filtered.count == 0
            {
                let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
            else
            {
                let dicCountry = filtered[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
        }
        else
        {
            let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
            cell.textLabel?.text = dicCountry["name"] as? String
            cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if searchActive
        {
            if filtered.count == 0
            {
                let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
            else
            {
                let dicSelectCountry = filtered[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
        }
        else
        {
            let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
            txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
            
            strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
        }
        
        txtSearchBar.text = nil
        txtSearchBar.resignFirstResponder()
        viewPopup.isHidden = true
        filtered = NSArray()
        tblView.reloadData()
    }
    
    // ********** UISearchbarDelegate Methods ********** //
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)
    {
        searchActive = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        filtered = arrCountryCode.filter({ (text) -> Bool in
            let dicCountry = text as! NSDictionary
            let tmp: NSString = dicCountry["name"] as! NSString
            let range = tmp.range(of: searchText, options: .caseInsensitive)
            return range.location != NSNotFound
        }) as! [NSDictionary] as NSArray
        
        if filtered.count == 0
        {
            searchActive = false
        }
        else
        {
            searchActive = true
        }
        tblView.reloadData()
    }
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == blurView
            {
                txtSearchBar.text = nil
                txtSearchBar.resignFirstResponder()
                viewPopup.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    func getCountryCode()
    {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json")
        {
            let jsonData = NSData(contentsOfFile: path)
            do
            {
                arrCountryCode = try JSONSerialization.jsonObject(with: jsonData! as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSArray
                
                tblView.reloadData()
                
            } catch {}
        }
    }
    
    func showAnimateCountry()
    {
        viewPopup.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        viewPopup.alpha = 0.0
        UIView.animate(withDuration: 0.25, animations: {
            self.viewPopup.alpha = 1.0
            self.viewPopup.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        })
    }
    


}










































