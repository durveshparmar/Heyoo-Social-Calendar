//
//  VIPMyProfileVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 02/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class VIPMyProfileVC: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate {
    @IBOutlet weak var viewDetailBack: UIView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    
    var strSelectCountryCode = NSString()
    var strEmailAddress = NSString()
    var strPhoneNumber = NSString()
    
    var dataPrpPic = NSData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewDetailBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewDetailBack.layer.shadowOpacity = 0.4
        viewDetailBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewDetailBack.layer.shadowRadius = 3
        
        btnNext.layer.shadowColor = UIColor.lightGray.cgColor
        btnNext.layer.shadowOpacity = 0.4
        btnNext.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnNext.layer.shadowRadius = 5.0
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        imgViewProPic.layer.borderWidth = 3.0
        imgViewProPic.layer.borderColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0) .cgColor
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionNext(_ sender: UIButton) {
        
//        let dashboard = self.storyboard?.instantiateViewController(withIdentifier: "VIPSavedEventVC") as! VIPSavedEventVC
//        self.navigationController?.pushViewController(dashboard, animated: true)
        
        self.registerWebServiceCall()
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == imgViewProPic
            {
                OpenImagePickerForProfilePicture()
            }
            else
            {
                return
            }
        }
    }
    
    func OpenImagePickerForProfilePicture()
    {
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (alert: UIAlertAction) in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                let imag = UIImagePickerController()
                imag.delegate = self
                imag.sourceType = UIImagePickerControllerSourceType.camera
                imag.allowsEditing = true
                self.present(imag, animated: true, completion: nil)
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Gallery", style: .default, handler: { (alert: UIAlertAction) in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary)
            {
                let imag = UIImagePickerController()
                imag.delegate = self
                imag.sourceType = UIImagePickerControllerSourceType.photoLibrary
                imag.allowsEditing = true
                self.present(imag, animated: true, completion: nil)
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Remove Photo", style: .default, handler: { (alert: UIAlertAction) in
            self.dataPrpPic = NSData()
            self.profileNameImaageGenerater()
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (alert: UIAlertAction) in
    
        }))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    // ********** UIImagePickerControllerDelegate Methods ********** //
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        imgViewProPic.image = info["UIImagePickerControllerEditedImage"] as? UIImage
        
        dataPrpPic = UIImageJPEGRepresentation(imgViewProPic.image!, 0.5)! as NSData
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    // ********** TextField Delegate Methods ********** //
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        if textField == txtFirstName || textField == txtLastName
        {
            if dataPrpPic.length == 0
            {
                let lblNameInitialize = UILabel()
                lblNameInitialize.frame.size = CGSize(width: 80.0, height: 80.0)
                lblNameInitialize.textColor = UIColor.black
                
                if txtFirstName.text?.count != 0 && txtLastName.text?.count == 0
                {
                    lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!)
                }
                else if txtLastName.text?.count != 0 && txtFirstName.text?.count == 0
                {
                    lblNameInitialize.text = String(self.txtLastName.text!.characters.first!)
                }
                else if txtFirstName.text?.count != 0 && txtLastName.text?.count != 0
                {
                    lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
                }
                else
                {
                    lblNameInitialize.text = String("heyoo")
                }
                
                lblNameInitialize.textAlignment = NSTextAlignment.center
                lblNameInitialize.backgroundColor = UIColor(red: 237/255, green: 237/255, blue: 237/255, alpha: 1)
                
                
                UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
                lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
                self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
            }
        }
    }
    
    
    func profileNameImaageGenerater()
    {
        let lblNameInitialize = UILabel()
        lblNameInitialize.frame.size = CGSize(width: 80.0, height: 80.0)
        lblNameInitialize.textColor = UIColor.black
        
        if txtFirstName.text?.count != 0 && txtLastName.text?.count == 0
        {
            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!)
        }
        else if txtLastName.text?.count != 0 && txtFirstName.text?.count == 0
        {
            lblNameInitialize.text = String(self.txtLastName.text!.characters.first!)
        }
        else if txtFirstName.text?.count != 0 && txtLastName.text?.count != 0
        {
            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
        }
        else
        {
            lblNameInitialize.text = String("heyoo")
        }
        lblNameInitialize.textAlignment = NSTextAlignment.center
        lblNameInitialize.backgroundColor = UIColor(red: 237/255, green: 237/255, blue: 237/255, alpha: 1)
        
        
        UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
        lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
        self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    
    func registerWebServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/SignUp"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let proPicData = UIImageJPEGRepresentation(imgViewProPic.image!, 0.5)! as NSData
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let tokenString = UserDefaults.standard.value(forKey: "deviceToken") as! String
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"UserSignUp", "Val_Type":"2", "Val_Firstname":txtFirstName.text!, "Val_Lastname":txtLastName.text!, "Val_Countrycode":strSelectCountryCode as String, "Val_Mobile":strPhoneNumber as String, "Val_Email":strEmailAddress as String, "Val_Country":"", "Val_State":"", "Val_City":"", "Val_ProfileImage":"", "Val_Categories":"", "Val_OTP":"", "Val_iOStoken":tokenString]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                if value.count == 0
                {
                    if key == "Val_ProfileImage"
                    {
                        multipartFormData.append(proPicData as Data, withName: "Val_ProfileImage", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                    }
                }
                else
                {
                    multipartFormData.append((value ).data(using: .utf8)!, withName: key)
                }
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
            
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicRegResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicRegResponse?["status"] as? String == "success"
                    {
                        let dicData = dicRegResponse?["data"] as! NSDictionary
                        
                        let strUserID = dicData["UserID"] as! String
                        UserDefaults.standard.set(strUserID, forKey: "VIPMemberUserID")
                        UserDefaults.standard.synchronize()
                        
                        let dashboard = self.storyboard?.instantiateViewController(withIdentifier: "VIPSavedEventVC") as! VIPSavedEventVC
                        self.navigationController?.pushViewController(dashboard, animated: true)
                        
                    }
                    else if dicRegResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicRegResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    
}









































