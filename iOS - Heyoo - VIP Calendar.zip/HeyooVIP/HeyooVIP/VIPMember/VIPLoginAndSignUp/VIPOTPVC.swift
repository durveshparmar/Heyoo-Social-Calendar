//
//  VIPOTPVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 02/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class VIPOTPVC: UIViewController, UITextFieldDelegate {

    var strSelectCountryCode = NSString()
    var strEmailAddress = NSString()
    var strPhoneNumber = NSString()
    var strScreenCheck = NSString()
    var strCeleLoginStatus = String()
    var dicCeleLoginResponse = NSDictionary()
    
    
    var strOTP = String()
    var strUserID = String()
    var strCalBGBaseURL = String()
    var strCalBGFlag = String()
    var strCalBFImage = String()
    var strCeleType = String()
    
    
    
    @IBOutlet weak var first: UITextField!
    @IBOutlet weak var second: UITextField!
    @IBOutlet weak var third: UITextField!
    @IBOutlet weak var fourth: UITextField!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        first.delegate = self
        second.delegate = self
        third.delegate = self
        fourth.delegate = self
        
        first.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        second.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        third.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        fourth.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
    }
    
    @objc func textFieldDidChange(textField: UITextField){
        
        //        let text = Int(textField.text?.characters.count)
        let text = textField.text
        let textCount:Int = (text?.characters.count)!
        
        
        if textCount >= 1 {
            switch textField{
            case first:
                second.becomeFirstResponder()
            case second:
                third.becomeFirstResponder()
            case third:
                fourth.becomeFirstResponder()
            case fourth:
                fourth.resignFirstResponder()
            default:
                break
            }
        }else{
            
            switch textField{
            case first:
                first.becomeFirstResponder()
            case second:
                first.becomeFirstResponder()
            case third:
                second.becomeFirstResponder()
            case fourth:
                third.becomeFirstResponder()
            default:
                break
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == first {
            
            first.text = ""
            second.text = ""
            third.text = ""
            fourth.text = ""
        }
        else{
            
            textField.text = ""
        }
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if first.text != "" && second.text != "" && third.text != "" && fourth.text != "" {
            
            let otpString = "\(first.text!)\(second.text!)\(third.text!)\(fourth.text!)"
            if otpString == strOTP
            {
                if strScreenCheck == "VIPLogin"
                {
                    UserDefaults.standard.set(strUserID, forKey: "VIPMemberUserID")
                    UserDefaults.standard.synchronize()
                    
                    let dashboard = self.storyboard?.instantiateViewController(withIdentifier: "VIPSavedEventVC") as! VIPSavedEventVC
                    self.navigationController?.pushViewController(dashboard, animated: true)
                }
                else if strScreenCheck == "VIPReg"
                {
                    let myProVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPMyProfileVC") as! VIPMyProfileVC
                    myProVC.strSelectCountryCode = strSelectCountryCode
                    myProVC.strEmailAddress = strEmailAddress
                    myProVC.strPhoneNumber = strPhoneNumber
                    self.navigationController?.pushViewController(myProVC, animated: true)
                }
                else if strScreenCheck == "celeReg"
                {
                    UserDefaults.standard.set(self.strUserID, forKey: "celeUserID1")
                    UserDefaults.standard.synchronize()
                    UserDefaults.standard.set(self.strOTP, forKey: "celeOTP")
                    UserDefaults.standard.synchronize()
                    UserDefaults.standard.set(strSelectCountryCode, forKey: "strSelectCountryCode")
                    UserDefaults.standard.synchronize()
                    UserDefaults.standard.set(strPhoneNumber, forKey: "strPhoneNumber")
                    UserDefaults.standard.synchronize()
                    UserDefaults.standard.set(strEmailAddress, forKey: "strEmailAddress")
                    UserDefaults.standard.synchronize()
                    let cateVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleCategoriesVC") as! CeleCategoriesVC
                    UserDefaults.standard.set("Unverified", forKey: "VideoScreen")
                    UserDefaults.standard.synchronize()
                    UserDefaults.standard.set("myProfile", forKey: "myProfile")
                    UserDefaults.standard.synchronize()
                    cateVC.strSelectCountryCode = strSelectCountryCode
                    cateVC.strEmailAddress = strEmailAddress
                    cateVC.strPhoneNumber = strPhoneNumber
                    cateVC.strOTP = strOTP
                    self.navigationController?.pushViewController(cateVC, animated: true)
                }
                else if strScreenCheck == "celeLogin"
                {
                    if strCalBGFlag == "1" {
                        
                        UserDefaults.standard.set(self.strUserID, forKey: "celeUserID")
                        UserDefaults.standard.synchronize()
                        
//                        let home = self.storyboard?.instantiateViewController(withIdentifier: "CeleHomeVC") as! CeleHomeVC
//                        self.navigationController?.pushViewController(home, animated: true)
                        
                        if self.strCeleLoginStatus == "1" {
                            let home = self.storyboard?.instantiateViewController(withIdentifier: "CeleHomeVC") as! CeleHomeVC
                            self.navigationController?.pushViewController(home, animated: true)
                        }
                        else {
                            
                            let successVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleSuccessLoginVC") as! CeleSuccessLoginVC
                            successVC.dicCeleLoginData = self.dicCeleLoginResponse
                            self.navigationController?.pushViewController(successVC, animated: true)
                            
                        }
                    }
                    else {
                        UserDefaults.standard.set(self.strUserID, forKey: "celeUserID")
                        UserDefaults.standard.set(self.strCeleType, forKey: "celeType")
                        UserDefaults.standard.synchronize()
                        
                        self.getDataFromUrl(url: URL(string: "\(strCalBGBaseURL)/\(strCalBFImage)")!, completion: { (data, response, error) in
                            DispatchQueue.main.async {
                                
                                let imageCalBack = UIImage(data: data!)!
                                
                                let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
                                let url = NSURL(fileURLWithPath: path)
                                if let pathComponent = url.appendingPathComponent("CalBack") {
                                    let filePath = pathComponent.path
                                    let fileManager = FileManager.default
                                    if fileManager.fileExists(atPath: filePath) {
                                        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                                        let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(self.strCalBFImage)")
                                        do {
                                            try UIImageJPEGRepresentation(imageCalBack, 1.0)!.write(to: fileURL)
                                        } catch {
                                        }
                                    }
                                    else {
                                        
                                        
                                        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                                        let folderURL = documentDirectoryURL.appendingPathComponent("CalBack")
                                        do {
                                            try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: false, attributes: nil)
                                            
                                            let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(self.strCalBFImage)")
                                            
                                            try UIImageJPEGRepresentation(imageCalBack, 1.0)!.write(to: fileURL)
                                            
                                        } catch {
                                        }
                                    }
                                }
                                else {
                                    
                                }
                                
                                if self.strCeleLoginStatus == "1" {
                                    
                                    let home = self.storyboard?.instantiateViewController(withIdentifier: "CeleHomeVC") as! CeleHomeVC
                                    self.navigationController?.pushViewController(home, animated: true)
                                }
                                else {
                                    
                                    let successVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleSuccessLoginVC") as! CeleSuccessLoginVC
                                    successVC.dicCeleLoginData = self.dicCeleLoginResponse
                                    self.navigationController?.pushViewController(successVC, animated: true)
                                }
                            }
                        })
                    }
                }
            }
            else
            {
                let alertCntrl = UIAlertController(title: "Warning", message: "Your PIN is invalid", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                    self.first.becomeFirstResponder()
                }))
                self.present(alertCntrl, animated: true, completion: nil)
            }
        }
    }
    
    
    // ********** Image URL Convert To Data ********** //
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    
    
    
    
    
    
    override func viewWillAppear(_ animated: Bool)
    {
        first.becomeFirstResponder()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionResendOPT(_ sender: UIButton)
    {
        first.becomeFirstResponder()
        self.resendOTPServiceCall()
    }
    
    // ********** Call Resend OTP WibService Method ********** //
    func resendOTPServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/ResendOTP"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let strMobileNumber = strPhoneNumber as String
        let parameters = ["Val_Countrycode":strSelectCountryCode as String, "Val_Mobile":strMobileNumber, "Action":"Send", "Val_Timezone":strTimezone, "Val_IsDST":strDST]
        print(parameters)
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append((value ).data(using: .utf8)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicResendOTPResponse = response.result.value as? [String: Any]
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicResendOTPResponse?["status"] as? String == "success"
                    {
                        let dicData = dicResendOTPResponse?["data"] as! NSDictionary
                        
                        self.strOTP = dicData["OTP"] as! String
                        
                    }
                    else if dicResendOTPResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicResendOTPResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    

}







































