//
//  VIPNotifTblCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 03/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class VIPNotifTblCell: UITableViewCell {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblNotificationHead: UILabel!
    @IBOutlet weak var lblNotificationDescrip: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgViewProPic.image = UIImage(named: "")
        lblNotificationHead.text = ""
        lblNotificationDescrip.text = ""
        lblDate.text = ""
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
