//
//  VIPNotificationVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 03/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class VIPNotificationVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var arrNotificationList = NSArray()
    var eventID = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.getAllNotificationListAPICall()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItemGroup) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    
    // ********** UITableView Delegate And Datasource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrNotificationList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cellID") as! VIPNotifTblCell
        
        let dicNotif = arrNotificationList[indexPath.row] as! NSDictionary
        cell.imgViewProPic.layer.cornerRadius = cell.imgViewProPic.frame.size.width/2
        
        cell.lblNotificationHead.text = (dicNotif["Title"] as! String)
        cell.lblNotificationDescrip.text = (dicNotif["Description"] as! String)
        cell.imgViewProPic.sd_setImage(with: URL(string : dicNotif["Image"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let strTempDate = dicNotif["Date"] as! String
        let date = dateFormatter.date(from: strTempDate)
        cell.lblDate.text = self.dateFormatterNotification.string(from: date!)
        eventID = dicNotif["RelationID"] as! String
        
        
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
        
        cell.selectionStyle = UITableViewCellSelectionStyle.none
        cell.setEditing(true, animated: true)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        //        return 70
        
        return UITableViewAutomaticDimension
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete {
            let dicNotif = arrNotificationList[indexPath.row] as! NSDictionary
            self.deleteNotificationAPICall(strNotifyID: dicNotif["NotifyID"] as! String)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let dicNotif = arrNotificationList[indexPath.row] as! NSDictionary
        let storyboard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let eventDetail = storyboard.instantiateViewController(withIdentifier: "VIPCeleEventDetailVC") as! VIPCeleEventDetailVC
        eventDetail.strEventID = dicNotif["RelationID"] as! String
        navigationController?.pushViewController(eventDetail, animated: false)
    }
    
    // ********** Notification Date Selector ********** //
    fileprivate lazy var dateFormatterNotification: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd"
        return formatter
    }()
    
    
    
    // ********** All Webservices call ********* //
    
    func getAllNotificationListAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Notification/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "VIPMemberUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Memberid":strUserID, "Action":"GetAllNotifications"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            self.arrNotificationList = dicDashResponse?["data"] as! NSArray
                            self.tblView.reloadData()
                            
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.arrNotificationList = NSArray()
                            self.tblView.reloadData()
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    func deleteNotificationAPICall(strNotifyID:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Notification/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Notifyid":strNotifyID, "Action":"Delete"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            if self.arrNotificationList.count == 1 {
                                self.getAllNotificationListAPICall()
                            }else {
                                self.getAllNotificationListAPICall()
                            }
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                            self.tblView.reloadData()
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
}











































