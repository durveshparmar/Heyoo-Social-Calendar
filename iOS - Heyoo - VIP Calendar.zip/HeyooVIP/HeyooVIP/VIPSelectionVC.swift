//
//  VIPSelectionVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 25/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class VIPSelectionVC: UIViewController {
    @IBOutlet weak var btnVIP: UIButton!
    @IBOutlet weak var btnVIPMember: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        print(TimeZone.current.secondsFromGMT())
        
        
        btnVIPMember.layer.shadowColor = UIColor.lightGray.cgColor
        btnVIPMember.layer.shadowOpacity = 0.4
        btnVIPMember.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnVIPMember.layer.shadowRadius = 5.0
        
        btnVIP.layer.shadowColor = UIColor.lightGray.cgColor
        btnVIP.layer.shadowOpacity = 0.4
        btnVIP.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnVIP.layer.shadowRadius = 5.0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionVIP(_ sender: UIButton) {
        if UserDefaults.standard.value(forKey: "VideoScreen") as? String != nil {
            if UserDefaults.standard.value(forKey: "myProfile") as? String != nil {
                let celeLogin = self.storyboard?.instantiateViewController(withIdentifier: "CeleCategoriesVC") as! CeleCategoriesVC
                self.navigationController?.pushViewController(celeLogin, animated: true)
            }else {
                let celeLogin = self.storyboard?.instantiateViewController(withIdentifier: "CeleVideoVarificationVC") as! CeleVideoVarificationVC
                self.navigationController?.pushViewController(celeLogin, animated: true)
            }
        }else {
            let celeLogin = self.storyboard?.instantiateViewController(withIdentifier: "CeleLoginVC") as! CeleLoginVC
            self.navigationController?.pushViewController(celeLogin, animated: true)
        }
    }
    
    @IBAction func ActionVIPMember(_ sender: UIButton) {
        
        
        let vipLogin = self.storyboard?.instantiateViewController(withIdentifier: "VIPLoginVC") as! VIPLoginVC
        self.navigationController?.pushViewController(vipLogin, animated: true)
    }
    
}







































