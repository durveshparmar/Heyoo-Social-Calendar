//
//  customColor.swift
//  heyoo
//
//  Created by Intorque LLP on 18/10/17.
//  Copyright © 2017 ISN Softech. All rights reserved.
//

import UIKit

class customColor: NSObject {
    
    open class var color1: UIColor
    {
        return UIColor(red: 244.0/255.0, green: 40.0/255.0, blue: 59.0/255.0, alpha: 1.0)
    }
    
    open class var color2: UIColor
    {
        return UIColor(red: 241.0/255.0, green: 49.0/255.0, blue: 130.0/255.0, alpha: 1.0)
    }
    
    open class var color3: UIColor
    {
        return UIColor(red: 50.0/255.0, green: 193.0/255.0, blue: 160.0/255.0, alpha: 1.0)
    }
    
    open class var color4: UIColor
    {
        return UIColor(red: 92.0/255.0, green: 225.0/255.0, blue: 114.0/255.0, alpha: 1.0)
    }
    
    open class var color5: UIColor
    {
        return UIColor(red: 76.0/255.0, green: 171.0/255.0, blue: 254.0/255.0, alpha: 1.0)
    }
    
    open class var color6: UIColor
    {
        return UIColor(red: 255.0/255.0, green: 107.0/255.0, blue: 61.0/255.0, alpha: 1.0)
    }
    
    open class var color7: UIColor
    {
        return UIColor(red: 12.0/255.0, green: 93.0/255.0, blue: 142.0/255.0, alpha: 1.0)
    }
}










