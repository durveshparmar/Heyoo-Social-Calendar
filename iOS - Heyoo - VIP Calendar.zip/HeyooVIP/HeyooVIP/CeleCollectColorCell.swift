//
//  CeleCollectColorCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 01/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class CeleCollectColorCell: UICollectionViewCell {
    @IBOutlet weak var viewColor: UIView!
    @IBOutlet weak var imgViewTick: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewColor.layer.cornerRadius = viewColor.frame.size.width/2
    }
}
