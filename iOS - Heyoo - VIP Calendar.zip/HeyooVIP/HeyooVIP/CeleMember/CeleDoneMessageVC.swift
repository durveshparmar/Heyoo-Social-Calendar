//
//  CeleDoneMessageVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 30/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class CeleDoneMessageVC: UIViewController {
    @IBOutlet weak var viewBack: UIView!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var lblMessage: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewBack.layer.shadowOpacity = 0.4
        viewBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewBack.layer.shadowRadius = 3
        
        btnDone.layer.shadowColor = UIColor.lightGray.cgColor
        btnDone.layer.shadowOpacity = 0.4
        btnDone.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnDone.layer.shadowRadius = 5.0
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionDone(_ sender: UIButton)
    {
        self.navigationController?.popToRootViewController(animated: true)
    }
    

}











































