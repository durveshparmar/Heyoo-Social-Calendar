//
//  CeleInstructionVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 25/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class CeleInstructionVC: UIViewController {
    @IBOutlet weak var viewInstruction: UIView!
    @IBOutlet weak var btnGotit: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var strOTP = String()
    var strUserID = String()
    var strFirstName = String()
    var strLastName = String()
    var strCountry = String()
    var strState = String()
    var strCity = String()
    var proPicData = NSData()
    var arrCategorySelect = NSMutableArray()
    var strValType:String = "0"
    var strSelectCountryCode = NSString()
    var strEmailAddress = NSString()
    var strPhoneNumber = NSString()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewInstruction.layer.shadowColor = UIColor.lightGray.cgColor
        viewInstruction.layer.shadowOpacity = 0.4
        viewInstruction.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewInstruction.layer.shadowRadius = 3
        
        btnGotit.layer.shadowColor = UIColor.lightGray.cgColor
        btnGotit.layer.shadowOpacity = 0.4
        btnGotit.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnGotit.layer.shadowRadius = 5.0
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionGotIt(_ sender: UIButton)
    {
        self.registerWebServiceCall()
    }
    
    func registerWebServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/SignUp"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let jsonDataForCategory: Data? = try? JSONSerialization.data(withJSONObject: arrCategorySelect, options: [])
        let jsonStringForCategory = String(data: jsonDataForCategory ?? Data(), encoding: .utf8)
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        strOTP = UserDefaults.standard.value(forKey: "celeOTP") as! String
        strSelectCountryCode = UserDefaults.standard.value(forKey: "strSelectCountryCode") as! NSString
        strPhoneNumber = UserDefaults.standard.value(forKey: "strPhoneNumber") as! NSString
        strEmailAddress = UserDefaults.standard.value(forKey: "strEmailAddress") as! NSString
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"UserSignUp", "Val_Type":strValType, "Val_Firstname":strFirstName, "Val_Lastname":strLastName, "Val_Countrycode":strSelectCountryCode as String, "Val_Mobile":strPhoneNumber as String, "Val_Email":strEmailAddress as String, "Val_Country":strCountry, "Val_State":strState, "Val_City":strCity, "Val_ProfileImage":"", "Val_Categories":jsonStringForCategory!, "Val_OTP":strOTP, "Val_iOSToken":""]
        print(parameters)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                if value.count == 0
                {
                    if key == "Val_ProfileImage"
                    {
                        multipartFormData.append(self.proPicData as Data, withName: "Val_ProfileImage", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                    }
                }
                else
                {
                    multipartFormData.append((value ).data(using: .utf8)!, withName: key)
                }
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicRegResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicRegResponse?["status"] as? String == "success"
                    {
                        let dicData = dicRegResponse?["data"] as! NSDictionary
                        print(dicData)
                        
                        if dicData["Type"] as! String == "3" {
                            
                            if dicData["PAStatus"] as! String == "1" {
                                
                                let alertCntrl = UIAlertController(title: "Pending Approval. You will receive a text message once your account has been activated.", message: nil, preferredStyle: .alert)
                                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                    
                                    self.navigationController?.popToRootViewController(animated: true)
                                }))
                                self.present(alertCntrl, animated: true, completion: nil)
                            }
                            else {
                                
                                let strUserID = dicData["CelebrityID"] as! String
                                
                                UserDefaults.standard.set(strUserID, forKey: "celeUserID")
                                UserDefaults.standard.set("3", forKey: "type")
                                UserDefaults.standard.synchronize()
                                
                                let home = self.storyboard?.instantiateViewController(withIdentifier: "CeleHomeVC") as! CeleHomeVC
                                self.navigationController?.pushViewController(home, animated: true)
                            }
                        }
                        else {
                            let strUserID = dicData["UserID"] as! String
                            print(strUserID)
                            UserDefaults.standard.set(nil, forKey: "myProfile")
                            UserDefaults.standard.synchronize()
                            UserDefaults.standard.set(strUserID, forKey: "celeUserID2")
                            UserDefaults.standard.synchronize()
                            let videoVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleVideoVarificationVC") as! CeleVideoVarificationVC
                            videoVC.strOTP = self.strOTP
                            videoVC.strUserID = dicData["UserID"] as! String
                            UserDefaults.standard.set("Unverified", forKey: "VideoScreen")
                            UserDefaults.standard.synchronize()
                            self.navigationController?.pushViewController(videoVC, animated: true)
                        
                        }
                    }
                    else if dicRegResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicRegResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    


}








































