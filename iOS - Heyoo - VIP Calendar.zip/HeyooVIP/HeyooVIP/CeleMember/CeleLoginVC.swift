//
//  CeleLoginVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 25/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class CeleLoginVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtCountryCode: UITextField!
    @IBOutlet weak var txtSearchBar: UISearchBar!
    @IBOutlet weak var viewLogin: UIView!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtMobileNumber: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var searchActive : Bool = false
    var filtered = NSArray()
    
    var viewPopup = UIView()
    var arrCountryCode = NSArray()
    var blurView = UIVisualEffectView()
    var strSelectCountryCode = NSString()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewLogin.layer.shadowColor = UIColor.lightGray.cgColor
        viewLogin.layer.shadowOpacity = 0.4
        viewLogin.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLogin.layer.shadowRadius = 3
        
        btnLogin.layer.shadowColor = UIColor.lightGray.cgColor
        btnLogin.layer.shadowOpacity = 0.4
        btnLogin.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnLogin.layer.shadowRadius = 5.0
        
        let swipeGestureInBackVC = UISwipeGestureRecognizer(target: self, action: #selector(swipeToBackPop))
        swipeGestureInBackVC.direction = .right
        self.view.addGestureRecognizer(swipeGestureInBackVC)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        let alertControl = UIAlertController(title: "NOTE", message: "For security reasons, an incomplete VIP registration will not allow you re-entry into your account if your app is uninstalled or deleted. Please complete all necessary fields.", preferredStyle: UIAlertControllerStyle.alert)
        alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alertControl, animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)
        
        strSelectCountryCode = "+1"
        
        self.getCountryCode()
    }
    
    @objc func swipeToBackPop()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionSelectCountryCode(_ sender: UIButton) {
        
        tblView.isHidden = false
        showAnimateCountry()
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        
        let effect = UIBlurEffect(style: UIBlurEffectStyle.light)
        blurView = UIVisualEffectView(effect: effect)
        blurView.frame = viewPopup.bounds
        blurView.alpha = 0.7
        viewPopup.addSubview(blurView)
        viewPopup.addSubview(tblView)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
        
        txtSearchBar.becomeFirstResponder()
    }
    
    
    @IBAction func Back_Click(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBAction func ActionSignUp(_ sender: UIButton) {
        
        let regVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleRegisterVC") as! CeleRegisterVC
        self.navigationController?.pushViewController(regVC, animated: true)
    }
    
    @IBAction func ActionLogin(_ sender: UIButton) {
        
        LoginWebServiceCall()
    }
    
    // ********** Call Login WibService Method ********** //
    
    func LoginWebServiceCall()
    {
        if txtMobileNumber.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Authentication/SignIn"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let tokenString = UserDefaults.standard.value(forKey: "deviceToken") as! String
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Countrycode":strSelectCountryCode as String, "Val_iOStoken":tokenString, "Val_Mobile":txtMobileNumber.text! as String, "Val_Type":"1", "Action":"UserSignIn"]

            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append((value ).data(using: .utf8)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicLoginResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicLoginResponse?["status"] as? String == "success"
                        {
                            let dicData = dicLoginResponse?["data"] as! NSDictionary
                            
                            if dicData["Type"] as! String == "3" {
                                
                                if dicData["PAStatus"] as! String == "1" {
                                    
                                    let alertCntrl = UIAlertController(title: "Pending Approval. You will receive a text message once your account has been activated.", message: nil, preferredStyle: .alert)
                                    alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                                        
                                        self.navigationController?.popToRootViewController(animated: true)
                                    }))
                                    self.present(alertCntrl, animated: true, completion: nil)
                                }
                                else {
                                    
                                    let strUserID = dicData["CelebrityID"] as! String
                                    
                                    let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPOTPVC") as! VIPOTPVC
                                    otpVC.strOTP = dicData["OTP"] as! String
                                    otpVC.strSelectCountryCode = self.strSelectCountryCode
                                    otpVC.strPhoneNumber = self.txtMobileNumber.text! as NSString
                                    otpVC.strScreenCheck = "celeLogin" as NSString
                                    otpVC.strUserID = strUserID
                                    otpVC.strCalBGBaseURL = dicData["CalendarBGBaseURL"] as! String
                                    otpVC.strCalBGFlag = dicData["CalendarBGFlag"] as! String
                                    otpVC.strCalBFImage = dicData["CalendarBGImage"] as! String
                                    otpVC.strCeleLoginStatus = dicData["LoginStatus"] as! String
                                    otpVC.dicCeleLoginResponse = dicData
                                    otpVC.strCeleType = dicData["Type"] as! String
                                    self.navigationController?.pushViewController(otpVC, animated: true)
                                }
                            }
                            else {
                                
                                let strUserID = dicData["UserID"] as! String
                                
                                let otpVC = self.storyboard?.instantiateViewController(withIdentifier: "VIPOTPVC") as! VIPOTPVC
                                otpVC.strOTP = dicData["OTP"] as! String
                                otpVC.strSelectCountryCode = self.strSelectCountryCode
                                otpVC.strPhoneNumber = self.txtMobileNumber.text! as NSString
                                otpVC.strScreenCheck = "celeLogin" as NSString
                                otpVC.strUserID = strUserID
                                otpVC.strCalBGBaseURL = dicData["CalendarBGBaseURL"] as! String
                                otpVC.strCalBGFlag = dicData["CalendarBGFlag"] as! String
                                otpVC.strCalBFImage = dicData["CalendarBGImage"] as! String
                                otpVC.strCeleLoginStatus = dicData["LoginStatus"] as! String
                                otpVC.dicCeleLoginResponse = dicData
                                otpVC.strCeleType = dicData["Type"] as! String
                                self.navigationController?.pushViewController(otpVC, animated: true)
                            }
                            
                        }
                        else if dicLoginResponse?["status"] as? String == "warning"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else if dicLoginResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                }
            }
        }
    }
    
    
    
    
    // ********* Tableview Delegate DataSource Methods ********* //
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if searchActive
        {
            if filtered.count == 0
            {
                return arrCountryCode.count
            }
            else
            {
                return filtered.count
            }
        }
        else
        {
            return arrCountryCode.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        if searchActive
        {
            if filtered.count == 0
            {
                let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
            else
            {
                let dicCountry = filtered[indexPath.row] as! NSDictionary
                cell.textLabel?.text = dicCountry["name"] as? String
                cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
            }
        }
        else
        {
            let dicCountry = arrCountryCode[indexPath.row] as! NSDictionary
            cell.textLabel?.text = dicCountry["name"] as? String
            cell.detailTextLabel?.text = "(\(dicCountry["dial_code"] ?? ""))"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if searchActive
        {
            if filtered.count == 0
            {
                let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
            else
            {
                let dicSelectCountry = filtered[indexPath.row] as! NSDictionary
                txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
                
                strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
            }
        }
        else
        {
            let dicSelectCountry = arrCountryCode[indexPath.row] as! NSDictionary
            txtCountryCode.text = "\(dicSelectCountry["name"] ?? "") (\(dicSelectCountry["dial_code"] ?? ""))"
            
            strSelectCountryCode = "\(dicSelectCountry["dial_code"] ?? "")" as NSString as NSString
        }
        
        txtSearchBar.text = nil
        txtSearchBar.resignFirstResponder()
        viewPopup.isHidden = true
        filtered = NSArray()
        tblView.reloadData()
    }
    
    // ********** UISearchbarDelegate Methods ********** //
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar)
    {
        searchActive = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
    {
        searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        filtered = arrCountryCode.filter({ (text) -> Bool in
            let dicCountry = text as! NSDictionary
            let tmp: NSString = dicCountry["name"] as! NSString
            let range = tmp.range(of: searchText, options: .caseInsensitive)
            return range.location != NSNotFound
        }) as! [NSDictionary] as NSArray
        
        if filtered.count == 0
        {
            searchActive = false
        }
        else
        {
            searchActive = true
        }
        tblView.reloadData()
    }
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == blurView
            {
                txtSearchBar.text = nil
                txtSearchBar.resignFirstResponder()
                viewPopup.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    func getCountryCode()
    {
        if let path = Bundle.main.path(forResource: "CountryCodes", ofType: "json")
        {
            let jsonData = NSData(contentsOfFile: path)
            do
            {
                arrCountryCode = try JSONSerialization.jsonObject(with: jsonData! as Data, options: JSONSerialization.ReadingOptions.mutableContainers) as! NSArray
                
                tblView.reloadData()
                
            } catch {}
        }
    }
    
    func showAnimateCountry()
    {
        viewPopup.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        viewPopup.alpha = 0.0
        UIView.animate(withDuration: 0.25, animations: {
            self.viewPopup.alpha = 1.0
            self.viewPopup.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        })
    }
    
    

}


































