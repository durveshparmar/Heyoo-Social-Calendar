//
//  CeleSuccessLoginVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 16/03/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import SDWebImage

class CeleSuccessLoginVC: UIViewController {
    @IBOutlet weak var imgViewProPic: UIImageView!
    
    var dicCeleLoginData = NSDictionary()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width / 2
        
        imgViewProPic.sd_setImage(with: URL(string : dicCeleLoginData["ProfileImage"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionContinue(_ sender: UIButton) {
        
        let home = self.storyboard?.instantiateViewController(withIdentifier: "CeleHomeVC") as! CeleHomeVC
        self.navigationController?.pushViewController(home, animated: true)
    }
    

    

}














































