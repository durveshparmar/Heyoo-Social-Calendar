//
//  CeleCategoriesVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 25/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class CeleCategoriesVC: UIViewController {
    @IBOutlet weak var btnActor: UIButton!
    @IBOutlet weak var btnMusician: UIButton!
    @IBOutlet weak var btnProAthelete: UIButton!
    @IBOutlet weak var btnComedian: UIButton!
    @IBOutlet weak var btnModel: UIButton!
    @IBOutlet weak var btnCEO: UIButton!
    @IBOutlet weak var btnOrganization: UIButton!
    @IBOutlet weak var btnOther: UIButton!
    @IBOutlet weak var btnPersonalAssist: UIButton!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var strSelectCountryCode = NSString()
    var strEmailAddress = NSString()
    var strPhoneNumber = NSString()
    var strOTP = String()    
    
    var arrCategorySelect = NSMutableArray()
    var strValType:String = "0"
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear

        self.setAllButtonShadow()
        
        arrCategorySelect = NSMutableArray()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    // ********** All Button Action ********** //
    
    @IBAction func ActionActor(_ sender: UIButton) {
        
        if arrCategorySelect.contains("1")
        {
            if let index:Int = arrCategorySelect.index(of: "1")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnActor.backgroundColor = UIColor .white
            btnActor.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("1")
            btnActor.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnActor.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
    }
    
    @IBAction func ActionMusician(_ sender: UIButton) {
        
        if arrCategorySelect.contains("2")
        {
            if let index:Int = arrCategorySelect.index(of: "2")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnMusician.backgroundColor = UIColor .white
            btnMusician.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("2")
            btnMusician.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnMusician.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
    }
    
    @IBAction func ActionProAthelete(_ sender: UIButton) {
        
        if arrCategorySelect.contains("3")
        {
            if let index:Int = arrCategorySelect.index(of: "3")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnProAthelete.backgroundColor = UIColor .white
            btnProAthelete.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("3")
            btnProAthelete.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnProAthelete.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
    }
    
    @IBAction func ActionComedian(_ sender: UIButton) {
        
        if arrCategorySelect.contains("4")
        {
            if let index:Int = arrCategorySelect.index(of: "4")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnComedian.backgroundColor = UIColor .white
            btnComedian.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("4")
            btnComedian.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnComedian.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
    }
    
    @IBAction func ActionModel(_ sender: UIButton) {
        
        if arrCategorySelect.contains("5")
        {
            if let index:Int = arrCategorySelect.index(of: "5")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnModel.backgroundColor = UIColor .white
            btnModel.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("5")
            btnModel.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnModel.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
        
    }
    
    @IBAction func ActionCEO(_ sender: UIButton) {
        
        if arrCategorySelect.contains("6")
        {
            if let index:Int = arrCategorySelect.index(of: "6")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnCEO.backgroundColor = UIColor .white
            btnCEO.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("6")
            btnCEO.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnCEO.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
        
    }
    
    @IBAction func ActionOrganization(_ sender: UIButton) {
        
        if arrCategorySelect.contains("7")
        {
            if let index:Int = arrCategorySelect.index(of: "7")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnOrganization.backgroundColor = UIColor .white
            btnOrganization.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("7")
            btnOrganization.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnOrganization.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
        
    }
    
    @IBAction func ActionOther(_ sender: UIButton) {
        
        if arrCategorySelect.contains("8")
        {
            if let index:Int = arrCategorySelect.index(of: "8")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnOther.backgroundColor = UIColor .white
            btnOther.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("8")
            btnOther.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnOther.setTitleColor(UIColor .white, for: .normal)
        }
        
        btnPersonalAssist.backgroundColor = UIColor .white
        btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
        strValType = "1"
        
    }
    
    @IBAction func ActionPersonalAssistant(_ sender: UIButton) {
        
        arrCategorySelect.removeAllObjects()
        
        btnActor.backgroundColor = UIColor .white
        btnActor.setTitleColor(UIColor .black, for: .normal)
        
        btnMusician.backgroundColor = UIColor .white
        btnMusician.setTitleColor(UIColor .black, for: .normal)
        
        btnProAthelete.backgroundColor = UIColor .white
        btnProAthelete.setTitleColor(UIColor .black, for: .normal)
        
        btnComedian.backgroundColor = UIColor .white
        btnComedian.setTitleColor(UIColor .black, for: .normal)
        
        btnModel.backgroundColor = UIColor .white
        btnModel.setTitleColor(UIColor .black, for: .normal)
        
        btnCEO.backgroundColor = UIColor .white
        btnCEO.setTitleColor(UIColor .black, for: .normal)
        
        btnOrganization.backgroundColor = UIColor .white
        btnOrganization.setTitleColor(UIColor .black, for: .normal)
        
        btnOther.backgroundColor = UIColor .white
        btnOther.setTitleColor(UIColor .black, for: .normal)
        
        if strValType == "3" {
            
            btnPersonalAssist.backgroundColor = UIColor .white
            btnPersonalAssist.setTitleColor(UIColor .black, for: .normal)
            strValType = "0"
        }
        else {
            
            btnPersonalAssist.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnPersonalAssist.setTitleColor(UIColor .white, for: .normal)
            strValType = "3"
        }
    }
    
    
    @IBAction func ActionNext(_ sender: UIButton) {
        
        if strValType == "0" {
            
            let alertCntrl = UIAlertController(title: "Alert", message: "Choose minimum one category", preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertCntrl, animated: true, completion: nil)
        }
        else if strValType == "1" {
            
            if arrCategorySelect.count == 0 {
                
                let alertCntrl = UIAlertController(title: "Alert", message: "Choose minimum one category", preferredStyle: .alert)
                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                self.present(alertCntrl, animated: true, completion: nil)
            }
            else {
                UserDefaults.standard.set("myProfile", forKey: "myProfile")
                UserDefaults.standard.synchronize()
                let profileVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleMyProfileVC") as! CeleMyProfileVC
                profileVC.strOTP = self.strOTP
                profileVC.arrCategorySelect = arrCategorySelect
                profileVC.strValType = strValType
                profileVC.strSelectCountryCode = strSelectCountryCode
                profileVC.strPhoneNumber = strPhoneNumber
                profileVC.strEmailAddress = strEmailAddress
                self.navigationController?.pushViewController(profileVC, animated: true)
            }
        }
        else if strValType == "3" {
            UserDefaults.standard.set("myProfile", forKey: "myProfile")
            UserDefaults.standard.synchronize()
            let profileVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleMyProfileVC") as! CeleMyProfileVC
            profileVC.strOTP = self.strOTP
            profileVC.arrCategorySelect = arrCategorySelect
            profileVC.strValType = strValType
            profileVC.strSelectCountryCode = strSelectCountryCode
            profileVC.strPhoneNumber = strPhoneNumber
            profileVC.strEmailAddress = strEmailAddress
            self.navigationController?.pushViewController(profileVC, animated: true)
        }
    }
    
    
    // ********** All Button Shadow ********** //
    func setAllButtonShadow()
    {
        btnNext.layer.shadowColor = UIColor.lightGray.cgColor
        btnNext.layer.shadowOpacity = 0.4
        btnNext.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnNext.layer.shadowRadius = 5.0
        
        btnActor.layer.shadowColor = UIColor.lightGray.cgColor
        btnActor.layer.shadowOpacity = 0.4
        btnActor.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnActor.layer.shadowRadius = 5.0
        
        btnMusician.layer.shadowColor = UIColor.lightGray.cgColor
        btnMusician.layer.shadowOpacity = 0.4
        btnMusician.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnMusician.layer.shadowRadius = 5.0
        
        btnProAthelete.layer.shadowColor = UIColor.lightGray.cgColor
        btnProAthelete.layer.shadowOpacity = 0.4
        btnProAthelete.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnProAthelete.layer.shadowRadius = 5.0
        
        btnComedian.layer.shadowColor = UIColor.lightGray.cgColor
        btnComedian.layer.shadowOpacity = 0.4
        btnComedian.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnComedian.layer.shadowRadius = 5.0
        
        btnModel.layer.shadowColor = UIColor.lightGray.cgColor
        btnModel.layer.shadowOpacity = 0.4
        btnModel.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnModel.layer.shadowRadius = 5.0
        
        btnCEO.layer.shadowColor = UIColor.lightGray.cgColor
        btnCEO.layer.shadowOpacity = 0.4
        btnCEO.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnCEO.layer.shadowRadius = 5.0
        
        btnOrganization.layer.shadowColor = UIColor.lightGray.cgColor
        btnOrganization.layer.shadowOpacity = 0.4
        btnOrganization.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnOrganization.layer.shadowRadius = 5.0
        
        btnOther.layer.shadowColor = UIColor.lightGray.cgColor
        btnOther.layer.shadowOpacity = 0.4
        btnOther.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnOther.layer.shadowRadius = 5.0
        
        btnPersonalAssist.layer.shadowColor = UIColor.lightGray.cgColor
        btnPersonalAssist.layer.shadowOpacity = 0.4
        btnPersonalAssist.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPersonalAssist.layer.shadowRadius = 5.0
    }
    

}







































