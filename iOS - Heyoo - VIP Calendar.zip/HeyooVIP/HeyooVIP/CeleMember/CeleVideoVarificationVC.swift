//
//  CeleVideoVarificationVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 25/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import AVKit
import Alamofire

class CeleVideoVarificationVC: UIViewController {
    @IBOutlet weak var imgViewPlayStop: UIImageView!
    @IBOutlet weak var myView: UIView!
    @IBOutlet weak var lblTimer: UILabel!
    @IBOutlet weak var btnPlayVideo: UIButton!
    @IBOutlet weak var blurViewCamera: UIVisualEffectView!
    @IBOutlet weak var lblOtp: UILabel!
    @IBOutlet weak var lblOtp1: UILabel!
    @IBOutlet weak var lblOtp2: UILabel!
    @IBOutlet weak var lblOtp3: UILabel!
    
    var strOTP = String()
    var strUserID = String()
    
    
    var counter = Int()
    var countTimer = Timer()
    var videoData = NSData()
    
    
    var session: AVCaptureSession?
    var userreponsevideoData = NSData()
    var userreponsethumbimageData = NSData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        strOTP = UserDefaults.standard.value(forKey: "celeOTP") as! String
        let Charecter = Array(strOTP)
        counter = 0
        btnPlayVideo.layer.cornerRadius = btnPlayVideo.frame.size.height/2
        btnPlayVideo.layer.shadowColor = UIColor.lightGray.cgColor
        btnPlayVideo.layer.shadowOpacity = 0.4
        btnPlayVideo.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPlayVideo.layer.shadowRadius = 5.0
        
        lblOtp.layer.borderWidth = 1
        lblOtp.layer.borderColor = UIColor.darkGray.cgColor
        lblOtp.text = "\(Charecter[0])"
        
        lblOtp1.layer.borderWidth = 1
        lblOtp1.layer.borderColor = UIColor.darkGray.cgColor
        lblOtp1.text = "\(Charecter[1])"
        
        lblOtp2.layer.borderWidth = 1
        lblOtp2.layer.borderColor = UIColor.darkGray.cgColor
        lblOtp2.text = "\(Charecter[2])"
        
        lblOtp3.layer.borderWidth = 1
        lblOtp3.layer.borderColor = UIColor.darkGray.cgColor
        lblOtp3.text = "\(Charecter[3])"
        
        createSession()
        if AVCaptureDevice.authorizationStatus(for: .video) ==  .authorized {
            AVCaptureDevice.requestAccess(for: .audio, completionHandler: { (granted: Bool) in
                if granted {
                    //access allowed
                    print("access allowed")
                } else {
                    //access denied
                    print("access denied")
                    let cameraUnavailableAlertController = UIAlertController (title: "Heyoo VIP Calendar", message: "To allow permission for your microphone.", preferredStyle: .alert)
                    
                    let settingsAction = UIAlertAction(title: "Settings", style: .destructive) { (_) -> Void in
                        let settingsUrl = NSURL(string:UIApplicationOpenSettingsURLString)
                        if let url = settingsUrl {
                            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                        }
                    }
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
                    cameraUnavailableAlertController .addAction(settingsAction)
                    cameraUnavailableAlertController .addAction(cancelAction)
                    self.present(cameraUnavailableAlertController , animated: true, completion: nil)
                }
            })
        } else {
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
                if granted {
                    //access allowed
                    print("access allowed")
                } else {
                    //access denied
                    print("access denied")
                    let cameraUnavailableAlertController = UIAlertController (title: "Heyoo VIP Calendar", message: "To allow permission for your camera.", preferredStyle: .alert)
                    
                    let settingsAction = UIAlertAction(title: "Settings", style: .destructive) { (_) -> Void in
                        let settingsUrl = NSURL(string:UIApplicationOpenSettingsURLString)
                        if let url = settingsUrl {
                            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
                        }
                    }
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
                    cameraUnavailableAlertController .addAction(settingsAction)
                    cameraUnavailableAlertController .addAction(cancelAction)
                    self.present(cameraUnavailableAlertController , animated: true, completion: nil)
                }
            })
        }
        strUserID = UserDefaults.standard.value(forKey: "celeUserID2") as! String
        print(strUserID)
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionPlayVideo(_ sender: UIButton)
    {
        if counter > 0 {
            
            counter = 0
//            self.updateCounter()
            imgViewPlayStop.image = #imageLiteral(resourceName: "socialLoginSend1")
            imgViewPlayStop.backgroundColor = UIColor.clear
            btnPlayVideo.backgroundColor = UIColor(red: 226/255, green: 221/255, blue: 215/255, alpha: 1)
            
        }
        else {
            
            imgViewPlayStop.backgroundColor = UIColor.white
            imgViewPlayStop.image = nil
            btnPlayVideo.backgroundColor = UIColor(red: 255/255, green: 179/255, blue: 61/255, alpha: 1)
            
            counter = 15
            session?.startRunning()
            //        btnPlayVideo.isEnabled = false
            blurViewCamera.isHidden = true
            countTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        }
    }
    
    @objc func updateCounter() {
        
        if counter >= 0 {
            
            lblTimer.text = "00:\(getStringFrom(seconds: counter))"
            counter -= 1
        }
        else
        {
            session?.stopRunning()
            countTimer.invalidate()
            blurViewCamera.isHidden = false
            
            let alertCntrl = UIAlertController(title: nil, message: nil, preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Send Video", style: .default, handler: { (action) in
                
                self.sendRecordVideoAPICall()

            }))
            alertCntrl.addAction(UIAlertAction(title: "Retry Video", style: .default, handler: { (action) in
                
                self.btnPlayVideo.isEnabled = true
                self.lblTimer.text = "00:15"
                self.imgViewPlayStop.image = #imageLiteral(resourceName: "socialLoginSend1")
                self.imgViewPlayStop.backgroundColor = UIColor(red: 226/255, green: 221/255, blue: 215/255, alpha: 1)
                self.blurViewCamera.isHidden = true
                self.session?.startRunning()
                self.btnPlayVideo.backgroundColor = UIColor(red: 226/255, green: 221/255, blue: 215/255, alpha: 1)
                
            }))
            self.present(alertCntrl, animated: true, completion: nil)
        }
    }
    
    func getStringFrom(seconds: Int) -> String {
        
        return seconds < 10 ? "0\(seconds)" : "\(seconds)"
    }
    
    func sendRecordVideoAPICall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/Verify"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        strUserID = UserDefaults.standard.value(forKey: "celeUserID2") as! String
        print(strUserID)
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"UploadVideo", "Val_Celebrityid":strUserID, "Val_Celebrityvideo":""]
        
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                if value.count == 0
                {
                    if key == "Val_Celebrityvideo"
                    {
                        multipartFormData.append(self.videoData as Data, withName: "Val_Celebrityvideo", fileName: "\(Date().timeIntervalSince1970).mp4", mimeType: "video/mp4")
                    }
                }
                else
                {
                    multipartFormData.append((value ).data(using: .utf8)!, withName: key)
                }
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicRegResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicRegResponse?["status"] as? String == "success"
                    {
                        let doneVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleDoneMessageVC") as! CeleDoneMessageVC
                        UserDefaults.standard.set(nil, forKey: "VideoScreen")
                        UserDefaults.standard.synchronize()
                        self.navigationController?.pushViewController(doneVC, animated: true)
                        
                    }
                    else if dicRegResponse?["status"] as? String == "error"
                    {
                        self.btnPlayVideo.isEnabled = true
                        let alertCntrl = UIAlertController(title: nil, message: (dicRegResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                print(encodingError)
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    
    @IBAction func help_Click(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Instructions", message: "1. Please state your full name, first and \r\n   last. Please speak slowly and clearly. \r\n2. Please repeat the 4 digit code that is identified on the screen.", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "GOT IT!", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func createSession() {
        
        var input: AVCaptureDeviceInput?
        let  movieFileOutput = AVCaptureMovieFileOutput()
        var prevLayer: AVCaptureVideoPreviewLayer?
        prevLayer?.frame.size = myView.frame.size
        session = AVCaptureSession()
        let error: NSError? = nil
        do { input = try AVCaptureDeviceInput(device: self.cameraWithPosition(position: .front)!) } catch {return}
        if error == nil {
            session?.addInput(input!)
        } else {
        }
        
        var inputAudio: AVCaptureDeviceInput?
        do { inputAudio = try AVCaptureDeviceInput(device: self.cameraWithAudio()) } catch {return}
        if error == nil {
            session?.addInput(inputAudio!)
        } else {
        }
        
        
        prevLayer = AVCaptureVideoPreviewLayer(session: session!)
        prevLayer?.frame.size = myView.frame.size
        prevLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
        prevLayer?.connection?.videoOrientation = .portrait
        myView.layer.addSublayer(prevLayer!)
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
//        let  filemainurl = NSURL(string: ("\(documentsURL.URLByAppendingPathComponent("temp")!)" + ".mov"))
        let filemainurl = URL(string: "\(documentsURL)temp.mov")
        
        let maxDuration: CMTime = CMTimeMake(600, 10)
        movieFileOutput.maxRecordedDuration = maxDuration
        movieFileOutput.minFreeDiskSpaceLimit = 1024 * 1024
        if self.session!.canAddOutput(movieFileOutput) {
            self.session!.addOutput(movieFileOutput)
        }
        session?.startRunning()
        movieFileOutput.startRecording(to: filemainurl!, recordingDelegate: self)
        
    }
    
    func cameraWithPosition(position: AVCaptureDevice.Position) -> AVCaptureDevice? {
        let devices = AVCaptureDevice.devices(for: AVMediaType.video)
        for device in devices {
            if device.position == position {
                return device
            }
        }
        return nil
    }
    
    func cameraWithAudio() -> AVCaptureDevice {
        let devices = AVCaptureDevice.devices(for: AVMediaType.audio)
        
        for device in devices {
            if device != nil {
                return device
            }
        }
        
        return devices[0]
    }
    
}

extension CeleVideoVarificationVC: AVCaptureFileOutputRecordingDelegate
{
    
    func captureOutput(captureOutput: AVCaptureFileOutput!, didStartRecordingToOutputFileAtURL fileURL: NSURL!, fromConnections connections: [AnyObject]!) {
    }
    
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        let filemainurl = outputFileURL
        
        videoData = NSData()
        videoData = NSData(contentsOf: filemainurl)!
        
//        let player = AVPlayer(url: outputFileURL)
//        let playerController = AVPlayerViewController()
//        playerController.player = player
//        self.present(playerController, animated: true) {
//            player.play()
//        }

    }
    
    
    
}































