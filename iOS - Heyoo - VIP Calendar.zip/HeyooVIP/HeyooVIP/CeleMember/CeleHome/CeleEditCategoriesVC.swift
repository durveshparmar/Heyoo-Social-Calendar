//
//  CeleEditCategoriesVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 24/03/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class CeleEditCategoriesVC: UIViewController {
    @IBOutlet weak var btnActor: UIButton!
    @IBOutlet weak var btnMusician: UIButton!
    @IBOutlet weak var btnProAthelete: UIButton!
    @IBOutlet weak var btnComedian: UIButton!
    @IBOutlet weak var btnModel: UIButton!
    @IBOutlet weak var btnCEO: UIButton!
    @IBOutlet weak var btnOrganization: UIButton!
    @IBOutlet weak var btnOther: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var arrSelectedCat = NSArray()
    var arrCategorySelect = NSMutableArray()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        arrCategorySelect = NSMutableArray()
        
        for i in (0..<arrSelectedCat.count) {
            
            arrCategorySelect.add(arrSelectedCat[i])
        }
        self.setAllButtonShadow()
        self.setSelectedCategoriesButton()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionSaveCategories(_ sender: UIBarButtonItem) {
        
        self.editCategoriesAPICall()
    }
    
    @IBAction func ActionActor(_ sender: UIButton) {
        
        if arrCategorySelect.contains("1")
        {
            if let index:Int = arrCategorySelect.index(of: "1")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnActor.backgroundColor = UIColor .white
            btnActor.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("1")
            btnActor.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnActor.setTitleColor(UIColor .white, for: .normal)
        }
    }
    
    @IBAction func ActionMusician(_ sender: UIButton) {
        
        if arrCategorySelect.contains("2")
        {
            if let index:Int = arrCategorySelect.index(of: "2")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnMusician.backgroundColor = UIColor .white
            btnMusician.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("2")
            btnMusician.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnMusician.setTitleColor(UIColor .white, for: .normal)
        }
    }
    
    @IBAction func ActionProAthelete(_ sender: UIButton) {
        
        if arrCategorySelect.contains("3")
        {
            if let index:Int = arrCategorySelect.index(of: "3")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnProAthelete.backgroundColor = UIColor .white
            btnProAthelete.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("3")
            btnProAthelete.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnProAthelete.setTitleColor(UIColor .white, for: .normal)
        }
    }
    
    @IBAction func ActionComedian(_ sender: UIButton) {
        
        if arrCategorySelect.contains("4")
        {
            if let index:Int = arrCategorySelect.index(of: "4")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnComedian.backgroundColor = UIColor .white
            btnComedian.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("4")
            btnComedian.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnComedian.setTitleColor(UIColor .white, for: .normal)
        }
    }
    
    @IBAction func ActionModel(_ sender: UIButton) {
        
        if arrCategorySelect.contains("5")
        {
            if let index:Int = arrCategorySelect.index(of: "5")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnModel.backgroundColor = UIColor .white
            btnModel.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("5")
            btnModel.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnModel.setTitleColor(UIColor .white, for: .normal)
        }
        
    }
    
    @IBAction func ActionCEO(_ sender: UIButton) {
        
        if arrCategorySelect.contains("6")
        {
            if let index:Int = arrCategorySelect.index(of: "6")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnCEO.backgroundColor = UIColor .white
            btnCEO.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("6")
            btnCEO.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnCEO.setTitleColor(UIColor .white, for: .normal)
        }
        
    }
    
    @IBAction func ActionOrganization(_ sender: UIButton) {
        
        if arrCategorySelect.contains("7")
        {
            if let index:Int = arrCategorySelect.index(of: "7")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnOrganization.backgroundColor = UIColor .white
            btnOrganization.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("7")
            btnOrganization.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnOrganization.setTitleColor(UIColor .white, for: .normal)
        }
        
    }
    
    @IBAction func ActionOther(_ sender: UIButton) {
        
        if arrCategorySelect.contains("8")
        {
            if let index:Int = arrCategorySelect.index(of: "8")
            {
                arrCategorySelect.removeObject(at: index)
            }
            
            btnOther.backgroundColor = UIColor .white
            btnOther.setTitleColor(UIColor .black, for: .normal)
        }
        else
        {
            arrCategorySelect.add("8")
            btnOther.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnOther.setTitleColor(UIColor .white, for: .normal)
        }
        
    }
    
    
    // ********** All Button Shadow ********** //
    func setAllButtonShadow()
    {
        btnActor.layer.shadowColor = UIColor.lightGray.cgColor
        btnActor.layer.shadowOpacity = 0.4
        btnActor.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnActor.layer.shadowRadius = 5.0
        
        btnMusician.layer.shadowColor = UIColor.lightGray.cgColor
        btnMusician.layer.shadowOpacity = 0.4
        btnMusician.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnMusician.layer.shadowRadius = 5.0
        
        btnProAthelete.layer.shadowColor = UIColor.lightGray.cgColor
        btnProAthelete.layer.shadowOpacity = 0.4
        btnProAthelete.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnProAthelete.layer.shadowRadius = 5.0
        
        btnComedian.layer.shadowColor = UIColor.lightGray.cgColor
        btnComedian.layer.shadowOpacity = 0.4
        btnComedian.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnComedian.layer.shadowRadius = 5.0
        
        btnModel.layer.shadowColor = UIColor.lightGray.cgColor
        btnModel.layer.shadowOpacity = 0.4
        btnModel.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnModel.layer.shadowRadius = 5.0
        
        btnCEO.layer.shadowColor = UIColor.lightGray.cgColor
        btnCEO.layer.shadowOpacity = 0.4
        btnCEO.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnCEO.layer.shadowRadius = 5.0
        
        btnOrganization.layer.shadowColor = UIColor.lightGray.cgColor
        btnOrganization.layer.shadowOpacity = 0.4
        btnOrganization.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnOrganization.layer.shadowRadius = 5.0
        
        btnOther.layer.shadowColor = UIColor.lightGray.cgColor
        btnOther.layer.shadowOpacity = 0.4
        btnOther.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnOther.layer.shadowRadius = 5.0
    }
    
    
    func setSelectedCategoriesButton() {
        
        if arrCategorySelect.contains("1")
        {
            btnActor.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnActor.setTitleColor(UIColor .white, for: .normal)
        }
        
        if arrCategorySelect.contains("2")
        {
         
            btnMusician.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnMusician.setTitleColor(UIColor .white, for: .normal)
        }
        
        if arrCategorySelect.contains("3")
        {
         
            btnProAthelete.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnProAthelete.setTitleColor(UIColor .white, for: .normal)
        }
        
        if arrCategorySelect.contains("4")
        {
         
            btnComedian.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnComedian.setTitleColor(UIColor .white, for: .normal)
        }
        
        if arrCategorySelect.contains("5")
        {
         
            btnModel.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnModel.setTitleColor(UIColor .white, for: .normal)
        }
        
        if arrCategorySelect.contains("6")
        {
         
            btnCEO.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnCEO.setTitleColor(UIColor .white, for: .normal)
        }
        
        if arrCategorySelect.contains("7")
        {
         
            btnOrganization.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnOrganization.setTitleColor(UIColor .white, for: .normal)
        }
        
        if arrCategorySelect.contains("8")
        {
         
            btnOther.backgroundColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0)
            btnOther.setTitleColor(UIColor .white, for: .normal)
        }
    }
    
    
    // ********** All Webservices Call ********** //
    func editCategoriesAPICall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        
        let jsonDataForCategory: Data? = try? JSONSerialization.data(withJSONObject: arrCategorySelect, options: [])
        let jsonStringForCategory = String(data: jsonDataForCategory ?? Data(), encoding: .utf8)
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"UpdateCategories", "Val_Celebrityid":strUserID, "Val_Categories": jsonStringForCategory]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    let dicUpdateResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicUpdateResponse?["status"] as? String == "success"
                    {
                        self.navigationController?.popViewController(animated: true)
                    }
                    else if dicUpdateResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    

}









































