//
//  CeleSettingsVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 11/04/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class CeleSettingsVC: UIViewController {
    
    @IBOutlet weak var userProfile_img: UIImageView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var dicUserData = NSDictionary()
    var arrSelectedCat = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        userProfile_img.layer.cornerRadius = userProfile_img.frame.size.width/2
        userProfile_img.clipsToBounds = true
        let strProfilePic = dicUserData["ProfileImage"] as! String
        if strProfilePic == "" {
            
            self.profileNameImaageGenerater(strFName: dicUserData["FirstName"] as! String, strLName: dicUserData["LastName"] as! String)
        }
        else {
            
            self.userProfile_img.sd_setImage(with: URL(string : strProfilePic), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        }
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Mark:- Button Action
    @IBAction func BackClick(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func EditProfileClick(_ sender: UIButton) {
        let editProfile = self.storyboard?.instantiateViewController(withIdentifier: "CeleEditProfileVC") as! CeleEditProfileVC
        self.navigationController?.pushViewController(editProfile, animated: true)
    }
    
    @IBAction func EditCategoryClick(_ sender: UIButton) {
        let editCat = self.storyboard?.instantiateViewController(withIdentifier: "CeleEditCategoriesVC") as! CeleEditCategoriesVC
        editCat.arrSelectedCat = arrSelectedCat
        self.navigationController?.pushViewController(editCat, animated: true)
    }
    
    @IBAction func TermsClick(_ sender: UIButton) {
        if let url = URL(string: "http://heyoo.life/terms-of-use.html") {
            if #available(iOS 10, *){
                UIApplication.shared.open(url)
            }else{
                UIApplication.shared.openURL(url)
            }
            
        }
    }
    
    @IBAction func PrivecyClick(_ sender: UIButton) {
        if let url = URL(string: "https://www.iubenda.com/privacy-policy/35888035") {
            if #available(iOS 10, *){
                UIApplication.shared.open(url)
            }else{
                UIApplication.shared.openURL(url)
            }
            
        }
    }
    
    @IBAction func LogoutClick(_ sender: UIButton) {
        self.LogOutWebServiceCall()
    }
    
    // ********** Call Login WibService Method ********** //
    
    func LogOutWebServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/SignOut"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Action":"UserSignOut"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    let dicLoginResponse = response.result.value as? [String: Any]
                    MBProgressHUD.hide(for: self.view, animated: true)
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                        let fileURL = documentDirectoryURL.appendingPathComponent("CalBack")
                        do {
                            try FileManager.default.removeItem(at: fileURL)
                        } catch {
                        }
                        UserDefaults.standard.set(nil, forKey: "celeUserID")
                        UserDefaults.standard.set(nil, forKey: "celeType")
                        UserDefaults.standard.synchronize()
                        
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    func profileNameImaageGenerater(strFName:String, strLName:String)
    {
        let lblNameInitialize = UILabel()
        lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
        lblNameInitialize.textColor = UIColor.white
        lblNameInitialize.font = UIFont.systemFont(ofSize: 30.0)
        
        lblNameInitialize.text = String(strFName.characters.first!) + String(strLName.characters.first!)
        lblNameInitialize.textAlignment = NSTextAlignment.center
        lblNameInitialize.backgroundColor = UIColor.gray
        
        UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
        lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
        self.userProfile_img.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
