//
//  CeleHomeTblCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 31/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class CeleHomeTblCell: UITableViewCell {
    @IBOutlet weak var viewMainBack: UIView!
    @IBOutlet weak var viewColor: UIView!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblEventPersonName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        viewMainBack.layer.shadowColor = UIColor.gray.cgColor
        viewMainBack.layer.shadowOffset = CGSize.zero
        viewMainBack.layer.shadowOpacity = 0.5 //0.4
        viewMainBack.layer.shadowRadius = 5 //3
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
