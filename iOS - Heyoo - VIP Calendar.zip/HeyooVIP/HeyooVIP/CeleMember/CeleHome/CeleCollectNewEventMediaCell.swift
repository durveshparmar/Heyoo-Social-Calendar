//
//  CeleCollectNewEventMediaCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 02/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class CeleCollectNewEventMediaCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var btnDelete: UIButton!
    @IBOutlet weak var imgViewPlayIcon: UIImageView!
    
}
