//
//  CeleEditProfileVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 23/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class CeleEditProfileVC: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate {
    @IBOutlet weak var viewProfileDetail: UIView!
    @IBOutlet weak var btnUpdate: UIButton!
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtLastName: UITextField!
    @IBOutlet weak var txtCountry: UITextField!
    @IBOutlet weak var txtState: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var dataPrpPic = NSData()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewProfileDetail.layer.shadowColor = UIColor.lightGray.cgColor
        viewProfileDetail.layer.shadowOpacity = 0.4
        viewProfileDetail.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewProfileDetail.layer.shadowRadius = 3
        
        btnUpdate.layer.shadowColor = UIColor.lightGray.cgColor
        btnUpdate.layer.shadowOpacity = 0.4
        btnUpdate.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnUpdate.layer.shadowRadius = 5.0
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        imgViewProPic.layer.borderWidth = 3.0
        imgViewProPic.layer.borderColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0) .cgColor
        
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        getUserProfileWebServiceCall()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == imgViewProPic
            {
                OpenImagePickerForProfilePicture()
            }
            else
            {
                return
            }
        }
    }
    
    func OpenImagePickerForProfilePicture()
    {
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (alert: UIAlertAction) in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)
            {
                let imag = UIImagePickerController()
                imag.delegate = self
                imag.sourceType = UIImagePickerControllerSourceType.camera
                imag.allowsEditing = true
                self.present(imag, animated: true, completion: nil)
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Gallery", style: .default, handler: { (alert: UIAlertAction) in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary)
            {
                let imag = UIImagePickerController()
                imag.delegate = self
                imag.sourceType = UIImagePickerControllerSourceType.photoLibrary
                imag.allowsEditing = true
                self.present(imag, animated: true, completion: nil)
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Remove Photo", style: .default, handler: { (alert: UIAlertAction) in
            self.dataPrpPic = NSData()
            self.profileNameImaageGenerater()
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (alert: UIAlertAction) in
        }))
        
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    // ********** UIImagePickerControllerDelegate Methods ********** //
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        imgViewProPic.image = info["UIImagePickerControllerEditedImage"] as? UIImage
        
        dataPrpPic = UIImageJPEGRepresentation(imgViewProPic.image!, 0.5)! as NSData
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionUpdateProfile(_ sender: UIButton) {
        
        updateUserProfileWebServiceCall()
    }
    
    // *********** Get User Profile Service Call ********** //
    func getUserProfileWebServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Fetch"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Action":"SingleUser"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicMyProfile = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicMyProfile?["status"] as? String == "success"
                    {
                        let arrData = dicMyProfile?["data"] as! NSArray
                        let dicData = arrData[0] as! NSDictionary
                        self.txtFirstName.text = dicData["FirstName"] as? String
                        self.txtLastName.text = dicData["LastName"] as? String
                        self.txtCountry.text = dicData["Country"] as? String
                        self.txtState.text = dicData["State"] as? String
                        self.txtCity.text = dicData["City"] as? String
                        let strImgURL = dicData["ProfileImage"] as? String
                        
                        if strImgURL != ""
                        {
                            MBProgressHUD.showAdded(to: self.view, animated: true)
                            
                            
                            let imgURL = NSURL(string: strImgURL!)
                            
                            self.getDataFromUrl(url: imgURL! as URL) { data, response, error in
                                guard let data = data, error == nil else { return }
                                DispatchQueue.main.async() {
                                    self.imgViewProPic.image = UIImage(data: data)
                                    self.dataPrpPic = UIImageJPEGRepresentation(self.imgViewProPic.image!, 0.5)! as NSData
                                    MBProgressHUD.hide(for: self.view, animated: true)
                                }
                            }
                        }
                        else
                        {
                            let lblNameInitialize = UILabel()
                            lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
                            lblNameInitialize.textColor = UIColor.white
                            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
                            lblNameInitialize.textAlignment = NSTextAlignment.center
                            lblNameInitialize.backgroundColor = UIColor.gray
                            
                            UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
                            lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
                            self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
                            UIGraphicsEndImageContext()
                        }
                    }
                    else if dicMyProfile?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicMyProfile?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    
    // ********** Image URL Convert To Data ********** //
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
    
    
    // *********** Update User Profile Service Call ********** //
    
    func updateUserProfileWebServiceCall()
    {
        if txtFirstName.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Enter Your First Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if txtLastName.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Enter Your Last Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if txtCountry.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Enter Your Country.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if txtState.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Enter Your State.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if txtCity.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Enter Your City.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Profile"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            dataPrpPic = UIImageJPEGRepresentation(imgViewProPic.image!, 0.5)! as NSData
//            let strBase64proPic = dataPrpPic.base64EncodedString(options: .lineLength64Characters)
            let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"Update", "Val_Celebrityid":strUserID, "Val_Firstname":txtFirstName.text! as String, "Val_Lastname":txtLastName.text! as String, "Val_Country":txtCountry.text! as String, "Val_State":txtState.text! as String, "Val_City":txtCity.text! as String, "Val_ProfileImage":""]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    if value?.count == 0
                    {
                        if key == "Val_ProfileImage"
                        {
                            multipartFormData.append(self.dataPrpPic as Data, withName: "Val_ProfileImage", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                        }
                    }
                    else
                    {
                        multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                    }
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicUpdateResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicUpdateResponse?["status"] as? String == "success"
                        {
                            MBProgressHUD.showAdded(to: self.view, animated: true)
                            let dicUpdateProfile = dicUpdateResponse!["data"] as! NSDictionary
                            let strProPicURL = dicUpdateProfile["ProfileImage"] as! String
                            self.navigationController?.popViewController(animated: true)
                        }
                        else if dicUpdateResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
    }
    
    // ********** TextField Delegate Methods ********** //
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        if textField == txtFirstName || textField == txtLastName
        {
            if dataPrpPic.length == 0
            {
                let lblNameInitialize = UILabel()
                lblNameInitialize.frame.size = CGSize(width: 80.0, height: 80.0)
//                lblNameInitialize.font = UIFont(name: "Proxima Nova Bold", size: 30.0)
                lblNameInitialize.textColor = UIColor.black
                
                if txtFirstName.text?.count != 0 && txtLastName.text?.count == 0
                {
                    lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!)
                }
                else if txtLastName.text?.count != 0 && txtFirstName.text?.count == 0
                {
                    lblNameInitialize.text = String(self.txtLastName.text!.characters.first!)
                }
                else if txtFirstName.text?.count != 0 && txtLastName.text?.count != 0
                {
                    lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
                }
                else
                {
                    lblNameInitialize.text = String("heyoo")
                }
                
                lblNameInitialize.textAlignment = NSTextAlignment.center
                lblNameInitialize.backgroundColor = UIColor(red: 237/255, green: 237/255, blue: 237/255, alpha: 1)
                
                
                UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
                lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
                self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
                UIGraphicsEndImageContext()
            }
        }
    }
    
    func profileNameImaageGenerater()
    {
        let lblNameInitialize = UILabel()
        lblNameInitialize.frame.size = CGSize(width: 80.0, height: 80.0)
        lblNameInitialize.textColor = UIColor.black
        
        if txtFirstName.text?.count != 0 && txtLastName.text?.count == 0
        {
            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!)
        }
        else if txtLastName.text?.count != 0 && txtFirstName.text?.count == 0
        {
            lblNameInitialize.text = String(self.txtLastName.text!.characters.first!)
        }
        else if txtFirstName.text?.count != 0 && txtLastName.text?.count != 0
        {
            lblNameInitialize.text = String(self.txtFirstName.text!.characters.first!) + String(self.txtLastName.text!.characters.first!)
        }
        else
        {
            lblNameInitialize.text = String("heyoo")
        }
        lblNameInitialize.textAlignment = NSTextAlignment.center
        lblNameInitialize.backgroundColor = UIColor(red: 237/255, green: 237/255, blue: 237/255, alpha: 1)
        
        
        UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
        lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
        self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    
    
}














































