//
//  CeleAddAdminVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 24/03/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import Contacts
import ContactsUI

class CeleAddAdminVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var FetchContacts = [CNContact]()
    var arrContactListServer = NSMutableArray()
    var searchActive : Bool = false
    var filtered = NSArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.fetchContactMethod()
        
        txtSearch.addTarget(self, action: #selector(textFieldDidChange(textField:)), for: .editingChanged)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionClearSearch(_ sender: UIButton) {
        
        txtSearch.text = ""
        filtered = NSArray()
        txtSearch.resignFirstResponder()
        tblView.reloadData()
    }
    
    // ********** UITextField Delegate Methods ********** //
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        searchActive = true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        searchActive = true
    }
    
    @objc func textFieldDidChange(textField: UITextField)
    {
        filtered = arrContactListServer.filter({ (text) -> Bool in
            let dicContact = text as! NSDictionary
            let tmp: NSString = dicContact["FullName"] as! NSString
            let search = textField.text!
            let rang = tmp.range(of: search, options: .caseInsensitive)
            return rang.location != NSNotFound
        }) as! [NSDictionary] as NSArray
        
        if filtered.count == 0
        {
            searchActive = false
        }
        else
        {
            searchActive = true
        }
        tblView.reloadData()
    }
    
    // ********** UITableview Delegate And DataSource Methods ********** //
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if searchActive
        {
            if filtered.count == 0
            {
                return arrContactListServer.count
            }
            else
            {
                return filtered.count
            }
        }
        else
        {
            return arrContactListServer.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! CeleAddAdminTblCell
        
        var dicContact = NSDictionary()
        if searchActive
        {
            if filtered.count == 0
            {
                dicContact = arrContactListServer[indexPath.row] as! NSDictionary
            }
            else
            {
                dicContact = filtered[indexPath.row] as! NSDictionary
            }
        }
        else
        {
            dicContact = arrContactListServer[indexPath.row] as! NSDictionary
        }
        
        cell.imgViewUser.layer.cornerRadius = cell.imgViewUser.frame.size.height / 2
        
        cell.lblContactName.text = (dicContact["FullName"] as! String)
        cell.lblConNum.text = (dicContact["Mobile"] as! String)
        
        cell.btnAdd.layer.borderWidth = 1.0
        cell.btnAdd.layer.borderColor = UIColor.black.cgColor
        cell.btnAdd.tag = indexPath.row
        cell.btnAdd.addTarget(self, action: #selector(ActionButtonAdd(sender:)), for: .touchUpInside)
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 60
    }
    
    // ********** Contact Invite to Personal Assistante Method ********** //
    @objc func ActionButtonAdd(sender:UIButton) {
        
        var dicContact = NSDictionary()
        if searchActive
        {
            if filtered.count == 0
            {
                dicContact = arrContactListServer[sender.tag] as! NSDictionary
            }
            else
            {
                dicContact = filtered[sender.tag] as! NSDictionary
            }
        }
        else
        {
            dicContact = arrContactListServer[sender.tag] as! NSDictionary
        }
        
        
//        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"AddAssistant", "Val_Celebrityid":strUserID, "Val_Mobile": "\(dicContact["Mobile"] as! String)"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    let dicUpdateResponse = response.result.value as? [String: Any]
                    if dicUpdateResponse?["status"] as? String == "success"
                    {
                        sender.backgroundColor = UIColor(red: 255/255, green: 179/255, blue: 61/255, alpha: 1)
                        let alert = UIAlertController(title: nil, message: "Your Admin Added Successfully", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "DONE", style: UIAlertActionStyle.default, handler: { Void in
                            self.navigationController?.popViewController(animated: true)
                        }))
                        self.present(alert, animated: true, completion: nil)
                    }
                    else if dicUpdateResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    
    
    // ********** Contact Fetch Methods ********** //
    func fetchContactMethod()
    {
        FetchContacts = [CNContact]()
        
        let store = CNContactStore()
        store.requestAccess(for: .contacts, completionHandler: {
            granted, error in
            
            guard granted else {
                let alert = UIAlertController(title: "Can't access contact", message: "Please go to Settings -> heyoo to enable contact permission", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
                return
            }
            
            let keysToFetch = [CNContactFormatter.descriptorForRequiredKeys(for: .fullName), CNContactPhoneNumbersKey] as [Any]
            let request = CNContactFetchRequest(keysToFetch: keysToFetch as! [CNKeyDescriptor])
            
            do {
                try store.enumerateContacts(with: request) {
                    (contact, cursor) -> Void in
                    self.FetchContacts.append(contact)
                }
            } catch let error {
                print("Fetch contact error: \(error)")
            }
            
            DispatchQueue.main.async {
                
                self.arrContactListServer.removeAllObjects()
                
                for contact in self.FetchContacts
                {
                    if contact.phoneNumbers.count != 0
                    {
                        let fullName = CNContactFormatter.string(from: contact, style: .fullName) ?? "No Name"
                        let MobNumVar = (contact.phoneNumbers[0].value).value(forKey: "stringValue") as! String
                        
                        let dicContactTemp = NSMutableDictionary()
                        dicContactTemp.setValue(fullName, forKey: "FullName")
                        dicContactTemp.setValue(MobNumVar, forKey: "Mobile")
                        
                        self.arrContactListServer.add(dicContactTemp)
                    }
                }
                self.tblView.reloadData()
            }
        })
    }
    

    

}













































