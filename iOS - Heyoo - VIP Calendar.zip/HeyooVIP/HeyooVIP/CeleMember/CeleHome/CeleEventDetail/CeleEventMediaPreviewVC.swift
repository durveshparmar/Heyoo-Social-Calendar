//
//  CeleEventMediaPreviewVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 23/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit
import SDWebImage

class CeleEventMediaPreviewVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    @IBOutlet weak var collectView: UICollectionView!
    @IBOutlet weak var btnSave: UIButton!
    
    var arrAllMedia = NSMutableArray()
    var showIndex : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        let dicMediaTemp = arrAllMedia[0] as! NSDictionary
        if dicMediaTemp["Type"] as! String == "image"
        {
            btnSave.isHidden = false
        }
        else
        {
            btnSave.isHidden = true
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionBack(_ sender: UIButton) {
        
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
        UIView.setAnimationDuration(0.75)
        UIView.setAnimationTransition(UIViewAnimationTransition.flipFromLeft, for: (self.navigationController?.view)!, cache: false)
        UIView.commitAnimations()
        
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDelay(0.375)
        self.navigationController?.popViewController(animated: false)
        UIView.commitAnimations()
    }
    
    @IBAction func ActionSaveImage(_ sender: UIButton) {
        
        let dicMediaTemp = arrAllMedia[showIndex] as! NSDictionary
        let imgPhotoAlbum = UIImageView()
        imgPhotoAlbum.sd_setImage(with: URL(string : dicMediaTemp["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        UIImageWriteToSavedPhotosAlbum(imgPhotoAlbum.image!, nil, nil, nil)
    }
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrAllMedia.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellImage : CeleEventMediaCollectCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellImage", for: indexPath) as! CeleEventMediaCollectCell
        
        let dicMediaTemp = arrAllMedia[indexPath.item] as! NSDictionary
        if dicMediaTemp["Type"] as! String == "image"
        {
            cellImage.imgMediaPlayIcon.isHidden = true
            cellImage.imgViewImage.sd_setImage(with: URL(string : dicMediaTemp["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        }
        else
        {
            cellImage.imgMediaPlayIcon.isHidden = false
            let strVideo = dicMediaTemp["url"] as! String
            let videoURL = NSURL(string: strVideo)
            DispatchQueue.global(qos: .background).async {
                let image = self.thumbnailForVideoAtURL(url: videoURL!)
                
                DispatchQueue.main.async {
                    cellImage.imgViewImage.image = image
                }
            }
        }
        
        return cellImage
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectView.frame.size.width, height: collectView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let dicMediaTemp = arrAllMedia[indexPath.item] as! NSDictionary
        if dicMediaTemp["Type"] as! String == "image"
        {
            
        }
        else
        {
            let strVideo = dicMediaTemp["url"] as! String
            let videoURL = URL(string: strVideo)
            let player = AVPlayer(url: videoURL!)
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
        }
    }
    
    
    private func thumbnailForVideoAtURL(url: NSURL) -> UIImage? {
        
        let asset = AVAsset(url: url as URL)
        let assetImageGenerator = AVAssetImageGenerator(asset: asset)
        
        var time = asset.duration
        time.value = min(time.value, 2)
        
        do {
            let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
            
        } catch {
            return nil
        }
    }
    
    // ********** UIScrollViewDelegate Methods **********//
    
    func scrollViewDidScroll(_ scrollView: UIScrollView)
    {
        let currentIndex : Int = Int(self.collectView.contentOffset.x / self.collectView.frame.size.width)
        showIndex = currentIndex
        let dicMediaTemp = arrAllMedia[currentIndex] as! NSDictionary
        if dicMediaTemp["Type"] as! String == "image"
        {
            btnSave.isHidden = false
        }
        else
        {
            btnSave.isHidden = true
        }
        
    }
    

}











































