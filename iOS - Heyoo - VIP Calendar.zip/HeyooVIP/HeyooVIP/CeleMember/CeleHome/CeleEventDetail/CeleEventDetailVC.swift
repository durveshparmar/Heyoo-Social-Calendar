//
//  CeleEventDetailVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 01/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import AVFoundation
import AVKit
import SDWebImage

class CeleEventDetailVC: UIViewController {
    @IBOutlet weak var viewCalendarName: UIView!
    @IBOutlet weak var viewEventMedia: UIView!
    @IBOutlet weak var viewEventLocation: UIView!
    @IBOutlet weak var viewCheckInOut: UIView!
    @IBOutlet weak var lblStartEndTime: UILabel!
    @IBOutlet weak var lblStartEndDate: UILabel!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var viewNave: UIView!
    @IBOutlet weak var lblEventLocation: UILabel!
    @IBOutlet weak var lblEventNotes: UILabel!
    @IBOutlet weak var lblMediaCount: UILabel!
    @IBOutlet weak var lblCalendarName: UILabel!
    @IBOutlet weak var viewCalCol: UIView!
    
    @IBOutlet weak var mediaImg1: UIImageView!
    @IBOutlet weak var mediaImg2: UIImageView!
    @IBOutlet weak var mediaImg3: UIImageView!
    @IBOutlet weak var mediaImg4: UIImageView!
    @IBOutlet weak var mediaImg5: UIImageView!
    @IBOutlet weak var mediaPlayICon1: UIImageView!
    @IBOutlet weak var mediaPlayICon2: UIImageView!
    @IBOutlet weak var mediaPlayICon3: UIImageView!
    @IBOutlet weak var mediaPlayICon4: UIImageView!
    @IBOutlet weak var mediaPlayICon5: UIImageView!
    @IBOutlet weak var imgViewCheckIn: UIImageView!
    @IBOutlet weak var imgViewCheckOut: UIImageView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var strEventID = String()
    
    var dicEventDetailData = NSDictionary()
    var arrEventImages = NSArray()
    var arrEventVideos = NSArray()
    var arrMediaTemp = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewCalCol.layer.cornerRadius = viewCalCol.frame.size.width / 2
        
        viewCalendarName.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalendarName.layer.shadowOpacity = 0.4
        viewCalendarName.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalendarName.layer.shadowRadius = 3
        
        viewEventMedia.layer.shadowColor = UIColor.lightGray.cgColor
        viewEventMedia.layer.shadowOpacity = 0.4
        viewEventMedia.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewEventMedia.layer.shadowRadius = 3
        
        viewEventLocation.layer.shadowColor = UIColor.lightGray.cgColor
        viewEventLocation.layer.shadowOpacity = 0.4
        viewEventLocation.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewEventLocation.layer.shadowRadius = 3
        
        viewCheckInOut.layer.shadowColor = UIColor.lightGray.cgColor
        viewCheckInOut.layer.shadowOpacity = 0.4
        viewCheckInOut.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCheckInOut.layer.shadowRadius = 3
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.eventDetailAPICall()
    }
    
    
    // ********** All Button Actions ********* //
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionEditEvent(_ sender: UIBarButtonItem) {
        
        let editEventVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleEditEventVC") as! CeleEditEventVC
        editEventVC.dicEventDetailPass = dicEventDetailData
        editEventVC.strIsPublishOrNot = "Publish"
        self.navigationController?.pushViewController(editEventVC, animated: true)
    }
    
    @IBAction func ActionMediaOpen(_ sender: UIButton) {
        
        if arrMediaTemp.count != 0
        {
            let imgPreviewVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleEventMediaPreviewVC") as! CeleEventMediaPreviewVC
            imgPreviewVC.arrAllMedia = arrMediaTemp
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationCurve(UIViewAnimationCurve.easeInOut)
            UIView.setAnimationDuration(0.75)
            self.navigationController?.pushViewController(imgPreviewVC, animated: false)
            UIView.setAnimationTransition(UIViewAnimationTransition.flipFromRight, for: (self.navigationController?.view)!, cache: false)
            UIView.commitAnimations()
        }
    }
    
    @IBAction func ActionCheckIn(_ sender: UIButton) {
        
        self.eventCheckInCheckOutAPICall(strAction: "2")
    }
    
    @IBAction func ActionCheckOut(_ sender: UIButton) {
        
        self.eventCheckInCheckOutAPICall(strAction: "3")
    }
    
    // ********** Event Check-In Check-Out Api Call ********** //
    func eventCheckInCheckOutAPICall(strAction:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Action":strAction, "Val_Eventid":strEventID, "Val_Celebrityid":strUserID, "Action":"TakeAction"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        let dicEventResponse = response.result.value as? [String: Any]
                        MBProgressHUD.hide(for: self.view, animated: true)
                        if dicEventResponse?["status"] as? String == "success"
                        {
                            if strAction == "2" {
                                
                                self.imgViewCheckIn.image = #imageLiteral(resourceName: "iconCheckBoxOrange")
                                self.imgViewCheckOut.image = #imageLiteral(resourceName: "iconCheckBoxBlack")
                            }
                            else {
                                
                                self.imgViewCheckOut.image = #imageLiteral(resourceName: "iconCheckBoxOrange")
                                self.imgViewCheckIn.image = #imageLiteral(resourceName: "iconCheckBoxBlack")
                            }
                        }
                        else if dicEventResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    
    // ********** Gel Event Detail Api Call ********** //
    func eventDetailAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Val_Celebrityid":strUserID, "Action":"SingleEvent"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        let dicEventResponse = response.result.value as? [String: Any]
                        MBProgressHUD.hide(for: self.view, animated: true)
                        if dicEventResponse?["status"] as? String == "success"
                        {
                            let arrEventDetailData = dicEventResponse?["data"] as! NSArray
                            self.dicEventDetailData = arrEventDetailData[0] as! NSDictionary
                            self.allDataSetOnScreen()
                        }
                        else if dicEventResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** All Data Set Methods ********** //
    func allDataSetOnScreen()
    {
        let inFormatter = DateFormatter()
        inFormatter.dateFormat = "HH:mm:ss"
        let outFormatter = DateFormatter()
        outFormatter.dateFormat = "hh:mma"
        
        let inStartTime = dicEventDetailData["StartTime"] as! String
        let dateTimeStart = inFormatter.date(from: inStartTime)!
        let inEndTime = dicEventDetailData["EndTime"] as! String
        let dateTimeEnd = inFormatter.date(from: inEndTime)!
        
        if dicEventDetailData["AllDay"] as! String == "2"
        {
            lblStartEndTime.text = "Today"
        }
        else
        {
            lblStartEndTime.text = "\(outFormatter.string(from: dateTimeStart)) To \(outFormatter.string(from: dateTimeEnd))"
        }
        
        let inDateFormatter = DateFormatter()
        inDateFormatter.dateFormat = "yyyy-MM-dd"
        let outDateFormatter = DateFormatter()
        outDateFormatter.dateFormat = "MMM dd, yyyy"
        
        let inStartDate = dicEventDetailData["StartDate"] as! String
        let dateDateStart = inDateFormatter.date(from: inStartDate)!
        let inEndDate = dicEventDetailData["EndDate"] as! String
        let dateDateEnd = inDateFormatter.date(from: inEndDate)!
        
        lblStartEndDate.text = "\(outDateFormatter.string(from: dateDateStart)) To \(outDateFormatter.string(from: dateDateEnd))"
        lblEventName.text = dicEventDetailData["Title"] as? String
        viewNave.backgroundColor = postEventColorInTableCell(strColor: dicEventDetailData["Color"] as! String)
        lblCalendarName.text = dicEventDetailData["CalendarName"] as? String
        lblEventLocation.text = dicEventDetailData["Location"] as? String
        lblEventNotes.text = dicEventDetailData["Notes"] as? String
        
        arrEventImages = dicEventDetailData["Images"] as! NSArray
        arrEventVideos = dicEventDetailData["Vidoes"] as! NSArray
        
        
        arrMediaTemp = NSMutableArray()
        for i in (0..<arrEventImages.count)
        {
            let strImgURLTemp = arrEventImages[i] as! String
            let dicImageTemp = NSMutableDictionary()
            dicImageTemp.setValue(strImgURLTemp, forKey: "url")
            dicImageTemp.setValue("image", forKey: "Type")

            arrMediaTemp.add(dicImageTemp)
        }

        for i in (0..<arrEventVideos.count)
        {
            let strVideoURLTemp = arrEventVideos[i] as! String
            let dicVideoTemp = NSMutableDictionary()
            dicVideoTemp.setValue(strVideoURLTemp, forKey: "url")
            dicVideoTemp.setValue("video", forKey: "Type")
            
            arrMediaTemp.add(dicVideoTemp)
        }
        lblMediaCount.isHidden = true
        let mediaCount = arrMediaTemp.count
        if mediaCount == 1
        {
            let dicMediaTemp = arrMediaTemp[0] as! NSDictionary
            if dicMediaTemp["Type"] as! String == "image"
            {
                mediaPlayICon1.isHidden = true
                mediaImg1.sd_setImage(with: URL(string : dicMediaTemp["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            }
            else
            {
                let strVideo = dicMediaTemp["url"] as! String
                let videoURL = NSURL(string: strVideo)
                DispatchQueue.global(qos: .background).async {
                    let image = self.thumbnailForVideoAtURL(url: videoURL!)

                    DispatchQueue.main.async {
                        self.mediaImg1.image = image
                    }
                }
                mediaPlayICon1.isHidden = false
            }
            mediaImg2.isHidden = true
            mediaImg3.isHidden = true
            mediaImg4.isHidden = true
            mediaImg5.isHidden = true

            mediaPlayICon2.isHidden = true
            mediaPlayICon3.isHidden = true
            mediaPlayICon4.isHidden = true
            mediaPlayICon5.isHidden = true

            lblMediaCount.isHidden = true
        }
        else if mediaCount == 2
        {
            let dicMedia1 = arrMediaTemp[0] as! NSDictionary
            if dicMedia1["Type"] as! String == "image"
            {
                mediaPlayICon2.isHidden = true
                mediaImg2.sd_setImage(with: URL(string : dicMedia1["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            }
            else
            {
                let strVideo = dicMedia1["url"] as! String
                let videoURL = NSURL(string: strVideo)
                DispatchQueue.global(qos: .background).async {
                    let image = self.thumbnailForVideoAtURL(url: videoURL!)

                    DispatchQueue.main.async {
                        self.mediaImg2.image = image
                    }
                }
                mediaPlayICon2.isHidden = false
            }

            let dicMedia2 = arrMediaTemp[1] as! NSDictionary
            if dicMedia2["Type"] as! String == "image"
            {
                mediaPlayICon3.isHidden = true
                mediaImg3.sd_setImage(with: URL(string : dicMedia2["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            }
            else
            {
                let strVideo = dicMedia2["url"] as! String
                let videoURL = NSURL(string: strVideo)
                DispatchQueue.global(qos: .background).async {
                    let image = self.thumbnailForVideoAtURL(url: videoURL!)

                    DispatchQueue.main.async {
                        self.mediaImg3.image = image
                    }
                }
                mediaPlayICon3.isHidden = false
            }
            mediaImg1.isHidden = true
            mediaImg4.isHidden = true
            mediaImg5.isHidden = true

            mediaPlayICon1.isHidden = true
            mediaPlayICon4.isHidden = true
            mediaPlayICon5.isHidden = true

            lblMediaCount.isHidden = true
        }
        else
        {
            if mediaCount != 0
            {
                let dicMedia1 = arrMediaTemp[0] as! NSDictionary
                if dicMedia1["Type"] as! String == "image"
                {
                    mediaPlayICon2.isHidden = true
                    mediaImg2.sd_setImage(with: URL(string : dicMedia1["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                }
                else
                {
                    let strVideo = dicMedia1["url"] as! String
                    let videoURL = NSURL(string: strVideo)
                    DispatchQueue.global(qos: .background).async {
                        let image = self.thumbnailForVideoAtURL(url: videoURL!)

                        DispatchQueue.main.async {
                            self.mediaImg2.image = image
                        }
                    }
                    mediaPlayICon2.isHidden = false
                }

                let dicMedia2 = arrMediaTemp[1] as! NSDictionary
                if dicMedia2["Type"] as! String == "image"
                {
                    mediaPlayICon4.isHidden = true
                    mediaImg4.sd_setImage(with: URL(string : dicMedia2["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                }
                else
                {

                    let strVideo = dicMedia2["url"] as! String
                    let videoURL = NSURL(string: strVideo)
                    DispatchQueue.global(qos: .background).async {
                        let image = self.thumbnailForVideoAtURL(url: videoURL!)

                        DispatchQueue.main.async {
                            self.mediaImg4.image = image
                        }
                    }
                    mediaPlayICon4.isHidden = false
                }

                let dicMedia3 = arrMediaTemp[2] as! NSDictionary
                if dicMedia3["Type"] as! String == "image"
                {
                    mediaPlayICon5.isHidden = true
                    mediaImg5.sd_setImage(with: URL(string : dicMedia3["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                }
                else
                {
                    let strVideo = dicMedia3["url"] as! String
                    let videoURL = NSURL(string: strVideo)
                    DispatchQueue.global(qos: .background).async {
                        let image = self.thumbnailForVideoAtURL(url: videoURL!)

                        DispatchQueue.main.async {
                            self.mediaImg5.image = image
                        }
                    }
                    mediaPlayICon5.isHidden = false
                }
                mediaImg1.isHidden = true
                mediaImg3.isHidden = true
                
                mediaPlayICon1.isHidden = true
                mediaPlayICon3.isHidden = true
            }else {
                mediaImg1.image = UIImage(named: "")
                mediaImg2.image = UIImage(named: "")
                mediaImg3.image = UIImage(named: "")
                mediaImg4.image = UIImage(named: "")
                mediaImg5.image = UIImage(named: "")
            }

            if mediaCount > 3
            {
                lblMediaCount.isHidden = false
                lblMediaCount.text = "+\(mediaCount-3)"
                lblMediaCount.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            }
            
        }
        
        if dicEventDetailData["CheckedStatus"] as! String == "2" {
            
            imgViewCheckIn.image = #imageLiteral(resourceName: "iconCheckBoxOrange")
        }
        else if dicEventDetailData["CheckedStatus"] as! String == "3" {
            
            imgViewCheckOut.image = #imageLiteral(resourceName: "iconCheckBoxOrange")
        }
        
    }
    
    private func thumbnailForVideoAtURL(url: NSURL) -> UIImage? {
        
        let asset = AVAsset(url: url as URL)
        let assetImageGenerator = AVAssetImageGenerator(asset: asset)
        
        var time = asset.duration
        time.value = min(time.value, 2)
        
        do {
            let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
            
        } catch {
            return nil
        }
    }
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
 
}



































