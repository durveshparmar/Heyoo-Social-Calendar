//
//  CeleEditEventVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 24/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class CeleEditEventVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var viewTitle: UIView!
    @IBOutlet weak var viewDateAndTime: UIView!
    @IBOutlet weak var viewMedia: UIView!
    @IBOutlet weak var viewLocation: UIView!
    @IBOutlet weak var btnPublish: UIButton!
    @IBOutlet weak var btnSaveAsDraft: UIButton!
    @IBOutlet weak var viewNav: UIView!
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var txtEventName: UITextField!
    @IBOutlet weak var collectEventColor: UICollectionView!
    @IBOutlet weak var txtEventLocation: UITextField!
    @IBOutlet weak var txtEventNotes: UITextField!
    @IBOutlet weak var imgViewAllDay: UIImageView!
    @IBOutlet weak var imgViewIconStartClock: UIImageView!
    @IBOutlet weak var imgViewIconEndClock: UIImageView!
    @IBOutlet weak var lblStartTime: UILabel!
    @IBOutlet weak var lblEndTime: UILabel!
    @IBOutlet weak var datePickerSelectDate: UIDatePicker!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var viewDatePickerBack: UIView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    var arrColor = NSArray()
    var strSelectColor = String()
    var strSelectTick = String()
    var strAllDay = String()
    var startDate = Date()
    var endDate = Date()
    var today = Date()
    var isStartDate = Bool()
    
    
    
    var dicEventDetailPass = NSDictionary()
    var strIsPublishOrNot = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        AllBackViewMethods()
        
        if strIsPublishOrNot == "Publish"
        {
            btnPublish.setTitle("Update", for: .normal)
            btnSaveAsDraft.isHidden = true
        }
        else
        {
            btnPublish.setTitle("Publish", for: .normal)
            btnSaveAsDraft.isHidden = false
        }
        
        arrColor = [customColor.color1, customColor.color2, customColor.color3, customColor.color4, customColor.color5, customColor.color6, customColor.color7]
        
        self.allDataSetInUI()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    // ********** All Button Action ********** //
    @IBAction func ActionDatePickerDone(_ sender: UIButton) {
        
        viewDatePickerBack.isHidden = true
    }
    
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionViewMedia(_ sender: UIButton) {
        
        let mediaVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleEditEventMediaListVC") as! CeleEditEventMediaListVC
        mediaVC.strEventID = dicEventDetailPass["EventID"] as! String
        mediaVC.strUserIDOwner = dicEventDetailPass["UserID"] as! String
        mediaVC.dicEventDetailPass = dicEventDetailPass
        self.navigationController?.pushViewController(mediaVC, animated: true)
    }
    
    @IBAction func ActionAllDay(_ sender: UIButton) {
        
        if strAllDay == "1"
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxOrange")
            strAllDay = "2"
            
            datePickerSelectDate.datePickerMode = .date
            imgViewIconStartClock.isHidden = true
            imgViewIconEndClock.isHidden = true
            lblStartTime.isHidden = true
            lblEndTime.isHidden = true
        }
        else
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxBlack")
            strAllDay = "1"
            
            datePickerSelectDate.datePickerMode = .dateAndTime
            imgViewIconStartClock.isHidden = false
            imgViewIconEndClock.isHidden = false
            lblStartTime.isHidden = false
            lblEndTime.isHidden = false
        }
    }
    
    @IBAction func ActionStartDateSelect(_ sender: UIButton) {
        
        isStartDate = true
        
        viewDatePickerBack.isHidden = false
        datePickerSelectDate.minimumDate = today
        
        if startDate > today
        {
            datePickerSelectDate.date = startDate
        }
        else
        {
            datePickerSelectDate.date = today
        }
    }
    
    @IBAction func ActionEndDateSelect(_ sender: UIButton) {
        
        isStartDate = false
        viewDatePickerBack.isHidden = false
        
        datePickerSelectDate.datePickerMode = UIDatePickerMode.dateAndTime
        if startDate > endDate
        {
            //            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
            datePickerSelectDate.minimumDate = startDate
            datePickerSelectDate.date = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
        }
        else
        {
            //            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
            datePickerSelectDate.minimumDate = startDate
            datePickerSelectDate.date = endDate
        }
    }
    
    @IBAction func ActionPublish(_ sender: UIButton) {
        
        self.updatePublishAndDraftEventAPICall(strEventType: "Publish")
    }
    
    @IBAction func ActionSaveAsDraft(_ sender: UIButton) {
        
        self.updatePublishAndDraftEventAPICall(strEventType: "Draft")
    }
    
    // ********** UIDatePickerView Methods ********** //
    @IBAction func startDatePickerHandle(_ sender: UIDatePicker) {
        
        if isStartDate == true
        {
            lblStartDate.text = self.dateFormatter.string(from: sender.date)
            lblStartTime.text = self.timeFormatter.string(from: sender.date)
            
            startDate = sender.date
            
            let startTimeInterval = Int(startDate.timeIntervalSinceReferenceDate)
            let endTimeInterval = Int(endDate.timeIntervalSinceReferenceDate)
            
            if startTimeInterval > endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else if startTimeInterval == endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
        }
        else
        {
            endDate = sender.date
            lblEndDate.text = self.dateFormatter.string(from: endDate)
            lblEndTime.text = self.timeFormatter.string(from: endDate)
        }
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    fileprivate lazy var timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        return formatter
    }()
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrColor.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellColor : CeleCollectColorCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CeleCollectColorCell
        
        cellColor.viewColor.backgroundColor = arrColor[indexPath.item] as? UIColor
        
        if strSelectTick == "\(indexPath.item)"
        {
            cellColor.imgViewTick.isHidden = false
        }
        else
        {
            cellColor.imgViewTick.isHidden = true
        }
        
        return cellColor
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: collectEventColor.frame.size.height, height: collectEventColor.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        viewNav.backgroundColor = arrColor[indexPath.item] as? UIColor
        strSelectColor = "\(indexPath.item+1)"
        strSelectTick = "\(indexPath.row)"
        collectEventColor.reloadData()
    }
    
    
    
    
    // ********** All Backview Shadow Method ********** //
    func AllBackViewMethods()
    {
        viewTitle.layer.shadowColor = UIColor.lightGray.cgColor
        viewTitle.layer.shadowOpacity = 0.4
        viewTitle.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewTitle.layer.shadowRadius = 3
        
        viewDateAndTime.layer.shadowColor = UIColor.lightGray.cgColor
        viewDateAndTime.layer.shadowOpacity = 0.4
        viewDateAndTime.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewDateAndTime.layer.shadowRadius = 3
        
        viewMedia.layer.shadowColor = UIColor.lightGray.cgColor
        viewMedia.layer.shadowOpacity = 0.4
        viewMedia.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewMedia.layer.shadowRadius = 3
        
        viewLocation.layer.shadowColor = UIColor.lightGray.cgColor
        viewLocation.layer.shadowOpacity = 0.4
        viewLocation.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLocation.layer.shadowRadius = 3
        
        btnPublish.layer.shadowColor = UIColor.lightGray.cgColor
        btnPublish.layer.shadowOpacity = 0.4
        btnPublish.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPublish.layer.shadowRadius = 5.0
        
        btnSaveAsDraft.layer.shadowColor = UIColor.lightGray.cgColor
        btnSaveAsDraft.layer.shadowOpacity = 0.4
        btnSaveAsDraft.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnSaveAsDraft.layer.shadowRadius = 5.0
    }
    
    // ********** All Data Set In UI ********** //
    func allDataSetInUI()
    {
        // -------------- Title And Color Set -------------------
        viewNav.backgroundColor = postEventColorInTableCell(strColor: dicEventDetailPass["Color"] as! String)
        lblEventName.text = dicEventDetailPass["Title"] as? String
        txtEventName.text = dicEventDetailPass["Title"] as? String
        
        strSelectColor = "\(dicEventDetailPass["Color"] as! String)"
        let strSelColorTemp = dicEventDetailPass["Color"] as! String
        let selColor:Int = Int(strSelColorTemp)!
        strSelectTick = "\(selColor-1)"
        collectEventColor.reloadData()
        
        
        // --------------- Location View Set -------------------
        txtEventLocation.text = dicEventDetailPass["Location"] as? String
        txtEventNotes.text = dicEventDetailPass["Notes"] as? String
        
        
        // --------------- Date Selection View Set --------------
        strAllDay = dicEventDetailPass["AllDay"] as! String
        if strAllDay == "2"
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxOrange")
            
            datePickerSelectDate.datePickerMode = .date
            imgViewIconStartClock.isHidden = true
            imgViewIconEndClock.isHidden = true
            lblStartTime.isHidden = true
            lblEndTime.isHidden = true
        }
        else
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxBlack")
            
            datePickerSelectDate.datePickerMode = .dateAndTime
            imgViewIconStartClock.isHidden = false
            imgViewIconEndClock.isHidden = false
            lblStartTime.isHidden = false
            lblEndTime.isHidden = false
        }
        
        
        let inFormatter = DateFormatter()
        inFormatter.dateFormat = "HH:mm:ss"
        let outFormatter = DateFormatter()
        outFormatter.dateFormat = "hh:mm a"
        
        let inStartTime = dicEventDetailPass["StartTime"] as! String
        let dateTimeStart = inFormatter.date(from: inStartTime)!
        let inEndTime = dicEventDetailPass["EndTime"] as! String
        let dateTimeEnd = inFormatter.date(from: inEndTime)!
        lblStartTime.text = outFormatter.string(from: dateTimeStart)
        lblEndTime.text = outFormatter.string(from: dateTimeEnd)
        
        let inDateFormatter = DateFormatter()
        inDateFormatter.dateFormat = "yyyy-MM-dd"
        let outDateFormatter = DateFormatter()
        outDateFormatter.dateFormat = "EEE, MMM dd, yyyy" //"MMM dd, yyyy"
        
        let inStartDate = dicEventDetailPass["StartDate"] as! String
        let dateDateStart = inDateFormatter.date(from: inStartDate)!
        let inEndDate = dicEventDetailPass["EndDate"] as! String
        let dateDateEnd = inDateFormatter.date(from: inEndDate)!
        lblStartDate.text = outDateFormatter.string(from: dateDateStart)
        lblEndDate.text = outDateFormatter.string(from: dateDateEnd)
        
        print(dicEventDetailPass)
        
        
        let arrStartDate = inStartDate.components(separatedBy: "-")
        let arrStartTime = inStartTime.components(separatedBy: ":")
        
        var startDateComponent = DateComponents()
        startDateComponent.year = Int(arrStartDate[0])
        startDateComponent.month = Int(arrStartDate[1])
        startDateComponent.day = Int(arrStartDate[2])
        startDateComponent.hour = Int(arrStartTime[0])
        startDateComponent.minute = Int(arrStartTime[1])
        startDateComponent.second = Int(arrStartTime[2])
        
        startDate = Calendar(identifier: .gregorian).date(from: startDateComponent)!
        print(startDate)
        
        let arrEndDate = inEndDate.components(separatedBy: "-")
        let arrEndTime = inEndTime.components(separatedBy: ":")
        
        var endDateComponent = DateComponents()
        endDateComponent.year = Int(arrEndDate[0])
        endDateComponent.month = Int(arrEndDate[1])
        endDateComponent.day = Int(arrEndDate[2])
        endDateComponent.hour = Int(arrEndTime[0])
        endDateComponent.minute = Int(arrEndTime[1])
        endDateComponent.second = Int(arrEndTime[2])
        
        endDate = Calendar(identifier: .gregorian).date(from: endDateComponent)!
        
    }
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    // ********** Update Publish And Draft Event WebService Call ********** //
    func updatePublishAndDraftEventAPICall(strEventType: String)
    {
        print(strSelectColor)
        print(txtEventName.text as Any)
        print("Start Date = \(String(describing: lblStartDate.text))")
        print("Start Time = \(String(describing: lblStartTime.text))")
        print("End Date = \(String(describing: lblEndDate.text))")
        print("End Time = \(String(describing: lblEndTime.text))")
        print("Location = \(String(describing: txtEventLocation.text))")
        print("Notes = \(String(describing: txtEventNotes.text))")
        
        
        if txtEventName.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Enter Event Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if strSelectColor.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Choose Event Color.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = dicEventDetailPass["UserID"] as? String
            let strEventID = dicEventDetailPass["EventID"] as? String
            
            let strStartDateServer = self.dateServerFormatter.string(from: startDate)
            let strStartTimeServer = self.timeServerFormatter.string(from: startDate)
            
            let strEndDateServer = self.dateServerFormatter.string(from: endDate)
            let strEndTimeServer = self.timeServerFormatter.string(from: endDate)
            
            var strEventStatus = String()
            if strEventType == "Publish"
            {
                strEventStatus = "2"
            }
            else
            {
                strEventStatus = "1"
            }
            
            var strAction = String()
            if strIsPublishOrNot == "Publish"
            {
                strAction = "Update"
            }
            else
            {
                strAction = "Publish"
            }
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":strAction, "Val_Eventid":strEventID, "Val_Celebrityid":strUserID, "Val_Title":txtEventName.text! as String, "Val_Color":strSelectColor, "Val_Startdate":strStartDateServer, "Val_Starttime":strStartTimeServer, "Val_EndDate":strEndDateServer, "Val_Endtime":strEndTimeServer, "Val_Allday":strAllDay, "Val_Location":txtEventLocation.text! as String, "Val_Notes":txtEventNotes.text! as String, "Val_Status":strEventStatus]
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        let dicUpdateResponse = response.result.value as? [String: Any]
                        MBProgressHUD.hide(for: self.view, animated: true)
                        if dicUpdateResponse?["status"] as? String == "success"
                        {
                            self.navigationController?.popViewController(animated: true)
                        }
                        else if dicUpdateResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** ServerSide Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "YYYY-MM-dd"
        return formatter
    }()
    
    fileprivate lazy var timeServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()
}













































