//
//  CeleEditEventMediaListVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 24/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import AVFoundation
import Alamofire
import SDWebImage

class CeleEditEventMediaListVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    @IBOutlet weak var collectView: UICollectionView!
    @IBOutlet weak var viewNav: UIView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    var strEventID = String()
    var strUserIDOwner = String()
    var dicEventDetailPass = NSDictionary()

    var arrAllMedia = NSMutableArray()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        viewNav.backgroundColor = postEventColorInTableCell(strColor: dicEventDetailPass["Color"] as! String)
        
        self.eventMediaListAPICall()
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        self.eventMediaListAPICall()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    // ********** All Button Action ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionAddMedia(_ sender: UIBarButtonItem) {
        
        let imag = UIImagePickerController()
        imag.delegate = self
        imag.sourceType = UIImagePickerControllerSourceType.photoLibrary
        imag.mediaTypes = ["public.image", "public.movie"]
        imag.allowsEditing = false
        self.present(imag, animated: true, completion: nil)
    }
    
    @objc func ActionDeleteMediaButton(sender: UIButton!)
    {
        let info = arrAllMedia.object(at: sender.tag) as! NSDictionary
        
        let strMediaURL: String = info["url"] as! String
        let arrSplitMedia = strMediaURL.components(separatedBy: "/") as NSArray
        
        self.eventMediaDeleteAPICall(strEventID: strEventID, strUserID: strUserIDOwner, strMediaName: arrSplitMedia.lastObject as! String)
    }
    
    // ********** UIImagePickerControllerDelegate Methods ********** //
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        let strMediaType = info[UIImagePickerControllerMediaType] as? String
        
        if strMediaType == "public.image"
        {
            let image = info[UIImagePickerControllerOriginalImage]
            let imageData = UIImageJPEGRepresentation(image! as! UIImage, 0.5)! as NSData
            self.addEventMediaAPICall(strMediaType: "image", mediaData: imageData, ThumbnailData: imageData)
        }
        else
        {
            let videoURL = info[UIImagePickerControllerMediaURL] as? NSURL
            let videoData = NSData(contentsOf: videoURL! as URL)! as NSData
            
            let image = self.thumbnailForVideoAtURL(url: videoURL!)
            let videoThumbData = UIImageJPEGRepresentation(image! , 0.5)! as NSData
            self.addEventMediaAPICall(strMediaType: "video", mediaData: videoData, ThumbnailData: videoThumbData)
        }
        
        self.dismiss(animated: true) {
            
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrAllMedia.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellMedia : CeleCollectNewEventMediaCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellMedia", for: indexPath) as! CeleCollectNewEventMediaCell
        let info = arrAllMedia.object(at: indexPath.item) as! NSDictionary
        
        if info["Type"] as! String == "image"
        {
            cellMedia.imgView.sd_setImage(with: URL(string : info["url"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
            cellMedia.imgViewPlayIcon.isHidden = true
        }
        else
        {
            cellMedia.imgViewPlayIcon.isHidden = false
            let strVideo = info["url"] as! String
            let videoURL = NSURL(string: strVideo)
            DispatchQueue.global(qos: .background).async {
                let image = self.thumbnailForVideoAtURL(url: videoURL!)
                
                DispatchQueue.main.async {
                    cellMedia.imgView.image = image
                }
            }
        }
        
        cellMedia.btnDelete.tag = indexPath.item
        cellMedia.btnDelete.addTarget(self, action: #selector(self.ActionDeleteMediaButton(sender:)), for: .touchUpInside)
        
        return cellMedia
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let width = collectView.frame.size.width / 3
        return CGSize(width: width-15, height: width-15)
    }
    
    private func thumbnailForVideoAtURL(url: NSURL) -> UIImage? {
        
        let asset = AVAsset(url: url as URL)
        let assetImageGenerator = AVAssetImageGenerator(asset: asset)
        
        var time = asset.duration
        time.value = min(time.value, 2)
        
        do {
            let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
            
        } catch {
            return nil
        }
    }
    
    // ********** Add Event Media API Call ********** //
    func addEventMediaAPICall(strMediaType:String, mediaData:NSData, ThumbnailData:NSData)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            var strMediaKey = String()
            var strMediaThumbKey = String()
            
            if strMediaType == "image"
            {
                strMediaKey = "Val_Images"
                strMediaThumbKey = "Val_Imagesthumbs"
            }
            
            if strMediaType == "video"
            {
                strMediaKey = "Val_Videos"
                strMediaThumbKey = "Val_Videosthumbs"
            }
//            "Val_Imagesthumbs":"", "Val_Videosthumbs":""
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"AddMedia", "Val_Eventid":strEventID, "Val_Celebrityid":strUserIDOwner, strMediaKey:""]
            
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    if value.count == 0
                    {
                        if strMediaType == "image"
                        {
                            multipartFormData.append(mediaData as Data, withName: "Val_Images", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType:"image/jpeg")
                            
                            
                            multipartFormData.append(ThumbnailData as Data, withName: "Val_Imagesthumbs", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType:"image/jpeg")
                        }
                        
                        if strMediaType == "video"
                        {
                            multipartFormData.append(mediaData as Data, withName: "Val_Videos", fileName: "\(Date().timeIntervalSince1970).mp4", mimeType:"video/mp4")
                            
                            multipartFormData.append(ThumbnailData as Data, withName: "Val_Videosthumbs", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType:"image/jpeg")
                        }
                    }
                    else
                    {
                        multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                        
                    }
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        let dicAddMediaResponse = response.result.value as? [String: Any]
                        MBProgressHUD.hide(for: self.view, animated: true)
                        if dicAddMediaResponse?["status"] as? String == "success"
                        {
                            let dicEventMediaData = dicAddMediaResponse?["data"] as! NSDictionary
                            
                            let arrEventImages = dicEventMediaData["Images"] as! NSArray
                            let arrEventVideos = dicEventMediaData["Vidoes"] as! NSArray
                            
                            
                            self.arrAllMedia = NSMutableArray()
                            for i in (0..<arrEventImages.count)
                            {
                                let strImgURLTemp = arrEventImages[i] as! String
                                let dicImageTemp = NSMutableDictionary()
                                dicImageTemp.setValue(strImgURLTemp, forKey: "url")
                                dicImageTemp.setValue("image", forKey: "Type")
                                
                                self.arrAllMedia.add(dicImageTemp)
                            }
                            
                            for i in (0..<arrEventVideos.count)
                            {
                                let strVideoURLTemp = arrEventVideos[i] as! String
                                let dicVideoTemp = NSMutableDictionary()
                                dicVideoTemp.setValue(strVideoURLTemp, forKey: "url")
                                dicVideoTemp.setValue("video", forKey: "Type")
                                
                                self.arrAllMedia.add(dicVideoTemp)
                            }
                            
                            self.collectView.reloadData()
                        }
                        else if dicAddMediaResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicAddMediaResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    
    // *********** Delete Event Media API Call *********** //
    func eventMediaDeleteAPICall(strEventID:String, strUserID:String, strMediaName:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Val_Celebrityid":strUserID, "Val_MediaFile":strMediaName, "Action":"DeleteMedia"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicEventMediaListResponse = response.result.value as? [String: Any]
                        MBProgressHUD.hide(for: self.view, animated: true)
                        self.collectView.reloadData()
                        if dicEventMediaListResponse?["status"] as? String == "success"
                        {
                            let dicEventMediaData = dicEventMediaListResponse?["data"] as! NSDictionary
                            
                            let arrEventImages = dicEventMediaData["Images"] as! NSArray
                            let arrEventVideos = dicEventMediaData["Vidoes"] as! NSArray
                            
                            
                            self.arrAllMedia = NSMutableArray()
                            for i in (0..<arrEventImages.count)
                            {
                                let strImgURLTemp = arrEventImages[i] as! String
                                let dicImageTemp = NSMutableDictionary()
                                dicImageTemp.setValue(strImgURLTemp, forKey: "url")
                                dicImageTemp.setValue("image", forKey: "Type")
                                
                                self.arrAllMedia.add(dicImageTemp)
                                
                            }
                            
                            for i in (0..<arrEventVideos.count)
                            {
                                let strVideoURLTemp = arrEventVideos[i] as! String
                                let dicVideoTemp = NSMutableDictionary()
                                dicVideoTemp.setValue(strVideoURLTemp, forKey: "url")
                                dicVideoTemp.setValue("video", forKey: "Type")
                                
                                self.arrAllMedia.add(dicVideoTemp)
                            }
                            self.collectView.reloadData()
                            
                            
                        }
                        else if dicEventMediaListResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventMediaListResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    
    
    // ********** Get Event Media List API Call ********** //
    
    func eventMediaListAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Action":"GetEventMedia"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        let dicEventMediaListResponse = response.result.value as? [String: Any]
                        MBProgressHUD.hide(for: self.view, animated: true)
                        if dicEventMediaListResponse?["status"] as? String == "success"
                        {
                            let arrEventMediaData = dicEventMediaListResponse?["data"] as! NSArray
                            let dicEventMediaData = arrEventMediaData[0] as! NSDictionary
                            
                            let arrEventImages = dicEventMediaData["Images"] as! NSArray
                            let arrEventVideos = dicEventMediaData["Vidoes"] as! NSArray
                            
                            
                            self.arrAllMedia = NSMutableArray()
                            for i in (0..<arrEventImages.count)
                            {
                                let strImgURLTemp = arrEventImages[i] as! String
                                let dicImageTemp = NSMutableDictionary()
                                dicImageTemp.setValue(strImgURLTemp, forKey: "url")
                                dicImageTemp.setValue("image", forKey: "Type")
                                
                                self.arrAllMedia.add(dicImageTemp)
                            }
                            
                            for i in (0..<arrEventVideos.count)
                            {
                                let strVideoURLTemp = arrEventVideos[i] as! String
                                let dicVideoTemp = NSMutableDictionary()
                                dicVideoTemp.setValue(strVideoURLTemp, forKey: "url")
                                dicVideoTemp.setValue("video", forKey: "Type")
                                
                                self.arrAllMedia.add(dicVideoTemp)
                            }
                            self.collectView.reloadData()
                            
                        }
                        else if dicEventMediaListResponse?["status"] as? String == "error"
                        {
                            self.arrAllMedia = NSMutableArray()
                            self.collectView.reloadData()
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventMediaListResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    

    

}














































