//
//  CeleEventMediaCollectCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 23/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class CeleEventMediaCollectCell: UICollectionViewCell {
    @IBOutlet weak var imgViewImage: UIImageView!
    @IBOutlet weak var imgMediaPlayIcon: UIImageView!
    
}
