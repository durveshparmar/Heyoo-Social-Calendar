//
//  CeleNewEventVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 01/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import AVFoundation
import Alamofire

class CeleNewEventVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    @IBOutlet weak var viewNavBackground: UIView!
    @IBOutlet weak var viewEventNameBack: UIView!
    @IBOutlet weak var viewTimeSelect: UIView!
    @IBOutlet weak var viewMediaPlaceholder: UIView!
    @IBOutlet weak var viewLocation: UIView!
    @IBOutlet weak var viewMediaBack: UIView!
    @IBOutlet weak var viewDatePickerBack: UIView!
    @IBOutlet weak var collectEventColor: UICollectionView!
    @IBOutlet weak var collectMedia: UICollectionView!
    @IBOutlet weak var btnEventMedia: UIButton!
    @IBOutlet weak var btnPublishEvent: UIButton!
    @IBOutlet weak var btnSaveAsDraftEvent: UIButton!
    @IBOutlet weak var datePickerSelectDate: UIDatePicker!
    @IBOutlet weak var lblStartDate: UILabel!
    @IBOutlet weak var lblStartTime: UILabel!
    @IBOutlet weak var lblEndDate: UILabel!
    @IBOutlet weak var lblEndTime: UILabel!
    @IBOutlet weak var txtEventTitle: UITextField!
    @IBOutlet weak var txtLocation: UITextField!
    @IBOutlet weak var txtNotes: UITextField!
    @IBOutlet weak var imgViewAllDay: UIImageView!
    @IBOutlet weak var imgViewIconStartClock: UIImageView!
    @IBOutlet weak var imgViewIconEndClock: UIImageView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    
    
    
    var arrColor = NSArray()
    var arrMediaData = NSMutableArray()
    var isStartDate = Bool()
    var today = Date()
    var startDate = Date()
    var endDate = Date()
    
    var strEventSelectColor = String()
    var strSelectTick = String()
    var strAllDay = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        viewEventNameBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewEventNameBack.layer.shadowOpacity = 0.4
        viewEventNameBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewEventNameBack.layer.shadowRadius = 3
        
        viewTimeSelect.layer.shadowColor = UIColor.lightGray.cgColor
        viewTimeSelect.layer.shadowOpacity = 0.4
        viewTimeSelect.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewTimeSelect.layer.shadowRadius = 3
        
        viewMediaBack.layer.shadowColor = UIColor.lightGray.cgColor
        viewMediaBack.layer.shadowOpacity = 0.4
        viewMediaBack.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewMediaBack.layer.shadowRadius = 3
        
        viewLocation.layer.shadowColor = UIColor.lightGray.cgColor
        viewLocation.layer.shadowOpacity = 0.4
        viewLocation.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewLocation.layer.shadowRadius = 3
        
        btnPublishEvent.layer.shadowColor = UIColor.lightGray.cgColor
        btnPublishEvent.layer.shadowOpacity = 0.4
        btnPublishEvent.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPublishEvent.layer.shadowRadius = 5.0
        
        btnSaveAsDraftEvent.layer.shadowColor = UIColor.lightGray.cgColor
        btnSaveAsDraftEvent.layer.shadowOpacity = 0.4
        btnSaveAsDraftEvent.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnSaveAsDraftEvent.layer.shadowRadius = 5.0
        
        
        arrColor = [customColor.color1, customColor.color2, customColor.color3, customColor.color4, customColor.color5, customColor.color6, customColor.color7]
        
        lblStartDate.text = self.dateFormatter.string(from: today)
        lblStartTime.text = self.timeFormatter.string(from: today)
        
        endDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: today)!
        lblEndDate.text = self.dateFormatter.string(from: endDate)
        lblEndTime.text = self.timeFormatter.string(from: endDate)
        
        strAllDay = "1"
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func ActionEventMedia(_ sender: UIButton) {
        
        let imag = UIImagePickerController()
        imag.delegate = self
        imag.sourceType = UIImagePickerControllerSourceType.photoLibrary
        imag.mediaTypes = ["public.image", "public.movie"]
        imag.allowsEditing = false
        self.present(imag, animated: true, completion: nil)
    }
    
    @IBAction func ActionStartDateSelect(_ sender: UIButton) {
        
        isStartDate = true
        
        viewDatePickerBack.isHidden = false
        datePickerSelectDate.minimumDate = today
        
        if startDate > today
        {
            datePickerSelectDate.date = startDate
        }
        else
        {
            datePickerSelectDate.date = today
        }
    }
    
    @IBAction func ActionEndDateSelect(_ sender: UIButton) {
        
        isStartDate = false
        viewDatePickerBack.isHidden = false
        
        datePickerSelectDate.datePickerMode = UIDatePickerMode.dateAndTime
        if startDate > endDate
        {
            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
            datePickerSelectDate.date = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
        }
        else
        {
            datePickerSelectDate.minimumDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: startDate)!
            datePickerSelectDate.date = endDate
        }
    }
    
    @IBAction func ActionDatePickerDone(_ sender: UIButton) {
        
        viewDatePickerBack.isHidden = true
    }
    
    @IBAction func ActionPublishEvent(_ sender: UIButton) {
        
        self.createEventAndDraftEventAPICall(strEventType: "Publish")
    }
    
    @IBAction func ActionSaveasDraftEvent(_ sender: UIButton) {
        
        self.createEventAndDraftEventAPICall(strEventType: "Draft")
    }
    
    @IBAction func ActionAllDay(_ sender: UIButton) {
        
        if strAllDay == "1"
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxOrange")
            strAllDay = "2"
            
            datePickerSelectDate.datePickerMode = .date
            imgViewIconStartClock.isHidden = true
            imgViewIconEndClock.isHidden = true
            lblStartTime.isHidden = true
            lblEndTime.isHidden = true
        }
        else
        {
            imgViewAllDay.image = UIImage(named: "iconCheckBoxBlack")
            strAllDay = "1"
            
            datePickerSelectDate.datePickerMode = .dateAndTime
            imgViewIconStartClock.isHidden = false
            imgViewIconEndClock.isHidden = false
            lblStartTime.isHidden = false
            lblEndTime.isHidden = false
        }
    }
    
    
    
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    fileprivate lazy var timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        return formatter
    }()
    
    
    // ********** UIDatePickerView Methods ********** //
    
    @IBAction func startDatePickerHandle(_ sender: UIDatePicker) {
        
        if isStartDate == true
        {
            lblStartDate.text = self.dateFormatter.string(from: sender.date)
            lblStartTime.text = self.timeFormatter.string(from: sender.date)
            
            startDate = sender.date
            
            let startTimeInterval = Int(startDate.timeIntervalSinceReferenceDate)
            let endTimeInterval = Int(endDate.timeIntervalSinceReferenceDate)
            
            if startTimeInterval > endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else if startTimeInterval == endTimeInterval
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
            else
            {
                var currentDate = Date()
                currentDate = NSCalendar.current.date(byAdding: .hour, value: 1, to: sender.date)!
                endDate = currentDate
                lblEndDate.text = self.dateFormatter.string(from: currentDate)
                lblEndTime.text = self.timeFormatter.string(from: currentDate)
            }
        }
        else
        {
            endDate = sender.date
            lblEndDate.text = self.dateFormatter.string(from: endDate)
            lblEndTime.text = self.timeFormatter.string(from: endDate)
        }
    }
    
    
    
    // ********** UIImagePickerControllerDelegate Methods ********** //
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        arrMediaData.add(info as Any)
        collectMedia.reloadData()
        viewMediaPlaceholder.isHidden = true
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if collectionView == collectEventColor
        {
            return arrColor.count
        }
        else
        {
            return arrMediaData.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        if collectionView == collectEventColor
        {
            let cellColor : CeleCollectColorCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CeleCollectColorCell
            
            cellColor.viewColor.backgroundColor = arrColor[indexPath.item] as? UIColor
        
            if strSelectTick == "\(indexPath.item)"
            {
                cellColor.imgViewTick.isHidden = false
            }
            else
            {
                cellColor.imgViewTick.isHidden = true
            }
        
            return cellColor
        }
        else
        {
            let cellMedia : CeleCollectNewEventMediaCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellMedia", for: indexPath) as! CeleCollectNewEventMediaCell
            
            let info = arrMediaData.object(at: indexPath.item) as! [String : Any]
            
            if let mediaType = info[UIImagePickerControllerMediaType] as? String {
                
                if mediaType == "public.image"
                {
                    cellMedia.imgView.image = (info[UIImagePickerControllerOriginalImage] as! UIImage)
                    cellMedia.imgViewPlayIcon.isHidden = true
                }
                
                if mediaType == "public.movie"
                {
                    let videoURL = info[UIImagePickerControllerMediaURL] as? NSURL
                    cellMedia.imgView.image = thumbnailForVideoAtURL(url: videoURL!)
                    cellMedia.imgViewPlayIcon.isHidden = false
                }
            }
            
            cellMedia.btnDelete.tag = indexPath.item
            cellMedia.btnDelete.addTarget(self, action: #selector(self.ActionDeleteMediaButton(sender:)), for: .touchUpInside)
            
            return cellMedia
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        if collectionView == collectEventColor
        {
            return CGSize(width: collectEventColor.frame.size.height, height: collectEventColor.frame.size.height)
        }
        else
        {
            return CGSize(width: collectMedia.frame.size.height, height: collectMedia.frame.size.height)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if collectionView == collectEventColor
        {
//            viewNavBackground.backgroundColor = arrColor[indexPath.item] as? UIColor
//            strEventSelectColor = "\(indexPath.item+1)"
//            strSelectTick = "\(indexPath.row)"
//            collectEventColor.reloadData()
            
            UIView.animate(withDuration: 0.5, animations: {
                
                self.viewNavBackground.backgroundColor = self.arrColor[indexPath.item] as? UIColor
                self.strEventSelectColor = "\(indexPath.item+1)"
                self.strSelectTick = "\(indexPath.row)"
                self.collectEventColor.reloadData()
            })
        }
        else
        {
            
        }
    }
    
    private func thumbnailForVideoAtURL(url: NSURL) -> UIImage? {
        
        let asset = AVAsset(url: url as URL)
        let assetImageGenerator = AVAssetImageGenerator(asset: asset)
        
        var time = asset.duration
        time.value = min(time.value, 2)
        
        do {
            let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
            
        } catch {
            return nil
        }
    }
    
    @objc func ActionDeleteMediaButton(sender: UIButton!)
    {
        arrMediaData.removeObject(at: sender.tag)
        collectMedia.reloadData()
        
        if arrMediaData.count == 0
        {
            viewMediaPlaceholder.isHidden = false
        }
    }
    
    
    // ********** Create And Draft Event WebService Call ********** //
    
    func createEventAndDraftEventAPICall(strEventType: String)
    {
        let arrImageData = NSMutableArray()
        let arrVideoData = NSMutableArray()
        let arrVideoThumbData = NSMutableArray()
        let arrImageThumbData = NSMutableArray()
        for i in (0..<arrMediaData.count)
        {
            let info = arrMediaData.object(at: i) as! [String : Any]
            let strMediaType = info[UIImagePickerControllerMediaType] as? String
            if strMediaType == "public.image"
            {
                let image = info[UIImagePickerControllerOriginalImage]
                let imageData = UIImageJPEGRepresentation(image! as! UIImage, 0.5)! as NSData
                arrImageData.add(imageData)
                
                let imgThumData = UIImageJPEGRepresentation(image! as! UIImage, 0.2)! as NSData
                arrImageThumbData.add(imgThumData)
            }
            else
            {
                let videoURL = info[UIImagePickerControllerMediaURL] as? NSURL
                let videoData = NSData(contentsOf: videoURL! as URL)! as NSData
                arrVideoData.add(videoData)
                
                let imgThumb = thumbnailForVideoAtURL(url: videoURL!)
                let videoThumData = UIImageJPEGRepresentation(imgThumb! , 0.5)! as NSData
                arrVideoThumbData.add(videoThumData)
            }
        }
        
        
        if txtEventTitle.text?.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Enter Event Name.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else if strEventSelectColor.count == 0
        {
            let alertControl = UIAlertController(title: nil, message: "Please Choose Event Color.", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
            
            let strStartDateServer = self.dateServerFormatter.string(from: startDate)
            let strStartTimeServer = self.timeServerFormatter.string(from: startDate)
            
            let strEndDateServer = self.dateServerFormatter.string(from: endDate)
            let strEndTimeServer = self.timeServerFormatter.string(from: endDate)
            
            var strEventAction = String()
            if strEventType == "Publish"
            {
                strEventAction = "Add"
            }
            else
            {
                strEventAction = "Draft"
            }
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":strEventAction, "Val_Celebrityid":strUserID, "Val_Title":txtEventTitle.text! as String, "Val_Color":strEventSelectColor, "Val_Startdate":strStartDateServer, "Val_Starttime":strStartTimeServer, "Val_EndDate":strEndDateServer, "Val_Endtime":strEndTimeServer, "Val_Allday":strAllDay, "Val_Videos":"", "Val_Location":txtLocation.text! as String, "Val_Notes":txtNotes.text! as String, "Val_Images":"", "Val_Imagesthumbs":"", "Val_Videosthumbs":""]
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    if value?.count == 0
                    {
                        if key == "Val_Images"
                        {
                            for imageData in arrImageData
                            {
                                multipartFormData.append(imageData as! Data, withName: "Val_Images\([])", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                            }
                        }
                        
                        if key == "Val_Imagesthumbs"
                        {
                            for imageData in arrImageThumbData
                            {
                                multipartFormData.append(imageData as! Data, withName: "Val_Imagesthumbs\([])", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                            }
                        }
                        
                        if key == "Val_Videos"
                        {
                            for videoData in arrVideoData
                            {
                                multipartFormData.append(videoData as! Data, withName: "Val_Videos\([])", fileName: "\(Date().timeIntervalSince1970).mp4", mimeType: "video/mp4")
                            }
                        }
                        
                        if key == "Val_Videosthumbs"
                        {
                            for videoData in arrVideoThumbData
                            {
                                multipartFormData.append(videoData as! Data, withName: "Val_Videosthumbs\([])", fileName: "\(Date().timeIntervalSince1970).jpeg", mimeType: "image/jpeg")
                            }
                        }
                    }
                    else
                    {
                        multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                        
                    }
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        let dicUpdateResponse = response.result.value as? [String: Any]
                        MBProgressHUD.hide(for: self.view, animated: true)
                        if dicUpdateResponse?["status"] as? String == "success"
                        {
                            if strEventType == "Publish"
                            {
                                self.navigationController?.popViewController(animated: true)
                            }
                            else
                            {
                                self.navigationController?.popViewController(animated: true)
                            }
                        }
                        else if dicUpdateResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    // ********** ServerSide Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "YYYY-MM-dd"
        return formatter
    }()
    
    fileprivate lazy var timeServerFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()
    
    
    
}







































