//
//  CeleCollectEditCal.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 01/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class CeleCollectEditCal: UICollectionViewCell {
    @IBOutlet weak var imgViewCalBack: UIImageView!
    
}
