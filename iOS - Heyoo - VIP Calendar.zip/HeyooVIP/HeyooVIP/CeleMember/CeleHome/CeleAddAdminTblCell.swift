//
//  CeleAddAdminTblCell.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 24/03/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit

class CeleAddAdminTblCell: UITableViewCell {
    @IBOutlet weak var lblContactName: UILabel!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var lblConNum: UILabel!
    @IBOutlet weak var imgViewUser: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
