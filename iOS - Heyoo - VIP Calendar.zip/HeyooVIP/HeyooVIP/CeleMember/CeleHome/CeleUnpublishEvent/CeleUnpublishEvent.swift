//
//  CeleUnpublishEvent.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 01/02/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire

class CeleUnpublishEvent: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var btnPublishAll: UIButton!
    @IBOutlet weak var viewNav: UIView!
    @IBOutlet weak var navigationBar: UINavigationBar!
    
    
    
    
    var dicEventList = NSDictionary()
    var arrEventListDateKey = NSMutableArray()
    var strCheckVC = String()
    var dicCustCalData = NSMutableDictionary()
    var dicEventDetailData = NSDictionary()
    
    var strIsMainCalendar = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnPublishAll.layer.shadowColor = UIColor.lightGray.cgColor
        btnPublishAll.layer.shadowOpacity = 0.4
        btnPublishAll.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnPublishAll.layer.shadowRadius = 5.0
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
  
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.getUnPublishEventsAPICall()
    }
    
    
    // ********** All Button Actions ********** //
    @IBAction func ActionBack(_ sender: UIBarButtonItem) {
        
        self.navigationController?.popViewController(animated: true)
    }
    
    
    // ********** UITableview Delegate And DataSourece Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return dicEventList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        let arrEventSectionWise = dicEventList[arrEventListDateKey[section]] as! NSArray
        return arrEventSectionWise.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : CeleHomeTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! CeleHomeTblCell
        
        let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
        let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        
        cell.viewColor.backgroundColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
        cell.lblEventName.text = dicPerticularEvent["EventTitle"] as? String
        
        if dicPerticularEvent["EventAllDay"] as! String == "2" {
            
            cell.lblTime.text = "All Day"
        }
        else {
            
            let inFormatter = DateFormatter()
            inFormatter.dateFormat = "HH:mm:ss"
            let outFormatter = DateFormatter()
            outFormatter.dateFormat = "hh:mma"
            
            let inTime = dicPerticularEvent["EventStartTime"] as! String
            let date = inFormatter.date(from: inTime)!
            let outTime = outFormatter.string(from: date)
            cell.lblTime.text = outTime
        }
        
        cell.setEditing(true, animated: true)
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
        let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        eventDetailAPICall(strEventID: (dicPerticularEvent["EventID"] as? String)!)
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 25
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView : CeleHomeHeaderCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! CeleHomeHeaderCell
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let strTempDate = arrEventListDateKey[section] as! String
        let date = dateFormatter.date(from: strTempDate)
        headerView.lblDateTitle.text = self.dateFormatterHeader.string(from: date!)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let viewFooter = UIView()
        viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
        viewFooter.backgroundColor = UIColor .white
        
        return viewFooter
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        self.deleteEventAPICall(indexPath: indexPath)
    }
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatterHeader: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    
    // ********** All Button Actions ********** //
    @IBAction func ActionPublishAll(_ sender: UIButton) {
        
        self.publishAllEventMainCalendarAPICall()
    }
    
    
    // ********** All Web Services Call *********** //
    // ********** Get Calendar Events ********** //
    func getUnPublishEventsAPICall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Calendar/Events"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Action":"UnpublishedDateWise"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary
                        self.dicEventList = dicData

                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []

                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"

                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }

                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)

                        }

                        self.tblView.reloadData()
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSDictionary()
                        self.tblView.reloadData()

                        let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                    else
                    {
                        self.dicEventList = NSDictionary()
                        self.tblView.reloadData()
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    // ********** Get Event Detail Api Call ********** //
    
    func eventDetailAPICall(strEventID:String)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Fetch"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Val_Celebrityid":strUserID,  "Action":"SingleEvent"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicEventResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicEventResponse?["status"] as? String == "success"
                        {
                            let arrEventDetailData = dicEventResponse?["data"] as! NSArray
                            self.dicEventDetailData = arrEventDetailData[0] as! NSDictionary
                            
                            let editEventVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleEditEventVC") as! CeleEditEventVC
                            editEventVC.dicEventDetailPass = self.dicEventDetailData
                            self.navigationController?.pushViewController(editEventVC, animated: true)

                            
                        }
                        else if dicEventResponse?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicEventResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction) in
                            }))
                            self.present(alertCntrl, animated: true, completion: nil)
                            
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
        
    }
    
    // ********** Publish All Event WebService Call ********** //
    func publishAllEventMainCalendarAPICall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/Details"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        
        let arrAllEventID = NSMutableArray()
        for i in (0..<arrEventListDateKey.count)
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[i]] as! NSArray
            for j in (0..<arrEventSectionWise.count)
            {
                let dicPerticularEvent = arrEventSectionWise[j] as! NSDictionary
                let strEventID = dicPerticularEvent["EventID"] as! String
                arrAllEventID.add(strEventID)
            }
        }
        let jsonDataForAllEvent :Data? = try? JSONSerialization.data(withJSONObject: arrAllEventID, options: [])
        let jsonStringForAllEvent = String(data: jsonDataForAllEvent ?? Data(), encoding: .utf8)
        
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"PublishAll", "Val_Celebrityid":strUserID, "Val_Eventids": jsonStringForAllEvent]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicUpdateResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicUpdateResponse?["status"] as? String == "success"
                    {
                        self.navigationController?.popViewController(animated: true)
                    }
                    else if dicUpdateResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
                print(encodingError)
            }
        }
    }
    
    // ********** Delete Event Api Call ********** //
    func deleteEventAPICall(indexPath: IndexPath)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            let dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            eventDetailAPICall(strEventID: (dicPerticularEvent["EventID"] as? String)!)
            
            
            let strEventID = dicPerticularEvent.value(forKey: "EventID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Action":"Delete"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDeleteCalendar = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDeleteCalendar?["status"] as? String == "success"
                        {
                            self.getUnPublishEventsAPICall()
                        }
                        else if dicDeleteCalendar?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDeleteCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                    print(encodingError)
                }
            }
        }
    }
    
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    

}







































