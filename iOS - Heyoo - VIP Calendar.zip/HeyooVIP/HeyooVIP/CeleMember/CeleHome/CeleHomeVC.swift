//
//  CeleHomeVC.swift
//  HeyooVIP
//
//  Created by Gaurav Patel on 30/01/18.
//  Copyright © 2018 Gaurav Patel. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage

class CeleHomeVC: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, FSCalendarDataSource, FSCalendarDelegate, FSCalendarDelegateAppearance {
    @IBOutlet weak var imgViewProPic: UIImageView!
    @IBOutlet weak var lblCalName: UILabel!
    @IBOutlet weak var imgViewNavHead: UIImageView!
    @IBOutlet weak var viewCalendarBackCover: UIView!
    @IBOutlet weak var viewCalenderBackCover: UIView!
    @IBOutlet weak var calendar: FSCalendar!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var viewMore: UIView!
    @IBOutlet weak var viewEditCalendar: UIView!
    @IBOutlet weak var collectView: UICollectionView!
    @IBOutlet weak var txtCalName: UITextField!
    @IBOutlet weak var btnCancelCal: UIButton!
    @IBOutlet weak var btnSaveCal: UIButton!
    @IBOutlet weak var imgViewCheckMonthView: UIImageView!
    @IBOutlet weak var imgViewCheckWeekView: UIImageView!
    @IBOutlet weak var btnAddAdmin: UIButton!
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var navItem: UINavigationItem!
    
    
    @IBOutlet weak var calendarHeightConstraint: NSLayoutConstraint!
    
    var viewPopup = UIView()
    var dicEventList = NSMutableDictionary()
    var arrEventListDateKey = NSMutableArray()
    var strSelectedDate = String()
    var isWeek : Bool = false
    var strGetDirCalBGImgName = String()
    var arrCalBackImage = NSArray()
    var dicEditCalData = NSDictionary()
    var arrSelectedCat = NSArray()
    var dicUsersData = NSDictionary()
    
    
    var strCalBGImageName = String()
    var strCalBGImageNameTemp = String()
    
    
    var moreBarButtonItem = UIBarButtonItem()
    var lblUnpublishBadge = UILabel()
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let strCeleType = UserDefaults.standard.value(forKey: "celeType") as? String
        if strCeleType == "3" {
            
            btnAddAdmin.isEnabled = false
            btnAddAdmin.setTitleColor(UIColor.lightGray, for: .normal)
        }
        
        imgViewProPic.layer.cornerRadius = imgViewProPic.frame.size.width/2
        imgViewProPic.layer.borderWidth = 2
        imgViewProPic.layer.borderColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 1.0).cgColor
        calendar.appearance.eventDefaultColor = UIColor.red
        calendar.appearance.eventSelectionColor = UIColor.red
        
        viewCalendarBackCover.layer.shadowColor = UIColor.lightGray.cgColor
        viewCalendarBackCover.layer.shadowOpacity = 0.4
        viewCalendarBackCover.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewCalendarBackCover.layer.shadowRadius = 3
        
        viewEditCalendar.layer.shadowColor = UIColor.lightGray.cgColor
        viewEditCalendar.layer.shadowOpacity = 0.4
        viewEditCalendar.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewEditCalendar.layer.shadowRadius = 3
        
        viewMore.layer.shadowColor = UIColor.lightGray.cgColor
        viewMore.layer.shadowOpacity = 0.4
        viewMore.layer.shadowOffset = CGSize(width: 1.5, height: 1.5)
        viewMore.layer.shadowRadius = 3
        
        btnCancelCal.layer.shadowColor = UIColor.lightGray.cgColor
        btnCancelCal.layer.shadowOpacity = 0.4
        btnCancelCal.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnCancelCal.layer.shadowRadius = 5.0
        
        btnSaveCal.layer.shadowColor = UIColor.lightGray.cgColor
        btnSaveCal.layer.shadowOpacity = 0.4
        btnSaveCal.layer.shadowOffset = CGSize(width: 3.0, height: 10.0)
        btnSaveCal.layer.shadowRadius = 5.0
        
        
        calendar.setCurrentPage(Date(), animated: true)
        
        let calendarGesture = UIPanGestureRecognizer(target: calendar, action: #selector(calendar.handleScopeGesture(_:)));
        calendar.addGestureRecognizer(calendarGesture)
        let calendarBackCoverGesture = UIPanGestureRecognizer(target: calendar, action: #selector(calendar.handleScopeGesture(_:)));
        viewCalenderBackCover.addGestureRecognizer(calendarBackCoverGesture)
        
        self.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationBar.shadowImage = UIImage()
        self.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
        moreBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconMoreWhite"), style: .plain, target: self, action: #selector(CeleHomeVC.ActionMoreButton(_:)))
        moreBarButtonItem.tintColor = UIColor.white
        
        lblUnpublishBadge = UILabel(frame: CGRect(x: 10, y: -10, width: 18, height: 18))
        lblUnpublishBadge.backgroundColor = UIColor.red
        lblUnpublishBadge.layer.cornerRadius = lblUnpublishBadge.bounds.size.height / 2
        lblUnpublishBadge.textAlignment = .center
        lblUnpublishBadge.layer.masksToBounds = true
        lblUnpublishBadge.font = UIFont.systemFont(ofSize: 11)
        lblUnpublishBadge.textColor = UIColor.white
        lblUnpublishBadge.text = "00"
        
        // button
        let rightButton = UIButton(frame: CGRect(x: 0, y: 0, width: 18, height: 16))
        rightButton.setBackgroundImage(UIImage(named: "iconCalWhite"), for: .normal)
        rightButton.addTarget(self, action: #selector(CeleHomeVC.ActionUnpublishEvent(_:)), for: .touchUpInside)
        rightButton.addSubview(lblUnpublishBadge)
        
        // Bar button item
        let unpublishBarButtonItem = UIBarButtonItem(customView: rightButton)
        self.navItem.rightBarButtonItems = [moreBarButtonItem, unpublishBarButtonItem]
        lblUnpublishBadge.isHidden = true
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.getNavigationBarBackgroundImageInDocumentDirectory()
        
        strSelectedDate = ""
        
        if self.calendar.scope == .month
        {
            imgViewCheckMonthView.isHidden = false
            imgViewCheckWeekView.isHidden = true
        }
        else
        {
            imgViewCheckMonthView.isHidden = true
            imgViewCheckWeekView.isHidden = false
        }
        
        dashboardAPICall()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    // ********** All Button Actions ********* //
    
    @IBAction func ActionCalPrev(_ sender: UIButton) {
        
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = -1
        }
        else
        {
            dateComponents.weekOfMonth = -1
        }
        
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    @IBAction func ActionCalNext(_ sender: UIButton) {
        
        let cal = Calendar.current
        var dateComponents = DateComponents()
        
        if self.calendar.scope == .month
        {
            dateComponents.month = 1
        }
        else
        {
            dateComponents.weekOfMonth = 1
        }
        calendar.currentPage = cal.date(byAdding: dateComponents, to: calendar.currentPage)!
        calendar.setCurrentPage(calendar.currentPage, animated: true)
    }
    
    @objc func ActionMoreButton(_ sender: UIButton) {
        
        viewMore.isHidden = false
        viewEditCalendar.isHidden = true
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.0)
        viewPopup.addSubview(viewMore)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
    }
    
    @objc func ActionUnpublishEvent(_ sender: UIButton) {
        
        let unpubVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleUnpublishEvent") as! CeleUnpublishEvent
        self.navigationController?.pushViewController(unpubVC, animated: true)
    }
    
    @IBAction func ActionCreateEvent(_ sender: UIButton) {
        
        let newEvent = self.storyboard?.instantiateViewController(withIdentifier: "CeleNewEventVC") as! CeleNewEventVC
        self.navigationController?.pushViewController(newEvent, animated: true)
    }
    
    @IBAction func ActionMonthView(_ sender: UIButton) {
        
        self.calendar.setScope(.month, animated: true)
        
        imgViewCheckMonthView.isHidden = false
        imgViewCheckWeekView.isHidden = true
        
        viewPopup.isHidden = true
        viewMore.isHidden = true
    }
    
    @IBAction func ActionListView(_ sender: UIButton) {
        
        self.calendar.setScope(.week, animated: true)
        
        imgViewCheckMonthView.isHidden = true
        imgViewCheckWeekView.isHidden = false
        
        viewPopup.isHidden = true
        viewMore.isHidden = true
    }
    
    @IBAction func ActionEditCalendar(_ sender: UIButton) {
        
        txtCalName.text = lblCalName.text
        
        viewEditCalendar.isHidden = false
        viewMore.isHidden = true
        
        viewPopup.frame = self.view.bounds
        viewPopup.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        viewPopup.addSubview(viewEditCalendar)
        self.view.addSubview(viewPopup)
        
        viewPopup.isHidden = false
        
        self.getCalendarImageAPICall()
    }
    
//    @IBAction func ActionEditProfile(_ sender: UIButton) {
//
//
//    }
    
//    @IBAction func ActionEditCategories(_ sender: UIButton) {
//
//        viewPopup.isHidden = true
//        viewMore.isHidden = true
//
//        let editCat = self.storyboard?.instantiateViewController(withIdentifier: "CeleEditCategoriesVC") as! CeleEditCategoriesVC
//    
//        self.navigationController?.pushViewController(editCat, animated: true)
//    }
    
    @IBAction func ActionAddAdmin(_ sender: UIButton) {
        
        viewPopup.isHidden = true
        viewMore.isHidden = true
        
        if btnAddAdmin.titleLabel?.text == "Add Admin" {
            
            let addAdminVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleAddAdminVC") as! CeleAddAdminVC
            self.navigationController?.pushViewController(addAdminVC, animated: true)
        }
        else {
            
            self.removeAdminAPICall()
        }
    }
    
    @IBAction func ActionLogOut(_ sender: UIButton) {
        viewPopup.isHidden = true
        viewMore.isHidden = true

        let celesettingVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleSettingsVC") as! CeleSettingsVC
        celesettingVC.dicUserData = dicUsersData
        celesettingVC.arrSelectedCat = arrSelectedCat
        self.navigationController?.pushViewController(celesettingVC, animated: true)
    }
    
    @IBAction func ActionCancelEditCalendar(_ sender: UIButton) {
        
        viewPopup.isHidden = true
        viewEditCalendar.isHidden = true
        print("\(strCalBGImageNameTemp) === \(strCalBGImageName)")
        strCalBGImageNameTemp = strCalBGImageName
        collectView.reloadData()
        
        self.getNavigationBarBackgroundImageInDocumentDirectory()
    }
    
    @IBAction func ActionSaveEditCalendar(_ sender: UIButton) {
        
        if (txtCalName.text?.isEmpty)! {
            
            let alertCntrl = UIAlertController(title: "Alert", message: "Please Enter Calendar Name", preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            self.present(alertCntrl, animated: true, completion: nil)
        }
        else{
            
//            lblCalName.text = txtCalName.text
//
//            viewPopup.isHidden = true
//            viewEditCalendar.isHidden = true
            
            self.editCalendarAPICall()
        }
    }
    
    // ********** Call Login WibService Method ********** //
    
    func LogOutWebServiceCall()
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Authentication/SignOut"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Action":"UserSignOut"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                        let fileURL = documentDirectoryURL.appendingPathComponent("CalBack")
                        do {
                            try FileManager.default.removeItem(at: fileURL)
                        } catch {
                        }
                        UserDefaults.standard.set(nil, forKey: "celeUserID")
                        UserDefaults.standard.set(nil, forKey: "celeType")
                        UserDefaults.standard.synchronize()
                        self.navigationController?.popToRootViewController(animated: true)
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicLoginResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                print(encodingError)
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    
    
    
    // ********** FSCalendar Deleagete Methods ********** //
    
    fileprivate lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM yyyy"
        return formatter
    }()
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar)
    {
//        lblCalenderHeader.text = self.dateFormatter.string(from: calendar.currentPage)
        strSelectedDate = ""
        
        let calTemp = Calendar.current
        let year = calTemp.component(.year, from: calendar.currentPage)
        let month = calTemp.component(.month, from: calendar.currentPage)
        
        let currentDate = Date()
        let curYear = calTemp.component(.year, from: currentDate)
        let curMonth = calTemp.component(.month, from: currentDate)
        if self.calendar.scope == .month
        {
            getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
        }
        else
        {
            var weekEndDate = Date()
            weekEndDate = NSCalendar.current.date(byAdding: .day, value: 6, to: calendar.currentPage)!

            let yearWeek = calTemp.component(.year, from: weekEndDate)

            let custCal = Calendar.current
            let weekOfYear = custCal.component(.weekOfYear, from: weekEndDate)

            let strWeekOfYear = "\(weekOfYear)"
            if strWeekOfYear.count == 1
            {
                getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(yearWeek)")
            }
            else
            {
                getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(yearWeek)")
            }
        }
    }
    
    func calendar(_ calendar: FSCalendar, boundingRectWillChange bounds: CGRect, animated: Bool)
    {
        self.calendarHeightConstraint.constant = bounds.height
        self.view.layoutIfNeeded()
        
        if self.calendar.scope == .month
        {
            imgViewCheckMonthView.isHidden = false
            imgViewCheckWeekView.isHidden = true
        }
        else
        {
            imgViewCheckMonthView.isHidden = true
            imgViewCheckWeekView.isHidden = false
        }
        if bounds.height < 100 || bounds.height > 222
        {
            strSelectedDate = ""

            self.calendarHeightConstraint.constant = bounds.height
            self.view.layoutIfNeeded()

            let calTemp = Calendar.current
            let year = calTemp.component(.year, from: calendar.currentPage)
            let month = calTemp.component(.month, from: calendar.currentPage)
            let currentDate = Date()
            let curYear = calTemp.component(.year, from: currentDate)
            let curMonth = calTemp.component(.month, from: currentDate)
            if self.calendar.scope == .month
            {
                getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
            }
            else
            {
                var weekEndDate = Date()
                weekEndDate = NSCalendar.current.date(byAdding: .day, value: 6, to: calendar.currentPage)!

                let yearWeek = calTemp.component(.year, from: weekEndDate)

                let custCal = Calendar.current
                let weekOfYear = custCal.component(.weekOfYear, from: weekEndDate)
                let strWeekOfYear = "\(weekOfYear)"
                if strWeekOfYear.count == 1
                {
                    getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(yearWeek)")
                }
                else
                {
                    getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(yearWeek)")
                }
            }
        }
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition)
    {
        let custCal = Calendar.current
        let weekOfYear = custCal.component(.weekOfYear, from: date)
        let dateString = self.dateFormatter2.string(from: date as Date)
        if arrEventListDateKey.contains(dateString)
        {
            strSelectedDate = "\(dateString)"
            tblView.reloadData()
        }
        else
        {
            let alertCntrl = UIAlertController(title: "Reminder:", message: "No events scheduled on this day.", preferredStyle: .alert)
            alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in
                
                self.strSelectedDate = ""
                self.tblView.reloadData()
            }))
            self.present(alertCntrl, animated: true, completion: nil)
        }
    }
    
    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, fillSelectionColorFor date: Date) -> UIColor?
    {
        return UIColor.red.withAlphaComponent(0.3)
    }
    
    func calendar(_ calendar: FSCalendar!, appearance: FSCalendarAppearance!, titleDefaultColorFor date: Date!) -> UIColor!
    {
        let dateString = self.dateFormatter2.string(from: date as Date)
        
        if arrEventListDateKey.contains(dateString)
        {
            return UIColor.red
        }

        return nil
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int
    {
        let dateString = self.dateFormatter2.string(from: date)
        if arrEventListDateKey.contains(dateString) {
            return 1
        }
        return 0
    }

    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    
    
    // ********** UITableview Delegate And DataSourece Methods ********** //
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        if strSelectedDate != ""
        {
            return 1
        }
        else
        {
            return dicEventList.count
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            return arrEventSelectedDate.count
            
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[section]] as! NSArray
            return arrEventSectionWise.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell : CeleHomeTblCell = tableView.dequeueReusableCell(withIdentifier: "cellID") as! CeleHomeTblCell
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        cell.viewColor.backgroundColor = postEventColorInTableCell(strColor: dicPerticularEvent.value(forKey: "EventColor") as! String)
        cell.lblEventName.text = dicPerticularEvent["EventTitle"] as? String
        if dicPerticularEvent["EventAllDay"] as! String == "2" {
            cell.lblTime.text = "All Day"
        }
        else {
            
            let inFormatter = DateFormatter()
            inFormatter.dateFormat = "HH:mm:ss"
            let outFormatter = DateFormatter()
            outFormatter.dateFormat = "hh:mma"
            
            let inTime = dicPerticularEvent["EventStartTime"] as! String
            let date = inFormatter.date(from: inTime)!
            let outTime = outFormatter.string(from: date)
            cell.lblTime.text = outTime
        }
        
        cell.setEditing(true, animated: true)
        cell .selectionStyle = UITableViewCellSelectionStyle.none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 25
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView : CeleHomeHeaderCell = tableView.dequeueReusableCell(withIdentifier: "cellHeader") as! CeleHomeHeaderCell
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        
        var strTempDate = String()
        if strSelectedDate != ""
        {
            strTempDate = strSelectedDate
        }
        else
        {
            strTempDate = arrEventListDateKey[section] as! String
        }
        
        let date = dateFormatter.date(from: strTempDate)
        headerView.lblDateTitle.text = self.dateFormatterHeader.string(from: date!)
        
        return headerView.contentView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let viewFooter = UIView()
        viewFooter.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 1)
        viewFooter.backgroundColor = UIColor .white
        
        return viewFooter
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        if dicPerticularEvent["EventClickable"] as! String == "1"
        {
            
        }
        else
        {
            let eventDetailVC = self.storyboard?.instantiateViewController(withIdentifier: "CeleEventDetailVC") as! CeleEventDetailVC
            eventDetailVC.strEventID = (dicPerticularEvent["EventID"] as? String)!
            self.navigationController?.pushViewController(eventDetailVC, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        var dicPerticularEvent = NSDictionary()
        if strSelectedDate != ""
        {
            let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
            dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
        }
        else
        {
            let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
            dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
        }
        
        if dicPerticularEvent["EventClickable"] as! String == "1"
        {
            
        }
        else
        {
            deleteEventAPICall(indexPath: indexPath)
        }
    }
    
    
    // ********** User Side Date Formater For Start / End Date Selector ********** //
    fileprivate lazy var dateFormatterHeader: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE, MMM dd, yyyy"
        return formatter
    }()
    
    
    
    // ********** UICollectionView Delegate And Datasource Methods ********** //
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return arrCalBackImage.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cellCalBck : CeleCollectEditCal = collectionView.dequeueReusableCell(withReuseIdentifier: "cellCalBack", for: indexPath) as! CeleCollectEditCal
        let dicImgData = arrCalBackImage[indexPath.item] as! NSDictionary
        cellCalBck.imgViewCalBack.layer.cornerRadius = cellCalBck.imgViewCalBack.frame.size.height / 2
        cellCalBck.imgViewCalBack.sd_setImage(with: URL(string : dicImgData["ColorPath"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        print("\(dicImgData["ColorName"] as! String == strCalBGImageNameTemp)")
        if dicImgData["ColorName"] as! String == strCalBGImageNameTemp {
            
            cellCalBck.imgViewCalBack.layer.borderWidth = 3
            cellCalBck.imgViewCalBack.layer.borderColor = UIColor(red: 255.0/255.0, green: 179.0/255.0, blue: 61.0/255.0, alpha: 0.5).cgColor
            dicEditCalData = arrCalBackImage[indexPath.item] as! NSDictionary
            print(dicEditCalData)
        }
        else {
            
            cellCalBck.imgViewCalBack.layer.borderWidth = 0
        }
        
        if strCalBGImageNameTemp == "8-CI-123123.jpg" {
            dicEditCalData = arrCalBackImage[0] as! NSDictionary
        }
        
        return cellCalBck
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let getWidth:CGFloat = CGFloat((collectionView.frame.size.height/2)*4)
        collectView.frame.size.width = CGFloat(getWidth)
        collectView.frame.origin.x = (viewEditCalendar.frame.size.width-getWidth)/2
        
        return CGSize(width: collectView.frame.size.height/2, height: collectView.frame.size.height/2)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        
        let dicImgData = arrCalBackImage[indexPath.item] as! NSDictionary
        imgViewNavHead.sd_setImage(with: URL(string : dicImgData["ColorPath"] as! String), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
        
        dicEditCalData = arrCalBackImage[indexPath.item] as! NSDictionary
        
        strCalBGImageNameTemp = dicImgData["ColorName"] as! String
        self.collectView.reloadData()
    }
    
    
    // ********** Other Methods ********** //
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        if let touch = touches.first
        {
            if touch.view == viewPopup
            {
                if viewEditCalendar.isHidden == false {
                    
                }
                else
                {
                    viewPopup.isHidden = true
                    viewMore.isHidden = true
                }
//                viewSwitchUser.isHidden = true
            }
            else
            {
                return
            }
        }
    }
    
    
    
    
    
    // ********** Dateboard API CAll ********** //
    
    func dashboardAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "User/Dashboard"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Action":"GetData"]
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDashResponse = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDashResponse?["status"] as? String == "success"
                        {
                            let dicData = dicDashResponse?["data"] as! NSDictionary
                            
                            let dicUserData = dicData["UserData"] as! NSDictionary
                            if dicUserData["status"] as! String == "error"
                            {
                                let alertCntrl = UIAlertController(title: "Warning", message: "\(dicUserData["message"] as! String)", preferredStyle: .alert)
                                alertCntrl.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (okAction:UIAlertAction) in
                                    self.navigationController?.popToRootViewController(animated: true)
                                }))
                                self.present(alertCntrl, animated: true, completion: nil)
                                
                            }
                            else
                            {
                                self.dicUsersData = dicUserData
                                self.arrSelectedCat = dicUserData["CategoriesArray"] as! NSArray
                                
                                if dicUserData["PAStatus"] as! String == "2" {
                                    
                                    self.btnAddAdmin.setTitle("Remove Admin", for: .normal)
                                }
                                else {
                                    
                                    let strCeleType = UserDefaults.standard.value(forKey: "celeType") as? String
                                    if strCeleType == "3" {
                                        
                                        self.LogOutWebServiceCall()
                                    }
                                    else {
                                        
                                        self.btnAddAdmin.setTitle("Add Admin", for: .normal)
                                    }
                                    
                                }
                                
                                
                                let strProfilePic = dicUserData["ProfileImage"] as! String
                                if strProfilePic == "" {
                                    
                                    self.profileNameImaageGenerater(strFName: dicUserData["FirstName"] as! String, strLName: dicUserData["LastName"] as! String)
                                }
                                else {
                                    
                                    self.imgViewProPic.sd_setImage(with: URL(string : strProfilePic), placeholderImage: nil, options: SDWebImageOptions.cacheMemoryOnly, completed: nil)
                                }
                                
                                
                                let dicMiscData = dicData["MiscData"] as! NSDictionary
                                print(dicMiscData)
                                if dicMiscData["status"] as! String == "error"
                                {
                                    self.lblUnpublishBadge.isHidden = true
                                }
                                else
                                {
                                    let unpubBadge:Int = dicMiscData["UnpublishedCount"] as! Int
                                    if unpubBadge == 0
                                    {
                                        self.lblUnpublishBadge.isHidden = true
                                    }
                                    else
                                    {
                                        self.lblUnpublishBadge.isHidden = false
                                        self.lblUnpublishBadge.text = String(unpubBadge)
                                    }
                                }
                                
                                self.strCalBGImageName = (dicMiscData["CalendarBGImage"] as! String)
                                self.strCalBGImageNameTemp = self.strCalBGImageName

                                self.lblCalName.text = (dicMiscData["CalendarName"] as! String)
                                
                                let cal = Calendar.current
                                var dateComponents = DateComponents()
                                dateComponents.day = 1
                                
                                let formatter = DateFormatter()
                                formatter.dateFormat = "YYYY-MM"
                                
                                let strCalDate = formatter.string(from: cal.date(byAdding: dateComponents, to: self.calendar.currentPage)!)
                                let strCurrDate = formatter.string(from: Date())
                                
                                if strCalDate == strCurrDate
                                {
                                    let dicEventListTemp = dicData["EventsData"] as! NSDictionary
                                    self.dicEventList = NSMutableDictionary()
                                    self.dicEventList = dicEventListTemp.mutableCopy() as! NSMutableDictionary

                                    let testArray = self.dicEventList.allKeys as NSArray
                                    var convertedArray: [Date] = []

                                    let dateFormatter = DateFormatter()
                                    dateFormatter.dateFormat = "yyyy-MM-dd"

                                    for dat in testArray {
                                        let strDate = dat as! String
                                        let date = dateFormatter.date(from: strDate)
                                        if let date = date {
                                            convertedArray.append(date)
                                        }
                                    }
                                
                                    self.arrEventListDateKey = NSMutableArray()
                                    let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                                    for dateArr in ready
                                    {
                                        let strFinalDate = dateFormatter.string(from: dateArr)
                                        self.arrEventListDateKey.add(strFinalDate)
                                    }
                                    self.tblView.reloadData()
                                    self.calendar.reloadData()
                                }
                                self.calBackImageOperations(dicMiscData: dicMiscData)
                            }
                        }
                        else if dicDashResponse?["status"] as? String == "error"
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            self.calendar.reloadData()
                            
                            let alertCntrl = UIAlertController(title: nil, message: (dicDashResponse?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                        else
                        {
                            self.dicEventList = NSMutableDictionary()
                            self.tblView.reloadData()
                            self.calendar.reloadData()
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
    }
    
    func getWeekWiseEventList(strWeek:String, strYear:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/DateWiseList"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Val_Status":"2", "Val_Year":strYear, "Val_Week":strWeek, "Action":"GetWeekWise"]

        Alamofire.upload(multipartFormData: { (multipartFormData) in

            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in

            switch encodingResult {

            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]

                    MBProgressHUD.hide(for: self.view, animated: true)

                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary

                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicData.mutableCopy() as! NSMutableDictionary

                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []

                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"

                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }

                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)

                        }

                        if self.arrEventListDateKey.count == 0
                        {
                        }
                        else
                        {
                        }

                        self.tblView.reloadData()
                        self.calendar.reloadData()

                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()

//                        self.lblEventAvailOrNot.isHidden = false
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                    }
                })

            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    
    // ********** Get Month wise Events ********** //
    func getMonthWiseEventList(strMonth:String, strYear:String)
    {
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "Event/DateWiseList"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Celebrityid":strUserID, "Val_Status":"2", "Val_Year":strYear, "Val_Month":strMonth, "Action":"GetMonthWise"]
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    
                    let dicLoginResponse = response.result.value as? [String: Any]
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                    if dicLoginResponse?["status"] as? String == "success"
                    {
                        let dicData = dicLoginResponse?["data"] as! NSDictionary
                        self.dicEventList = NSMutableDictionary()
                        self.dicEventList = dicData.mutableCopy() as! NSMutableDictionary
                        
                        let testArray = self.dicEventList.allKeys as NSArray
                        var convertedArray: [Date] = []
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        
                        for dat in testArray {
                            let strDate = dat as! String
                            let date = dateFormatter.date(from: strDate)
                            if let date = date {
                                convertedArray.append(date)
                            }
                        }
                        
                        self.arrEventListDateKey = NSMutableArray()
                        let ready = convertedArray.sorted(by: { $0.compare($1) == .orderedAscending })
                        for dateArr in ready
                        {
                            let strFinalDate = dateFormatter.string(from: dateArr)
                            self.arrEventListDateKey.add(strFinalDate)
                            
                        }
                        
                        if self.arrEventListDateKey.count == 0
                        {
//                            self.lblEventAvailOrNot.isHidden = false
                        }
                        else
                        {
//                            self.lblEventAvailOrNot.isHidden = true
                        }
                        
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
                    }
                    else if dicLoginResponse?["status"] as? String == "error"
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
                        
//                        self.lblEventAvailOrNot.isHidden = false
                    }
                    else
                    {
                        self.dicEventList = NSMutableDictionary()
                        self.arrEventListDateKey = NSMutableArray()
                        self.tblView.reloadData()
                        self.calendar.reloadData()
//                        self.lblEventAvailOrNot.isHidden = false
                    }
                })
                
            case .failure(let encodingError):
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    
    // ********** Delete Event Api Call ********** //
    func deleteEventAPICall(indexPath: IndexPath)
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Event/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            var dicPerticularEvent = NSDictionary()
            if strSelectedDate != ""
            {
                let arrEventSelectedDate = dicEventList[strSelectedDate] as! NSArray
                dicPerticularEvent = arrEventSelectedDate[indexPath.row] as! NSDictionary
            }
            else
            {
                let arrEventSectionWise = dicEventList[arrEventListDateKey[indexPath.section]] as! NSArray
                dicPerticularEvent = arrEventSectionWise[indexPath.row] as! NSDictionary
            }
            let strEventID = dicPerticularEvent.value(forKey: "EventID") as? String
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Val_Eventid":strEventID, "Action":"Delete"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicDeleteCalendar = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicDeleteCalendar?["status"] as? String == "success"
                        {
                            let calTemp = Calendar.current
                            let year = calTemp.component(.year, from: self.calendar.currentPage)
                            let month = calTemp.component(.month, from: self.calendar.currentPage)
                            if self.calendar.scope == .month
                            {
                                self.getMonthWiseEventList(strMonth: "\(month)", strYear: "\(year)")
                            }
                            else
                            {
                                let custCal = Calendar.current
                                let weekOfYear = custCal.component(.weekOfYear, from: self.calendar.currentPage)
                                
                                let strWeekOfYear = "\(weekOfYear)"
                                if strWeekOfYear.count == 1
                                {
                                    self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)")
                                }
                                else
                                {
                                    let strWeekOfYear = "\(weekOfYear)"
                                    if strWeekOfYear.count == 1
                                    {
                                        self.getWeekWiseEventList(strWeek: "0\(weekOfYear)", strYear: "\(year)")
                                    }
                                    else
                                    {
                                        self.getWeekWiseEventList(strWeek: "\(weekOfYear)", strYear: "\(year)")
                                    }
                                }
                            }
                            
                        }
                        else if dicDeleteCalendar?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicDeleteCalendar?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            }
        }
    }
    
    
    // ********** Remove Assistant API Call ********** //
    func removeAdminAPICall() {
        
//        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
        let strMainURL: String = "User/Profile"
        let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
        
        let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
        let strTimezone = "\(TimeZone.current.secondsFromGMT())"
        let strDST = UserDefaults.standard.value(forKey: "DST") as! String
        
        let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"RemoveAssistant", "Val_Celebrityid":strUserID, "Val_Assistantid":"\(dicUsersData["AssistantID"] as! String)"]
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            
            for (key,value) in parameters {
                
                multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
            }
            
        }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
            
            switch encodingResult {
                
            case .success(let upload, _, _):
                upload.responseJSON(completionHandler: { (response) in
                    let dicUpdateResponse = response.result.value as? [String: Any]
                    if dicUpdateResponse?["status"] as? String == "success"
                    {
                        self.btnAddAdmin.setTitle("Add Admin", for: .normal)
                        let alert = UIAlertController(title: nil, message: "Your Admin has been removed.", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "DONE", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    else if dicUpdateResponse?["status"] as? String == "error"
                    {
                        let alertCntrl = UIAlertController(title: nil, message: (dicUpdateResponse?["message"] as? String), preferredStyle: .alert)
                        alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(alertCntrl, animated: true, completion: nil)
                    }
                })
                
            case .failure(let encodingError):
                
                MBProgressHUD.hide(for: self.view, animated: true)
            }
        }
    }
    
    func profileNameImaageGenerater(strFName:String, strLName:String)
    {
        let lblNameInitialize = UILabel()
        lblNameInitialize.frame.size = CGSize(width: 100.0, height: 100.0)
        lblNameInitialize.textColor = UIColor.white
        lblNameInitialize.font = UIFont.systemFont(ofSize: 30.0)
        
        lblNameInitialize.text = String(strFName.characters.first!) + String(strLName.characters.first!)
        lblNameInitialize.textAlignment = NSTextAlignment.center
        lblNameInitialize.backgroundColor = UIColor.gray
        
        UIGraphicsBeginImageContext(lblNameInitialize.frame.size)
        lblNameInitialize.layer.render(in: UIGraphicsGetCurrentContext()!)
        self.imgViewProPic.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    
    // ********** Get Calendar Background Image Api Call ********** //
    func getCalendarImageAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Colors"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"GetAllColors"]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value ).data(using: .utf8)!), withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicGetCalImage = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicGetCalImage?["status"] as? String == "success"
                        {
                            
                            self.arrCalBackImage = dicGetCalImage!["data"] as! NSArray
                            self.collectView.reloadData()
                            
                            
                        }
                        else if dicGetCalImage?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicGetCalImage?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                }
            }
        }
    }
    
    // ********** Edit Calendar Api Call ********** //
    func editCalendarAPICall()
    {
        if !Reachability.isConnectedToNetwork()
        {
            let networkAlert = UIAlertController(title: "Please, check your internet connection", message: nil, preferredStyle: .alert)
            networkAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction) in
                
            }))
            self.present(networkAlert, animated: true, completion: nil)
        }
        else
        {
            MBProgressHUD.showAdded(to: self.view, animated: true)
            
            let strBaseURL: String = UserDefaults.standard.value(forKey: "baseURL") as! String
            let strMainURL: String = "Calendar/Details"
            let strFllURL = String(format:"%@%@", arguments:[strBaseURL, strMainURL])
            
            let strUserID = UserDefaults.standard.value(forKey: "celeUserID") as? String
            let strCalColor = strCalBGImageNameTemp
            let strTimezone = "\(TimeZone.current.secondsFromGMT())"
            let strDST = UserDefaults.standard.value(forKey: "DST") as! String
            
            let parameters = ["Val_Timezone":strTimezone, "Val_IsDST":strDST, "Action":"Update", "Val_Name":txtCalName.text!, "Val_Color":strCalColor, "Val_Celebrityid":strUserID]
            
            Alamofire.upload(multipartFormData: { (multipartFormData) in
                
                for (key,value) in parameters {
                    multipartFormData.append(((value )?.data(using: .utf8)!)!, withName: key)
                }
                
            }, usingThreshold: UInt64.init(), to: strFllURL, method: .post) { (encodingResult) in
                
                switch encodingResult {
                    
                case .success(let upload, _, _):
                    upload.responseJSON(completionHandler: { (response) in
                        
                        let dicGetCalImage = response.result.value as? [String: Any]
                        
                        MBProgressHUD.hide(for: self.view, animated: true)
                        
                        if dicGetCalImage?["status"] as? String == "success"
                        {
                            self.strCalBGImageName = self.strCalBGImageNameTemp
                            self.calendarBackgroundupdate()
                        }
                        else if dicGetCalImage?["status"] as? String == "error"
                        {
                            let alertCntrl = UIAlertController(title: nil, message: (dicGetCalImage?["message"] as? String), preferredStyle: .alert)
                            alertCntrl.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                            self.present(alertCntrl, animated: true, completion: nil)
                        }
                    })
                    
                case .failure(let encodingError):
                    
                    MBProgressHUD.hide(for: self.view, animated: true)
                    
                }
            }
        }
    }
    
    
    func postEventColorInTableCell(strColor: String) -> UIColor
    {
        if strColor == "1"
        {
            return customColor.color1
        }
        else if strColor == "2"
        {
            return customColor.color2
        }
        else if strColor == "3"
        {
            return customColor.color3
        }
        else if strColor == "4"
        {
            return customColor.color4
        }
        else if strColor == "5"
        {
            return customColor.color5
        }
        else if strColor == "6"
        {
            return customColor.color6
        }
        else
        {
            return customColor.color7
        }
    }
    
    func getNavigationBarBackgroundImageInDocumentDirectory() {
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let url = NSURL(fileURLWithPath: path)
        if let pathComponent = url.appendingPathComponent("CalBack") {
            let filePath = pathComponent.path
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: filePath) {
                
                do {
                    let arrBackContent = try FileManager.default.contentsOfDirectory(atPath: filePath)
                    strGetDirCalBGImgName = arrBackContent[0]
                    
                    let fileURL = pathComponent.appendingPathComponent(arrBackContent[0])
                    if FileManager.default.fileExists(atPath: fileURL.path)
                    {
                        self.imgViewNavHead.image = UIImage(contentsOfFile: fileURL.path)
                    }
                    else
                    {
                        
                    }
                    
                } catch {
                    
                }
                
            }
            else {
                
                
            }
        }
        else {
            
        }
        
    }
    
    func calBackImageOperations(dicMiscData:NSDictionary) {
        
        
        if dicMiscData["CalendarBGFlag"] as! String == "2" {
            
            if dicMiscData["CalendarBGImage"] as! String == strGetDirCalBGImgName {
                
                
            }
            else {
                
                let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(self.strGetDirCalBGImgName)")
                
                do {
                    
                    try FileManager.default.removeItem(at: fileURL)
                    
                    self.getDataFromUrl(url: URL(string: "\(dicMiscData["CalendarBGBaseURL"]!)/\(dicMiscData["CalendarBGImage"]!)")!, completion: { (data, response, error) in
                        DispatchQueue.main.async {
                            
                            let imageCalBack = UIImage(data: data!)!
                            
                            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
                            let url = NSURL(fileURLWithPath: path)
                            if let pathComponent = url.appendingPathComponent("CalBack") {
                                let filePath = pathComponent.path
                                let fileManager = FileManager.default
                                if fileManager.fileExists(atPath: filePath) {
                                    
                                    
                                    let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                                    let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(dicMiscData["CalendarBGImage"] as! String)")
                                    do {
                                        try UIImageJPEGRepresentation(imageCalBack, 1.0)!.write(to: fileURL)
                                    } catch {
                                    }
                                }
                                else {
                                    
                                    
                                    let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                                    let folderURL = documentDirectoryURL.appendingPathComponent("CalBack")
                                    do {
                                        try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: false, attributes: nil)
                                        
                                        let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(dicMiscData["CalendarBGImage"] as! String)")
                                        
                                        try UIImageJPEGRepresentation(imageCalBack, 1.0)!.write(to: fileURL)
                                        
                                    } catch {
                                    }
                                }
                                self.getNavigationBarBackgroundImageInDocumentDirectory()
                            }
                            else {
                            }
                        }
                    })
                } catch {
                }
            }
            
        }
        
    }
    
    func calendarBackgroundupdate() {
        
        let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(self.strGetDirCalBGImgName)")
        do {
            try FileManager.default.removeItem(at: fileURL)
            self.getDataFromUrl(url: URL(string: "\(dicEditCalData["ColorPath"]!)")!, completion: { (data, response, error) in
                DispatchQueue.main.async {
                    let imageCalBack = UIImage(data: data!)!
                    let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
                    let url = NSURL(fileURLWithPath: path)
                    if let pathComponent = url.appendingPathComponent("CalBack") {
                        let filePath = pathComponent.path
                        let fileManager = FileManager.default
                        if fileManager.fileExists(atPath: filePath) {
                            let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                            let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(self.dicEditCalData["ColorName"] as! String)")
                            do {
                                try UIImageJPEGRepresentation(imageCalBack, 1.0)!.write(to: fileURL)
                            } catch {
                            }
                        }
                        else {
                            let documentDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                            let folderURL = documentDirectoryURL.appendingPathComponent("CalBack")
                            do {
                                try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: false, attributes: nil)
                                let fileURL = documentDirectoryURL.appendingPathComponent("CalBack/\(self.dicEditCalData["ColorName"] as! String)")
                                try UIImageJPEGRepresentation(imageCalBack, 1.0)!.write(to: fileURL)
                            } catch {
                            }
                        }
                        self.lblCalName.text = self.txtCalName.text
                        self.viewPopup.isHidden = true
                        self.viewEditCalendar.isHidden = true
                        self.getNavigationBarBackgroundImageInDocumentDirectory()
                    }
                    else {
                    }
                }
            })
        } catch {
        }
    }
    
    // ********** Image URL Convert To Data ********** //
    
    func getDataFromUrl(url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url) { data, response, error in
            completion(data, response, error)
            }.resume()
    }
}



































